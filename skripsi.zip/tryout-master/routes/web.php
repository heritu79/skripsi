<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes(['register' => false]);

Route::group(['middleware' => ['auth']], function () {
    //dashboard
    Route::get('/', 'DashboardController@index')->name('dashboard');
    Route::get('homeroom', 'TeacherController@siswaWali');
    Route::get('homeroom/siswa/{study_group_id}', 'TeacherController@refreshSiswa');
    Route::post('homeroom/test-permission/siswa/{student}', 'TeacherController@testPermission');

    //pengelolaan Materi
    Route::resource('module', 'ModuleController')->only([
        'index', 'store', 'show', 'update', 'destroy'
    ]);
    Route::post('/module-answer', 'ModuleController@answer');
    Route::get('/module-answers/{module}', 'ModuleController@answers');
    Route::get('getmodule/{module}', 'ModuleController@getmodule');
    Route::delete('modulefile/{modulefile}', 'ModuleFileController@destroy')->name('modulefile.destroy');

    //pengaturan akun
    Route::get('setting', 'SettingController@userAcc')->name('setting')->middleware(['password.confirm']);
    Route::post('setting', 'SettingController@userAccStore');

    //route role admin
    Route::group(['middleware' => 'role:admin'], function () {
        //pengelolaan tipe soal
        Route::resource('type', 'QuestionTypeController')->only([
            'index', 'store', 'update', 'destroy'
        ]);
        Route::get('gettype/{type}', 'QuestionTypeController@gettype');

        //pengelolaan user
        Route::resource('user', 'UserController')->only([
            'index', 'show'
        ]);

        //pengelolaan informasi
        Route::resource('information', 'InformationController')->only([
            'index', 'store', 'show', 'update', 'destroy'
        ]);

        //pengelolaan guru
        Route::get('teacher', 'TeacherController@index');
        Route::post('teacher', 'TeacherController@store');
        Route::delete('teacher/{teacher}', 'TeacherController@destroy');
        
        //pengelolaan kelas
        Route::get('class', 'StudyGroupController@index');
        Route::post('class', 'StudyGroupController@store');
        Route::delete('class/{study_group}', 'StudyGroupController@destroy');

        Route::post('siswa', 'UserController@storeSiswa');
        Route::delete('siswa/{user_id}', 'UserController@destroySiswa');
        
        Route::patch('homeroom/change/{study_group}', 'StudyGroupController@homeroomChange');
        Route::post('import/siswa', 'ImportController@siswa');

        Route::get('statistic/{review}', 'ReviewController@statistic')->name('review.statistic');
        Route::get('review/detail/{user_tryout}', 'ReviewController@detail')->name('review.detail');
        Route::resource('review', 'ReviewController')->only('show');
    });

    //route role user
    Route::group(['middleware' => 'role:user'], function () {
        //tryout
        Route::resource('tryout', 'TryoutController')->only([
            'index', 'store', 'show'
        ]);
    });

    //route role user
    Route::group(['middleware' => 'role:teacher&admin'], function () {
        //pengelolaan paket soal
        Route::delete('/tryout/{user_tryout}', 'TryoutController@destroy');
        Route::get('package/result/{package}', 'QuestionPackageController@result')->name('package.user');
        Route::resource('package', 'QuestionPackageController')->only([
            'index', 'store', 'show', 'update', 'destroy'
        ]);
        
        //pengelolaan soal
        Route::resource('question', 'QuestionController')->only([
            'store', 'show', 'update', 'destroy'
        ]);

        Route::get('getpackage/{package}', 'QuestionPackageController@getpackage');
    });
});

//clear cache
Route::get('/clear-cache', function () {
    Artisan::call("cache:clear");
    Artisan::call("config:clear");
    Artisan::call("route:clear");
    Artisan::call("view:clear");
    echo "<script>
            document.location.href='/';
    </script>";
});
