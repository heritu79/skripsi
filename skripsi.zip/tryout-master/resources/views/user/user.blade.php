@extends('layouts.main')
@section('title','Pengelolaan Siswa')

@section('css')
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title">
            User Terdaftar
            <!-- <button class="btn btn-primary btn-sm float-right mx-1" id="create-siswa" data-toggle="modal" data-target="#create-siswa-modal">Tambah Siswa</button> -->
            <button class="btn btn-success btn-sm float-right mx-1" id="import-siswa" data-toggle="modal" data-target="#import-siswa-modal">Import Siswa</button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">NISN</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Paket Dikerjakan</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        @php
                            $progress=DB::table('user_tryouts')
                                ->where('id_user',$user->id)
                                ->distinct()
                                ->get(['id_question_package'])
                                ->count();
                        @endphp
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$user->name}}</td>
                            <td>{{$user->username}}</td>    
                            <td>{{$user["student"]["study_group"]['name']}}</td>
                            <td>
                                <div class="progress shadow mt-2" style="height: 6px;">
                                    <div class="progress-bar gradient-quepal" role="progressbar" style="width: {{ $total_package > 0 ? $progress/$total_package*100 : ''}}%"></div>
                                </div>
                            </td>
                            <td>
                                <a href="/review/{{ $user->id }}" style="cursor:pointer" class="badge badge-primary">Ujian</a>
                                <span style="cursor:pointer" class="badge badge-secondary" onclick="detail({{$user->id}})">Detail</span>
                                <span style="cursor:pointer" class="badge badge-danger delete-siswa" onclick="deleteSiswa({{$user->id}})">Delete</span>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- modal form --}}
<div class="modal fade" id="modalUser">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Detail User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="profile-card-3">
                    <div class="card-group">
                        <div class="card">
                            <div class="user-fullimage">
                                <img id="profile_picture" src="{{url('img/profile/default.png')}}" alt="" class="card-img-top">
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 id="name" class="mb-1  ml-3">Nama</h5>
                                <p id="username"></p>
                                <p id="email" class="ml-3">Email</p>
                                <div class="row mt-2">
                                    <div class="col p-2">
                                        <h5 id="total" class="mb-1 line-height-5 text-primary">0</h5>
                                        <small class="mb-0 font-weight-bold text-primary">Ulangan Online</small>
                                    </div>
                                    <div class="col p-2">
                                        <h5 id="pass" class="mb-1 line-height-5 text-success">0</h5>
                                        <small class="mb-0 font-weight-bold text-success">Lulus</small>
                                    </div>
                                    <div class="col p-2">
                                        <h5 id="fail" class="mb-1 line-height-5 text-danger">0</h5>
                                        <small class="mb-0 font-weight-bold text-danger">Gagal</small>
                                    </div>
                                </div>
                                <p id="email" class="ml-3 mt-2">Paket Dikerjakan</p>
                                <div class="progress shadow mt-2" style="height: 6px;">
                                    <div id="progress" class="progress-bar gradient-quepal" role="progressbar" style="width: 100%"></div>
                                </div>
                                <p class="mt-2">Member Since : <span id="member"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<form id="delete-siswa-form" action="/siswa" method="post">
    @method('delete')
    @csrf
</form>
{{-- modal form --}}
<div class="modal fade" id="create-siswa-modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Siswa</h5>
            </div>
            <form action="/siswa" method="post">
                <div class="modal-body row">
                        @csrf
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Nama : </label>
                                <input type="text" class="form-control" name="name" autocomplete="off" placeholder="Masukan Nama">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Username :</label>
                                <input type="text" class="form-control" name="username" autocomplete="off" placeholder="Masukan Username">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Password :</label>
                                <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Masukan Password">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Konfirmasi Password :</label>
                                <input type="password" class="form-control" name="password_confirmation" autocomplete="off" placeholder="Masukan Password">
                            </div>
                        </div>
                        <div class="col-qw col-md-6">
                            <div class="form-group">
                                <label>Kelas :</label>
                                <select class="custom-select" name="study_group_id">
                                    <option selected disabled>Pilih Kelas</option>
                                    @foreach($classes as $class)
                                    <option value="{{$class->id}}">{{$class->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-sm float-right" id="store-siswa">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="import-siswa-modal">
    <div class="modal-dialog">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5>Import Siswa</h5>
            </div>
            <div class="modal-body">
                <form action="/import/siswa" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="file">
                    <button class="btn btn-primary float-right">Import</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
    <!--Data Tables js-->
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

    <script>
        $('#default-datatable').DataTable();

        function detail(id){
            $('#modalUser').modal('show');
            
            $.ajax({
                url: "{{url('user').'/'}}" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    console.log(data);
                    $('#profile_picture').attr('src',"{{url('img/profile/')}}/"+data[0].profile_picture)
                    $('#name').text(data[0].name);
                    $('#username').text("("+data[0].username+")");
                    $('#email').html('<span class="badge badge-dark">'+data[0].email+'</span>');
                    $('#progress').attr('style','width:'+(data[1]/data[2]*100)+'%');
                    $('#total').text(data[3]);
                    $('#pass').text(data[4]);
                    $('#fail').text(data[5]);
                    $('#member').text(data[6]);

                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    console.log('Error - ' + errorMessage);
                }
            });
        }

        function deleteSiswa(id){
            console.log(id)
            $('#delete-siswa-form').attr('action', '/siswa/'+id)
            $('#delete-siswa-form').submit()
        }
    </script>
@endsection