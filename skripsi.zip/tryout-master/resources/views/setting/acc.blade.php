@extends('layouts.main')
@section('title','Pengaturan Akun')

@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
<form action="{{url('setting')}}" method="POST" enctype="multipart/form-data">
@csrf
{{method_field('POST')}}
<div class="row justify-content-md-center">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                Pengaturan Akun
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="form-group col-lg-12">
                        <div class="text-center">
                            <img src="{{url('img/profile/'.$user->profile_picture)}}"  class="img-fluid img-thumbnail full-width" style="width:200px;height:200px;object-fit:cover;overflow:hidden;">
                            <input type="hidden" name="old_picture" id="" value="{{$user->profile_picture}}">
                        </div>
                        <label for="profile-picture">Ubah Gambar</label>
                        <input type="file" class="form-control @error('profile-picture') is-invalid @enderror form-control-sm" id="profile-picture" profile-picture="profile-picture" name="profile_picture">
                        @error('profile-picture')
                            <p class="text-danger ml-3">
                                <small>{{ $message }}</small>
                            </p>
                        @enderror
                    </div>
                    <div class="form-group col-lg-6 ">
                        <label for="name">Nama</label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror form-control-sm" id="name" name="name" placeholder="Masukan Nama anda" value="{{$user->name}}">
                        @error('name')
                            <p class="text-danger ml-3">
                                <small>{{ $message }}</small>
                            </p>
                        @enderror
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="email">Email</label>
                        <input type="text" class="form-control form-control-sm disable" readonly id="email" name="email" value="{{$user->email}}">
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="password">Password</label>
                        <input type="password" class="form-control @error('password') is-invalid @enderror form-control-sm" id="password" name="password" placeholder="Masukan Password">
                        @error('password')
                            <p class="text-danger ml-3">
                                <small>{{ $message }}</small>
                            </p>
                        @enderror
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="password_confirmation">Konfirmasi Password</label>
                        <input type="password" class="form-control form-control-sm" id="password_confirmation" name="password_confirmation" placeholder="Masukan Ulang Password">
                    </div>
                </div>
                <div class="form-group mt-2">
                    <button type="submit" class="btn btn-primary float-right shadow-primary px-5"><i class="icon-login"></i> Update</button>
                </div>

            </div>
        </div>
    </div>
</div>
</form>
@endsection

@section('js')
{{-- notification --}}
@endsection
