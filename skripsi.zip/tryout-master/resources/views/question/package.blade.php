@extends('layouts.main')
@section('title','Pengelolaan Soal')

@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')

<div class="row">
    <div class="col-lg-6 mb-4">
        <button onclick="addform()" class="btn btn-primary waves-effect waves-light m-1"><i class="fa fa-plus mr-1"></i>Tambah Paket Soal</button>
    </div>
    <div class="col-lg-12">
        <div class="row">
            @php
                $i=0;
            @endphp
            @forelse ($questionPackages as $questionPackage)
                @php
                    $color=['primary','success','danger','info','warning','dark','secondary'];
                    if($i==count($color)-1){
                        $i=0;
                    }else{
                        $i++;
                    }
                @endphp
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title text-{{$color[$i]}}">
                                {{$questionPackage->question_package}} 
                                @if($questionPackage->is_active=="false")
                                    <span class="text-dark">(status : tidak aktif)</span> 
                                    <i class="fa fa-info-circle pull-right" data-toggle="tooltip" data-placement="top" title="Status tidak aktif menandakan paket tidak akan muncul dan dapat dikerjakan oleh user. Edit status paket menjadi aktif apabila ingin menampilkannya."></i>
                                @endif
                            </h5>
                            <p class="card-text">{{$questionPackage->desc}}</p>
                            @php
                                $question_count=DB::table('questions')
                                        ->where('id_question_package',$questionPackage->id)
                                        ->count();
                            @endphp
                            <p class="card-text">Waktu Pengerjaan: <b>{{$questionPackage->tryout_time}}</b> Menit</p>
                            <p class="card-text">Tingkat : <b>{{$questionPackage->degree}}</b></p>
                            <p class="card-text">Jurusan : <b>{{$questionPackage->department}}</b></p>
                            <p class="card-text">Jumlah Soal : <b>{{$question_count}}</b> Soal</p>
                            @php
                                $user = DB::table('users')
                                    ->where('id', '=', $questionPackage->user_id)
                                    ->first();
                            @endphp
                            <p class="card-text">Penulis Soal : <b>{{ $questionPackage->user_id != null ? $user->name : 'admin' }}</b></p>
                            @php
                                $question_type_in_question = DB::table('questions')
                                    ->where('id_question_package', '=', $questionPackage->id)
                                    ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
                                    ->distinct()
                                    ->get(['question_type']);
                            @endphp
                            <p class="card-text"> 
                                @foreach ($question_type_in_question as $question_type)
                                    @php
                                        $count_type=DB::table('questions')
                                            ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
                                            ->where('id_question_package',$questionPackage->id)
                                            ->where('question_type',$question_type->question_type)
                                            ->count(['question_type']);
                                    @endphp
                                    | {{$question_type->question_type}} : <b>{{$count_type}}</b> |
                                @endforeach
                            </p>
                            <hr>
                            <div class="row">
                                <div class="col-lg-6">
                                    <button class="btn-sm delete-package btn btn-outline-{{$color[$i]}} waves-effect waves-light " data-id="{{$questionPackage->id}}" data-action="{{route('package.destroy',$questionPackage->id)}}"> <i class="fa fa-trash-o fa-2x"></i> </button>
                                    <button class="btn-sm btn btn-outline-{{$color[$i]}} waves-effect waves-light" onclick="editPackageForm({{$questionPackage->id}})"> <i class="fa fa-edit fa-2x"></i> </button>
                                    
                                </div>
                                <div class="col-lg-6">
                                    <a href="{{route('package.show',$questionPackage->id)}}" class=" float-right btn btn-{{$color[$i]}} waves-effect waves-light"><i class="fa fa-plus mr-1"></i> Tambah Soal</a>
                                </div>
                                <div class="col-lg-12">
                                    <a href="{{route('package.user',$questionPackage->id)}}" class="mt-2 btn-block btn btn-{{$color[$i]}} waves-effect waves-light"><i class="fa fa-user"></i> Hasil Pengerjaan Siswa </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <center>
                    <h6 class="text-center" style="text-align: center;">Belum Ada Paket Soal Tersedia :(</h6>
                </center>
            @endforelse
        </div>
    </div>
</div>

{{-- Modals --}}
<div class="modal fade" id="modalPackage">
    <div class="modal-dialog">
        <form id="form_package" action="{{url('package')}}" method="POST">
            @csrf
            {{method_field('')}}
            <div class="modal-content animated fadeInUp">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Paket Soal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                    <div class="row">
                        <div class="form-group col-lg-12">
                            <input type="hidden" name="id" value="">
                            <label for="question_package">Nama Paket</label>
                            <input type="text" class="form-control @error('question_package') is-invalid @enderror" id="question_package" placeholder="masukan nama paket" name="question_package" value="{{ old('question_package') }}" autocomplete="off" autofocus>
                            @error('question_package')
                                <small for="question_package" class="error">{{$message}}</small>
                            @enderror
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="tryout_time">Waktu Pengerjaan(menit)</label>
                            <input type="number" class="form-control @error('tryout_time') is-invalid @enderror" id="tryout_time" placeholder="masukan waktu pengerjaan" name="tryout_time" value="{{ old('tryout_time') }}" autocomplete="off" autofocus>
                            @error('tryout_time')
                                <small for="tryout_time" class="error">{{$message}}</small>
                            @enderror
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="is_active">Status Paket</label>
                            <select name="is_active" class="form-control" id="is_active">
                                <option value="false">Tidak Aktif</option>
                                <option value="true">Aktif</option>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="department">Jurusan</label>
                            <input type="text" class="form-control @error('department') is-invalid @enderror" id="department" placeholder="masukan nama jurusan" name="department" value="{{ old('department') }}" autocomplete="off" autofocus>
                            @error('department')
                                <small for="department" class="error">{{$message}}</small>
                            @enderror
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="degree">Tingkat</label>
                            <select name="degree" class="form-control" id="degree">
                                <option value="X">X</option>
                                <option value="XI">XI</option>
                                <option value="XII">XII</option>
                            </select>
                        </div>
                        <div class="form-group col-lg-12">
                            <label for="desc">Keterangan</label>
                            <textarea rows="4" class="form-control" id="desc" placeholder="masukan keterangan paket" name="desc">{{ old('desc') }}</textarea>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary"><span id="submit"><i class="fa fa-plus"></i> Tambah Paket</span> </button>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@section('js')
<script src="{{url("assets/plugins/switchery/js/switchery.min.js")}}"></script>


@if ($errors->any())
    <script>
        $("#modalPackage").modal('show');        
    </script>
@endif

<script>
    function addform() {
        $("#modalPackage").modal('show');
        $('.modal-title').html('Tambah Paket Soal');
        $('#submit').html('<i class="fa fa-plus"></i> Tambah');
        $('#question_package').val('');
        $('#tryout_time').val('');
        $('#is_active').val('false');
		$('#desc').text('');
        $('input[name$="_method"]').val('POST');
        $('#form_package').attr('action',"{{url('package')}}");
    }

    $('body').on("click",".delete-package", function() {
        var current_object=$(this);
        swal({
            title: "Apa kamu yakin?",
            text: "anda akan menghapus semua soal yang terdapat pada paket ini",
            type: "error",
            showCancelButton:true,
            dangerMode:true,
            cancelButtonClass:'#DD5B55',
            confirmButtonColor:'#dc3545',
            confirmButtonText:'Delete!',
        },function(result){
            if(result){
                var action=current_object.attr('data-action');
                var token = jQuery('meta[name="csrf-token"]').attr('content');
                var id=current_object.attr('data-id');

                $('body').html("<form class='form-inline delete-package' method='post' action='"+action+"'></form>");
                $('body').find('.delete-package').append('<input name="_method" type="hidden" value="delete">');
                $('body').find('.delete-package').append('<input name="_token" type="hidden" value="'+token+'">');
                $('body').find('.delete-package').append('<input name="id" type="hidden" value="'+id+'">');
                $('body').find('.delete-package').submit();
            }
        });
    });

    function editPackageForm(id){
        $("#modalPackage").modal('show');
        $('.modal-title').html('Edit Paket Soal');
        $('#submit').html('<i class="fa fa-edit"></i> Edit');
        $('#form_package').attr('action',"{{url('package')}}/"+id);
        $('input[name$="_method"]').val('PATCH');
        $('input[name$="id"]').val(id);

        $.ajax({
			url: "{{url('getpackage').'/'}}" + id,
			type: "GET",
			dataType: "JSON",
			success: function(data) {
                console.log(data)

				$('#question_package').val(data.question_package);
                $('#tryout_time').val(data.tryout_time);
                $('#is_active').val(data.is_active);
				$('#desc').text(data.desc);
				$('#degree').val(data.degree);
				$('#department').val(data.department);
			},
			error: function(xhr, status, error) {
				var errorMessage = xhr.status + ': ' + xhr.statusText
				console.log('Error - ' + errorMessage);
			}
		});
    }

    setTimeout(function(){
        $('#notification').slideUp();
    },3000 );
</script>
@endsection