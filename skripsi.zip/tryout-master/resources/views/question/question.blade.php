@extends('layouts.main')
@section('title','Pengelolaan Soal')
@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{url('assets/plugins/summernote/dist/summernote-bs4.css')}}" />
    <style>
        .item {
            position:relative;
            padding-top:20px;
            display:inline-block;
        }
        .notify-badge{
            position: absolute;
            right:16px;
            top:20px;
            background:#008cff;
            text-align: center;
            border-radius: 30px 30px 30px 30px;
            color:white;
            padding:5px 10px;
            font-size:10px;
        }
    </style>
@endsection

@section('content')
<div class="row ">
    <div class="col-lg-12 ">
        <div class="card card-primary">
            <div class="card-header text-uppercase text-primary">Informasi Paket</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">
                        <p class="card-text">Nama Paket : <b>{{$question_package->question_package}}</b></p>
                        <p class="card-text">Deskripsi Paket : <b>{{$question_package->desc}}</b></p>
                    </div>
                    <div class="col-lg-6">
                        <p class="card-text">Waktu Pengerjaan : <b>{{$question_package->tryout_time}} Menit</b></p>
                        <p class="card-text">Jumlah Soal : <b>{{$question_count}}</b></p>
                        <p class="card-text"> 
                            @foreach ($question_type_in_question as $question_type)
                                @php
                                    $count_type=DB::table('questions')
                                        ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
                                        ->where('id_question_package',$question_package->id)
                                        ->where('question_type',$question_type->question_type)
                                        ->count(['question_type']);
                                @endphp
                                {{$question_type->question_type}} : <b>{{$count_type}}</b> ||
                            @endforeach
                        </p>
                    </div>
                </div>
                <button onclick="addform()" class="mt-3 btn btn-primary waves-effect waves-light m-1"><i class="fa fa-plus mr-1"></i>Tambah Soal</button>
            </div>
        </div>
    </div>

    @foreach ($questions as $question)
    <div class="col-lg-6">
        <div class="card card-success">
            <img src="{{url('img/question/'.$question->question_image)}}" style="" class=" card-img-top" alt=''>
            <div class="card-body">
                <p class="card-text "><b>{{$loop->iteration}}.</b> {!!$question->question!!}</p>
                <p class="text-success">Type Soal : {{$question->question_type->question_type}}</p>

                @php
                    $choices=DB::table('question_choices')
                            ->where('id_question',$question->id)
                            ->get();
                @endphp

                @if ($question->choice_type=="img")
                    <div class="row">
                        @foreach ($choices as $choice)
                            <div class="col-6 item">
                                @if($choice->value!=0)<span class="notify-badge">{{$choice->value}}</span>@endif
                                <img src="{{url('img/question/'.$choice->choice)}}" class="card-img-top">
                            </div>
                        @endforeach
                    </div>
                    
                @else
                    <ul class="list-group list-group-flush list shadow-none">
                        @foreach ($choices as $choice)
                            <li class="list-group-item @if($choice->value==5) {{'active'}} @endif d-flex justify-content-between align-items-center">
                                {{$choice->choice}}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <div class="card mb-2">
                    <div class="card-header">
                        <button class="btn btn-link shadow-none" data-toggle="collapse" data-target="#soal{{$loop->iteration}}" aria-expanded="true" aria-controls="soal{{$loop->iteration}}">
                        Penjelasan Soal
                        </button>
                    </div>
    
                    <div id="soal{{$loop->iteration}}" class="collapse" data-parent="#soal{{$loop->iteration}}">
                        <div class="card-body">
                            {!!$question->answer!!}
                        </div>
                    </div>
                </div>
                {{-- <p><span class="text-success"> Jawaban :</span> {!!$question->answer!!}</p> --}}
            </div>
            <div class="card-footer">
                <button class="btn-sm btn float-right btn-outline-warning waves-effect waves-light" onclick="editPackageForm({{$question->id}})"> <i class="fa fa-edit fa-2x"></i> </button>
                <button class="btn-sm delete-question btn float-right btn-outline-danger waves-effect waves-light mr-1" data-id="{{$question->id}}" data-action="{{route('question.destroy',$question->id)}}"> <i class="fa fa-trash-o fa-2x"></i> </button>
            </div>
        </div>
    </div>
    @endforeach
</div>

<div class="modal fade" id="modalQuestion">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" style="width:95%;max-width:1300px">
        <form id="form_question" action="{{url('question')}}" method="POST" enctype="multipart/form-data">
            <div class="modal-content animated fadeInUp">
                <div class="modal-body row  mb-0">
                    @csrf
                    {{method_field('')}}
                    <input type="hidden" name="id_question_package" value="{{$question_package->id}}">
                    <div class="col-lg-12">
                        <div class="card-title">
                            <span id='title'>Form Input Soal</span>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="form-group" id="form_soal">
                            <label for="soal">Soal</label>
                            <textarea rows="2" class="form-control" id="soal" placeholder="masukan soal" name="question">{{ old('question') }}</textarea>
                        </div>
                    </div>
                    <!-- <div class="col-lg-6">
                        <div class="form-group row">
                            <label for="basic-select" class="col-lg-4 col-form-label">Gambar Soal</label>
                            <div class="custom-file custom-file-sm col-lg-8">
                                <input type="file" name="question_image" class="custom-file-input" id="question_image">
                                <label class="custom-file-label question_image" for="question_image">Choose file</label>
                                <div id="old_question_image_box">
                                    
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-lg-6">
                        <div class=" form-group row">
                            <label for="basic-select" class="col-lg-4 form-sm col-form-label">Tipe Soal</label>
                            <div class="col-lg-8">
                                <select name="id_question_type" class="form-control" id="question_type">
                                    @foreach ($question_types as $question_type)
                                        <option value="{{$question_type->id}}">{{$question_type->question_type}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 text-center">
                        <div class="">
                            <input type="checkbox" id="choice_type" name="choice_type" class="choice" value="true"/>
                            <label for="choice_type">Jawaban berbentuk gambar</label>
                        </div>
                        @if ($errors->any())
                            @foreach($errors->all() as $error)
                                <small for="passing_grade" class="error">{{$error}}</small>
                            @endforeach
                        @endif
                        
                    </div>
                    
                    <div class="col-lg-12 choice-text">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="texta" class="col-sm-1 col-form-label">A. </label>
                                    <div class="col-sm-9">
                                        <textarea rows="1" class="form-control" name="text[0]"id="texta" placeholder="masukan pilihan jawaban" >{{ old('text[0]') }}</textarea>
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="checkbox" id="valtexta" name="valtext[0]" class="choice"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="textb" class="col-sm-1 col-form-label">B. </label>
                                    <div class="col-sm-9">
                                        <textarea rows="1" class="form-control" name="text[1]" id="textb" placeholder="masukan pilihan jawaban" >{{ old('text[1]') }}</textarea>
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="checkbox" id="valtextb" name="valtext[1]" class="choice"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="textc" class="col-sm-1 col-form-label">C. </label>
                                    <div class="col-sm-9">
                                        <textarea rows="1" class="form-control" name="text[2]" id="textc" placeholder="masukan pilihan jawaban" >{{ old('text[2]') }}</textarea>
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="checkbox" id="valtextc" name="valtext[2]" class="choice"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="textd" class="col-sm-1 col-form-label">D. </label>
                                    <div class="col-sm-9">
                                        <textarea rows="1" class="form-control" name="text[3]" id="textd" placeholder="masukan pilihan jawaban" >{{ old('text[3]') }}</textarea>
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="checkbox" id="valtextd" name="valtext[3]" class="choice"/>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="texte" class="col-sm-1 col-form-label">E. </label>
                                    <div class="col-sm-9">
                                        <textarea rows="1" class="form-control" name="text[4]" id="texte" placeholder="masukan pilihan jawaban" >{{ old('text[4]') }}</textarea>
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="checkbox" id="valtexte" name="valtext[4]" class="choice"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 choice-img">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="imga" class="col-sm-1 col-form-label">A. </label>
                                    <div class="col-sm-9">
                                        <input type="file" name="img[]" class="custom-file-input" id="imga" value="">
                                        <label class="custom-file-label imga" for="imga">Choose file</label>
                                        <small class="itembox">File sebelumnya : <span id="itema"></span></small>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="valimg[]" class="form-control" id="valimga">
                                            <option value="0">Salah</option>
                                            <option value="5">Benar</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="imgb" class="col-sm-1 col-form-label">B. </label>
                                    <div class="col-sm-9">
                                        <input type="file" name="img[]" class="custom-file-input" id="imgb" value="">
                                        <label class="custom-file-label imgb" for="imgb">Choose file</label>
                                        <small class="itembox">File sebelumnya : <span id="itemb"></span></small>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="valimg[]" class="form-control" id="valimgb">
                                            <option value="0">Salah</option>
                                            <option value="5">Benar</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="imgc" class="col-sm-1 col-form-label">C. </label>
                                    <div class="col-sm-9">
                                        <input type="file" name="img[]" class="custom-file-input" id="imgc" value="">
                                        <label class="custom-file-label imgc" for="imgc">Choose file</label>
                                        <small class="itembox">File sebelumnya : <span id="itemc"></span></small>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="valimg[]"class="form-control" id="valimgc">
                                            <option value="0">Salah</option>
                                            <option value="5">Benar</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="imgd" class="col-sm-1 col-form-label">D. </label>
                                    <div class="col-sm-9">
                                        <input type="file" name="img[]" class="custom-file-input" id="imgd" value="">
                                        <label class="custom-file-label imgd" for="imgd">Choose file</label>
                                        <small class="itembox">File sebelumnya : <span id="itemd"></span></small>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="valimg[]" class="form-control" id="valimgd">
                                            <option value="0">Salah</option>
                                            <option value="5">Benar</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row mt-1">
                                    <label for="imge" class="col-sm-1 col-form-label">E. </label>
                                    <div class="col-sm-9">
                                        <input type="file" name="img[]" class="custom-file-input" id="imge" value="">
                                        <label class="custom-file-label imge" for="imge">Choose file</label>
                                        <small class="itembox">File sebelumnya : <span id="iteme"></span></small>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="valimg[]" class="form-control" id="valimge">
                                            <option value="0">Salah</option>
                                            <option value="5">Benar</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-12 mb-0 pb-0">
                        <div class="form-group row mt-1" id="form_jawaban">
                            <label for="jawaban" class=" col-form-label ml-3">Penjelasan Jawaban</label>
                            <div class="col-sm-12">
                                <textarea rows="2" class="form-control" name="answer" id="jawaban" placeholder="masukan jawaban terkait soal bukan abjad" ></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-0 pt-0">
                        <button type="submit" class="btn btn-primary pull-right"><span id="submit"><i class="fa fa-plus"></i> Tambah Soal</span> </button>
                    </div>
                </div>
            </div>
        
        </form>
    </div>
</div>
@endsection

@section('js')
<script src="{{url('assets/plugins/summernote/dist/summernote-bs4.min.js')}}"></script>

@if ($errors->any())
    <script>
        $("#modalQuestion").modal('show');        
    </script>
@endif

@if(session('status_question'))
    <script>
        function notification() {
            Lobibox.notify('{{session('type')}}', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'center top',
                icon: '{{session('icon')}}',
                msg: '{{session('status')}}'
            });
        };
        notification();
    </script>
@endif

<script>
    $('#lpackage').addClass('active');
    $('#lhpackage').addClass('active');

    var list=['a','b','c','d','e'];

    //view awal modal
    $('#choice_type').prop('checked',false);
    $('.choice-img').hide();
    $('.choice').change(function(){
        var choice=$('input[name="choice_type"]:checked').val();
        if(choice=='true'){
            $('.choice-text').hide();
            $('.choice-img').show();
        }else{
            $('.choice-img').hide();
            $('.choice-text').show();
        }
    })
    
    function addform() {
        $("#modalQuestion").modal('show');
        $('.itembox').hide();
        $('#title').html('Tambah Soal');
        $('#submit').html('<i class="fa fa-plus"></i> Tambah');
        $('#question_package').val('');
		// $('#desc').text('');
        $('.note-editable').html('');
        $('input[name$="_method"]').val('POST');
        $('#form_question').attr('action',"{{url('question')}}");

        //mengosongkan value
        $('#soal').text('');
        $('#jawaban').text('');
        $('#old_question_image_box').html("")

        //mengosongkan jawaban text dan gambar
        for (let i = 0; i < list.length; i++) {
            $('#text'+list[i]).text('');
            $('#valtext'+list[i]).val('0');
            $('#item'+list[i]).html('');
            $('#valimg'+list[i]).val('0');
        }
    }

    $('body').on("click",".delete-question", function() {
        var current_object=$(this);
        swal({
            title: "Apa kamu yakin?",
            text: "anda akan menghapus semua soal yang terdapat pada paket ini",
            type: "error",
            showCancelButton:true,
            dangerMode:true,
            cancelButtonClass:'#DD5B55',
            confirmButtonColor:'#dc3545',
            confirmButtonText:'Delete!',
        },function(result){
            if(result){
                var action=current_object.attr('data-action');
                var token = jQuery('meta[name="csrf-token"]').attr('content');
                var id=current_object.attr('data-id');

                $('body').html("<form class='form-inline delete-question' method='post' action='"+action+"'></form>");
                $('body').find('.delete-question').append('<input name="_method" type="hidden" value="delete">');
                $('body').find('.delete-question').append('<input name="_token" type="hidden" value="'+token+'">');
                $('body').find('.delete-question').append('<input name="id" type="hidden" value="'+id+'">');
                $('body').find('.delete-question').submit();
            }
        });
    });

    function editPackageForm(id){
        $("#modalQuestion").modal('show');
        $('#title').html('Edit Soal');
        $('#submit').html('<i class="fa fa-edit"></i> Edit');
        $('input[name$="_method"]').val('PATCH');
        $('#form_question').attr('action',"{{url('question')}}/"+id);
        $('input[name$="_method"]').val('PATCH');

        $.ajax({
            url: "{{url('question').'/'}}" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                console.log(data);
                $('#form_soal .note-editable').html(data[0].question);
                $('#form_jawaban .note-editable').html(data[0].answer);
                $('#question_type').val(data[0].id_question_type);
                
                if(data[0].question_image!=""){
                    $('#old_question_image_box').html(`
                        <img src="{{url('img/question/`+data[0].question_image+`') }}" class="logo-icon" alt=''>
                        <a href="{{ url('img/question/`+data[0].question_image+`') }}" target="_blank" >`+data[0].question_image+`'</a>
                        <input type="hidden" name="old_question_image" value="`+data[0].question_image+`">
                    `);
                }else{
                    $('#old_question_image_box').html("")
                }
                
                if(data[0].choice_type=='text'){
                    //jawaban text
                    $('.choice-img').hide();
                    $('.choice-text').show();
                    $('#choice_type').prop('checked',false);
                    $('.itembox').hide();
                    $('input[type=checkbox]').prop('checked', false);

                    //mengisi jawaban text
                    for (let i = 0; i < list.length; i++) {
                        $('#text'+list[i]).text(data[1][i].choice);
                        if(data[1][i].value){
                            $('#valtext'+list[i]).prop('checked', true);
                        }
                    }
                }else{
                    //jawaban img
                    $('.choice-text').hide();
                    $('.choice-img').show();
                    $('#choice_type').prop('checked',true);
                    $('.itembox').show();

                    //mengisi jawaban gambar
                    for (let i = 0; i < list.length; i++) {
                        $('#item'+list[i]).html(`
                            <img src="{{url('img/question/`+data[1][i].choice+`') }}" class="logo-icon" alt=''>
                            <a href="{{ url('img/question/`+data[1][i].choice+`') }}" target="_blank" >`+data[1][i].choice+`'</a>
                            <input type="hidden" name="old_img[`+i+`]" value="`+data[1][i].choice+`">
                        `);
                        $('#valimg'+list[i]).val(data[1][i].value);
                    }
                }
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                console.log('Error - ' + errorMessage);
            }
        });
    }

    $('input[name="question_image"]').change(function(e) {
        var filename = e.target.files[0].name;
        $('.question_image').html(filename);
    });

    for (let i = 0; i < list.length; i++) {
        $('#img'+list[i]).change(function(e) {
            var filename = e.target.files[0].name;
            $('.img'+list[i]).html(filename);
        });
    }

    $('#soal').summernote({
        height: 100,
        tabsize: 2,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link', 'picture']],
        ]
    });

    $('#jawaban').summernote({
        height: 100,
        tabsize: 2,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link', 'picture']],
        ]
    });
</script>
@endsection