@extends('layouts.main')
@section('title','Pengelolaan Soal')

@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="assets/plugins/notifications/css/lobibox.min.css"/>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-6 mb-4">
        <button onclick="addform()" class="btn btn-primary waves-effect waves-light m-1"><i class="fa fa-plus mr-1"></i>Tambah Tipe Soal</button>
    </div>
    <div class="col-lg-12">
        <div class="row">
            @php
                $i=0;
            @endphp
            @foreach ($questionTypes as $questiontype)
                @php
                    $color=['info','success','danger','primary','warning','dark','secondary'];
                    if($i==count($color)-1){
                        $i=0;
                    }else{
                        $i++;
                    }
                @endphp
                <div class="col-lg-4">
                    <div class="card  border border-{{$color[$i]}}">
                        <div class="card-body">
                            <h5 class="card-title text-{{$color[$i]}}">{{$questiontype->question_type}}</h5>
                            <p class="card-text">{{$questiontype->desc}}</p>
                            <h6><span class="text-{{$color[$i]}}">Passing Grade :</span> {{$questiontype->passing_grade}} %</h6>
                            <hr>
                            <div class="row">
                                <div class="col-lg-12">
                                    <button class="btn-sm delete-type btn btn-outline-{{$color[$i]}} waves-effect waves-light " data-id="{{$questiontype->id}}" data-action="{{route('type.destroy',$questiontype->id)}}"> <i class="fa fa-trash-o fa-2x"></i> </button>
                                    <button class="btn-sm btn btn-outline-{{$color[$i]}} waves-effect waves-light" onclick="editTypeForm({{$questiontype->id}})"> <i class="fa fa-edit fa-2x"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>


{{-- Modals --}}
<div class="modal fade" id="modalType">
    <div class="modal-dialog">
        <form id="form_type" action="{{url('type')}}" method="POST">
            @csrf
            {{method_field('')}}
            <div class="modal-content animated fadeInUp">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Tipe Soal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" value="">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="form-group">
                                <label for="question_type">Nama Tipe Paket</label>
                                <input type="text" class="form-control @error('question_type') is-invalid @enderror" id="question_type" placeholder="masukan tipe soal" name="question_type" value="{{ old('question_type') }}" autocomplete="off" autofocus>
                                @error('question_type')
                                    <small for="quetion_type" class="error">{{$message}}</small>
                                @enderror
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label for="passing_grade">Passing Grade(%)</label>
                                <input type="number" class="form-control @error('passing_grade') is-invalid @enderror" id="passing_grade" placeholder="masukan passing grade(%)" name="passing_grade" value="{{ old('passing_grade') }}" autocomplete="off" autofocus>
                                @error('passing_grade')
                                    <small for="passing_grade" class="error">{{$message}}</small>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="desc">Keterangan</label>
                        <textarea rows="4" class="form-control" id="desc" placeholder="masukan keterangan tipe soal" name="desc">{{ old('desc') }}</textarea>
                    </div>
                    <small class="error text-justify">Note: Passing Grade diambil berapa persen soal yang harus benar dari keseluruhan soal pada tipe yang sama.</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary"><span id="submit"><i class="fa fa-plus"></i> Tambah Tipe Soal</span> </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('js')
{{-- notification --}}

@if ($errors->any())
    <script>
        $("#modalType").modal('show');        
    </script>
@endif

<script>
    function addform() {
        $("#modalType").modal('show');
        $('.modal-title').html('Tambah Tipe Soal');
        $('#submit').html('<i class="fa fa-plus"></i> Tambah');
        $('#question_type').val('');
        $('#passing_grade').val('');
		$('#desc').text('');
        $('input[name$="_method"]').val('POST');
        $('#form_type').attr('action',"{{url('type')}}");
    }

    $('body').on("click",".delete-type", function() {
        var current_object=$(this);
        swal({
            title: "Apa kamu yakin?",
            text: "sekali terhapus, tipe soal ini akan terhapus!",
            type: "error",
            showCancelButton:true,
            dangerMode:true,
            cancelButtonClass:'#DD5B55',
            confirmButtonColor:'#dc3545',
            confirmButtonText:'Delete!',
        },function(result){
            if(result){
                var action=current_object.attr('data-action');
                var token = jQuery('meta[name="csrf-token"]').attr('content');
                var id=current_object.attr('data-id');

                $('body').html("<form class='form-inline delete-type' method='post' action='"+action+"'></form>");
                $('body').find('.delete-type').append('<input name="_method" type="hidden" value="delete">');
                $('body').find('.delete-type').append('<input name="_token" type="hidden" value="'+token+'">');
                $('body').find('.delete-type').append('<input name="id" type="hidden" value="'+id+'">');
                $('body').find('.delete-type').submit();
            }
        });
    });

    function editTypeForm(id){
        $("#modalType").modal('show');
        $('.modal-title').html('Edit Tipe Soal');
        $('#submit').html('<i class="fa fa-edit"></i> Edit');
        $('#form_type').attr('action',"{{url('type')}}/"+id);
        $('input[name$="_method"]').val('PATCH');
        $('input[name$="id"]').val(id);

        $.ajax({
			url: "{{url('gettype').'/'}}" + id,
			type: "GET",
			dataType: "JSON",
			success: function(data) {
				$('#question_type').val(data.question_type);
				$('#passing_grade').val(data.passing_grade);
				$('#desc').text(data.desc);
			},
			error: function(xhr, status, error) {
				var errorMessage = xhr.status + ': ' + xhr.statusText
				console.log('Error - ' + errorMessage);
			}
		});
    }

    setTimeout(function(){
        $('#notification').slideUp();
    },3000 );
</script>
@endsection