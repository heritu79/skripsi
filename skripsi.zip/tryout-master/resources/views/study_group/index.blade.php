@extends('layouts.main')
@section('title','Pengelolaan Kelas')

@section('css')
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title mb-4">
            Daftar Kelas
            <button class="btn btn-primary btn-sm float-right" id="create-class" data-toggle="modal" data-target="#create-class-modal">Tambah Kelas</button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Wali Kelas</th>
                        <th scope="col">Jumlah Siswa</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($kelas as $kelas)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$kelas->name}}</td>
                            <td>{{isset($kelas->wali_kelas->user->name) ? $kelas->wali_kelas->user->name : ''}}</td>
                            <td>{{count($kelas->students)}}</td>    
                            <td>
                                <span style="cursor:pointer" class="badge badge-danger delete-class" onclick="deleteKelas({{$kelas->id}})">Delete</span>
                                <span style="cursor:pointer" class="badge badge-warning select-homeroom" onclick="selectHomeroom({{$kelas->id}})">Ganti Wali Kelas</span>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<form id="delete-class-form" action="/class" method="post">
    @method('delete')
    @csrf
</form>
<div class="modal fade" id="homeroom">
    <div class="modal-dialog">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Ganti Wali Kelas</h5>
            </div>
            <form action="/homeroom/change" method="post" id="homeroom-form">
                <div class="modal-body row">
                    @method('patch')
                    @csrf
                    <input type="hidden" name="">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Wali Kelas :</label>
                            <select class="custom-select" name="teacher_id">
                                <option selected disabled>Pilih Guru</option>
                                @foreach($teachers as $teacher)
                                <option value="{{$teacher->id}}">{{$teacher->user->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-sm float-right">Ganti</button>
                </div>
            </form>
        </div>
    </div>
</div>
{{-- modal form --}}
<div class="modal fade" id="create-class-modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Kelas</h5>
            </div>
            <form action="/class" method="post">
                <div class="modal-body row">
                    @csrf
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <label>Nama Kelas : </label>
                            <input type="text" class="form-control" name="name" autocomplete="off" placeholder="Masukan Nama Kelas">
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <label>Wali Kelas :</label>
                            <select class="custom-select" name="homeroom_teacher_id">
                                <option selected disabled>Pilih Guru</option>
                                @foreach($teachers as $teacher)
                                <option value="{{$teacher->id}}">{{$teacher->user->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-sm float-right" id="store-class">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('js')
    <!--Data Tables js-->
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

    <script>
        $('#default-datatable').DataTable();

        function deleteKelas(id){
            console.log(id)
            $('#delete-class-form').attr('action', '/class/'+id)
            $('#delete-class-form').submit()
        }

        function selectHomeroom(id){
            $('#homeroom').modal('show')
            $('#homeroom-form').attr('action', '/homeroom/change/'+id)
        }
    </script>
@endsection