@extends('layouts.auth')
@section('title','Login Page')

@section('content')

<div class="card-content p-2">
    <div class="text-center">
        <img src="{{url('/img/logo.png')}}" class="ml-3 mt-2" style="width:200px; height:auto" alt="logo icon">
    </div>
    <div class="card-title text-uppercase text-center py-3">Halaman Login</div>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="exampleInputUsername" class="sr-only">Username</label>
                <input id="username" type="text" class="form-control @error('username') is-invalid @enderror form-control-rounded" name="username" value="{{ old('username') }}" required autocomplete="username" autofocus placeholder="Username">
                <div class="form-control-position">
                    <i class="icon-user"></i>
                </div>
            </div>
            @error('username')
                <p class="text-danger ml-3">
                    <small>{{ $message }}</small>
                </p>
            @enderror
        </div>
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="password" class="sr-only">Password</label>
                <input id="password" type="password"  class="form-control @error('password') is-invalid @enderror form-control-rounded" name="password" required autocomplete="current-password" placeholder="Password">
                <div class="form-control-position">
                    <i class="icon-lock"></i>
                </div>
            </div>
            @error('password')
                <p class="text-danger ml-3">
                    <small>{{ $message }}</small>
                </p>
            @enderror
        </div>
        <div class="form-row mr-0 ml-0">
            <div class="form-group col-6">
                <div class="icheck-primary">
                    <input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                    <label class="form-check-label" for="remember">
                        {{ __('Remember Me') }}
                    </label>
                </div>
            </div>
            <div class="form-group col-6 text-right">
                <a href="{{ route('password.request') }}">Reset Password</a>
            </div>
        </div>
        <button type="submit" class="btn btn-primary shadow-primary btn-round btn-block waves-effect waves-light">Login</button>
    </form>
</div>
@endsection
