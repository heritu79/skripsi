@extends('layouts.auth')
@section('title','Reset Password')

@section('css')
    <link rel="icon" href="{{'../assets/images/favicon.ico'}}" type="image/x-icon">
    <link href="{{'../assets/css/bootstrap.min.css'}}" rel="stylesheet" />
    <link href="{{'../assets/css/animate.css'}}" rel="stylesheet" type="text/css" />
    <link href="{{'../assets/css/icons.css'}}" rel="stylesheet" type="text/css" />
    <link href="{{'../assets/css/app-style.css'}}" rel="stylesheet" />
@endsection

@section('content')
<div class="card-content p-2">
    <div class="card-title text-uppercase text-center pb-2">Reset Password</div>
    <p class="text-center pb-2">Silahkan masukan email kamu disini. Kamu akan mendapatkan link untuk membuat password baru lewat email.</p>
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif
    <form method="POST" action="{{ route('password.email') }}"> 
        @csrf
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="email" class="sr-only">Email Address</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror form-control-rounded" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Masukan email">

                <div class="form-control-position">
                    <i class="icon-envelope-open"></i>
                </div>
            </div>
            @error('email')
                <p class="text-danger ml-3">
                    <small>{{ $message }}</small>
                </p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary shadow-primary btn-round btn-block waves-effect waves-light mt-3">Reset Password</button>
        <div class="text-center pt-3">
            <hr>
            <p class="text-muted">Kembali ke halaman <a href="{{ route('login') }}"> Login</a></p>
        </div>
    </form>
</div>
@endsection

@section('js')
    <script src="{{'../assets/js/jquery.min.js'}}"></script>
    <script src="{{'../assets/js/popper.min.js'}}"></script>
    <script src="{{'../assets/js/bootstrap.min.js'}}"></script>
@endsection