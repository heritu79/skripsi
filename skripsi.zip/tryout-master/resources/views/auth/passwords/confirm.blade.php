@extends('layouts.auth')
@section('title','Confirm Password')

@section('css')
    <link rel="icon" href="{{'../assets/images/favicon.ico'}}" type="image/x-icon">
    <link href="{{'../assets/css/bootstrap.min.css'}}" rel="stylesheet" />
    <link href="{{'../assets/css/animate.css'}}" rel="stylesheet" type="text/css" />
    <link href="{{'../assets/css/icons.css'}}" rel="stylesheet" type="text/css" />
    <link href="{{'../assets/css/app-style.css'}}" rel="stylesheet" />
@endsection

@section('content')
<div class="card-content p-2">
    <div class="card-title text-uppercase text-center pb-2">Confirm Password</div>
    <p class="text-center pb-2">Untuk keamanan masukan password untuk melanjutkan masuk ke fitur ini.</p>
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif
    <form method="POST" action="{{ route('password.confirm') }}"> 
        @csrf
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="password" class="sr-only">Password</label>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror form-control-rounded" name="password" required autocomplete="new-password" placeholder="Masukan Password" autofocus>
                <div class="form-control-position">
                    <i class="icon-lock"></i>
                </div>
            </div>
            @error('password')
            <p class="text-danger ml-3">
                <small>{{ $message }}</small>
            </p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary shadow-primary btn-round btn-block waves-effect waves-light mt-3">Confirm</button>
        <div class="text-center pt-3">
            <a href="{{ route('password.request') }}">Reset Password</a>
        </div>
    </form>
</div>
@endsection

@section('js')
    <script src="{{'../assets/js/jquery.min.js'}}"></script>
    <script src="{{'../assets/js/popper.min.js'}}"></script>
    <script src="{{'../assets/js/bootstrap.min.js'}}"></script>
@endsection