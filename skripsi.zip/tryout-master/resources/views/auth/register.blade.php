@extends('layouts.auth')
@section('title','Registration Page')

@section('content')
<div class="card-content p-2">
    <div class="text-center">
        <img src="{{url('/img/logo.png')}}" class="ml-3 mt-2" style="width:200px; height:auto" alt="logo icon">
    </div>
    <div class="card-title text-uppercase text-center py-3">Sign Up</div>
    <form method="POST" action="{{ route('register') }}">
        @csrf
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="name" class="sr-only">Name</label>
                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror form-control-rounded" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus placeholder="Name">

                <div class="form-control-position">
                    <i class="icon-user"></i>
                </div>
            </div>
            @error('name')
            <p class="text-danger ml-3">
                <small>{{ $message }}</small>
            </p>
            @enderror
        </div>
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="email" class="sr-only">Email ID</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror form-control-rounded" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="Email">
                <div class="form-control-position">
                    <i class="icon-envelope-open"></i>
                </div>
            </div>
            @error('email')
            <p class="text-danger ml-3">
                <small>{{ $message }}</small>
            </p>
            @enderror
        </div>
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="password" class="sr-only">Password</label>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror form-control-rounded" name="password" required autocomplete="new-password" placeholder="Password">
                <div class="form-control-position">
                    <i class="icon-lock"></i>
                </div>
            </div>
            @error('password')
            <p class="text-danger ml-3">
                <small>{{ $message }}</small>
            </p>
            @enderror
        </div>
        <div class="form-group">
            <div class="position-relative has-icon-right">
                <label for="password-confirm" class="sr-only">Confirm Password</label>
                <input id="password-confirm" type="password" class="form-control form-control-rounded" name="password_confirmation" required autocomplete="new-password" placeholder="Ulangi Password">

                <div class="form-control-position">
                    <i class="icon-lock"></i>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary shadow-primary btn-round btn-block waves-effect waves-light">Submit</button>
        <div class="text-center pt-3">
            <p class="text-muted">Sudah punya akun? <a href="{{ route('login') }}"> Login disini</a></p>
        </div>
    </form>
</div>
@endsection