@extends('layouts.nosidebar')
@section('title','Verifikasi Email')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body">
                    <div class="card-title">Verifikasi Alamat Email.</div>
                    @if (session('resent'))
                        <div class="alert alert-success" role="alert">
                            {{ __('Link verifikasi varu telah dikirim ke email kamu.') }}
                        </div>
                    @endif

                    Sebelum mengakses aplikasi secara penuh, silahkan cek email untuk verifikasi email.
                    Jika anda tidak mendapatkan link verfikasi,
                    <form class="d-inline" method="POST" action="{{ route('verification.resend') }}">
                        @csrf
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline">{{ __('klik disini untuk mendapatkan link verifikasi') }}</button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
