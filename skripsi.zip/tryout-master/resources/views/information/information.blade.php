@extends('layouts.main')

@section('title','Pengelolaan Informasi')
@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="{{url('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')}}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{url('assets/plugins/summernote/dist/summernote-bs4.css')}}"/>
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<button onclick="addform()" class="btn btn-primary waves-effect waves-light mb-2"><i class="fa fa-plus mr-1"></i>Tambah Informasi</button>

<div class="card">
    <div class="card-body">
        <div class="card-title">
            List Informasi Sekolah
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col" width="5%">#</th>
                        <th scope="col" width="20%">Judul Informasi</th>
                        <th scope="col" width="50%">Isi Informasi</th>
                        <th scope="col" width="20%">Tanggal Informasi</th>
                        <th scope="col" width="5%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($informations as $information)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$information->information_header}}</td>
                            <td style="white-space:pre-wrap;word-wrap:break-word;">{!!$information->information_body!!}</td>
                            <td>{{$information->timeline_date}}</td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" onclick="editInformationForm({{$information->id}})" class="btn btn-sm btn-outline-primary waves-effect waves-light "><i class="fa fa-edit fa-2x" ></i></button>
                                    <button type="button" class="btn btn-sm delete-information btn-outline-danger waves-effect waves-light data-id="{{$information->id}}" data-action="{{route('information.destroy',$information->id)}}"><i class="fa fa-trash-o fa-2x"></i></button>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- modal form --}}
<div class="modal fade" id="modalInformation">
    <div class="modal-dialog modal-lg">
        <form id="form_information" action="{{url('information')}}" method="POST">
            @csrf
            {{method_field('')}}
            <div class="modal-content animated fadeInUp">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Informasi Sekolah</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body row">
                    <div class="form-group col-lg-8">
                        <input type="hidden" name="id" value="">
                        <label for="information_header">Judul Informasi</label>
                        <input type="text" class="form-control @error('information_header') is-invalid @enderror" id="information_header" placeholder="masukan judul informasi" name="information_header" value="{{ old('information_header') }}" autocomplete="off" autofocus>
                        @error('information_header')
                            <small for="information_header" class="error">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="col-lg-4">
                        <label>Tanggal Informasi</label>
                        <input type="text" id="timeline_date" class="form-control mb-3" placeholder="masukan tanggal informasi" name="timeline_date" value="{{ old('timeline_date') }}" autocomplete="off">
                    </div>
                    <div class="col-lg-12">
                        <textarea id="information_body" placeholder="masukan informasi" name="information_body"></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary"><span id="submit"><i class="fa fa-plus"></i> Tambah Paket</span> </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection

@section('js')
<script src="{{url('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{url('assets/plugins/summernote/dist/summernote-bs4.min.js')}}"></script>
<!--Data Tables js-->
<script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

<script>
    $('#default-datatable').DataTable();
</script>

@if ($errors->any())
    <script>
        $("#modalInformation").modal('show');        
    </script>
@endif

<script>
    function addform() {
        $("#modalInformation").modal('show');
        $('.modal-title').html('Tambah Informasi Sekolah');
        $('#submit').html('<i class="fa fa-plus"></i> Tambah');
        $('#information_header').val('');
        $('.note-editable').html('');
		$('#timeline_date').val('');
        $('input[name$="_method"]').val('POST');
        $('#form_information').attr('action',"{{url('information')}}");
    }

    function editInformationForm(id){
        $("#modalInformation").modal('show');
        $('.modal-title').html('Edit Informasi Sekolah');
        $('#submit').html('<i class="fa fa-edit"></i> Edit');
        $('#form_information').attr('action',"{{url('information')}}/"+id);
        $('input[name$="_method"]').val('PATCH');
        $('input[name$="id"]').val(id);

        $.ajax({
			url: "{{url('information').'/'}}" + id,
			type: "GET",
			dataType: "JSON",
			success: function(data) {
				$('#information_header').val(data.information_header);
				$('#timeline_date').val(data.timeline_date);
				$('.note-editable').html(data.information_body);
			},
			error: function(xhr, status, error) {
				var errorMessage = xhr.status + ': ' + xhr.statusText
				console.log('Error - ' + errorMessage);
			}
		});
    }

    $('body').on("click",".delete-information", function() {
        var current_object=$(this);
        swal({
            title: "Apa kamu yakin?",
            text: "mengapus informasi yang telah diberikan kepada pengguna!",
            type: "error",
            showCancelButton:true,
            dangerMode:true,
            cancelButtonClass:'#DD5B55',
            confirmButtonColor:'#dc3545',
            confirmButtonText:'Delete!',
        },function(result){
            if(result){
                var action=current_object.attr('data-action');
                var token = jQuery('meta[name="csrf-token"]').attr('content');
                var id=current_object.attr('data-id');

                $('body').html("<form class='form-inline delete-information' method='post' action='"+action+"'></form>");
                $('body').find('.delete-information').append('<input name="_method" type="hidden" value="delete">');
                $('body').find('.delete-information').append('<input name="_token" type="hidden" value="'+token+'">');
                $('body').find('.delete-information').append('<input name="id" type="hidden" value="'+id+'">');
                $('body').find('.delete-information').submit();
            }
        });
    });

    $('#timeline_date').datepicker({
        autoclose: true,
        todayHighlight: true
    });

    $('#information_body').summernote({
        height: 100,
        tabsize: 2,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['para', ['ul', 'ol', 'paragraph']],
        ]
    });
</script>

@endsection