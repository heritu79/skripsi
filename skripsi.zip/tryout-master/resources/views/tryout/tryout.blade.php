@extends('layouts.nosidebar')

@section('content')
<form action="{{route('tryout.store')}}" method="post" id="form">
    @csrf
    <input type="hidden" name="id_question_package" value="{{$question_package->id}}">
    <div class="row">
        <div class="col-lg-8">
            @php
                $i=1;
            @endphp
            @foreach ($questions as $question)
            <div class="card question" id="q{{$loop->iteration}}">
                <div class="card-body">
                    @if (!$loop->last)
                        <button type="button" class="btn btn-light btn-sm pull-right mx-1" onclick="show({{$loop->iteration+1}})"><i class="ti-angle-right"></i></button>
                    @endif
                    @if (!$loop->first)
                        <button type="button" class="btn btn-light btn-sm pull-right mx-1" onclick="show({{$loop->iteration-1}})"><i class="ti-angle-left"></i></button>
                    @endif
                    <p class="card-text"><b>{{$loop->iteration}}.</b> {!!$question->question!!}</p>
                    @if ($question->question_image != '')
                        <img src="{{url('img/question/'.$question->question_image)}}" style="width:auto;height:100%;max-height:250px" class="card-img-top" alt=''>
                    @endif
                    </div>
                    <ul class="list-group list-group-flush list shadow-none">
                        @php
                            $choices=DB::table('question_choices')
                                    ->where('id_question',$question->id)
                                    ->get();
                        @endphp
                        @foreach ($choices as $choice)
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="icheck-primary">
                                    <input type="radio" id="{{$choice->id}}" name="answers[{{$i}}]" value="{{$choice->id}}" @if (old('answers.'.$i) == $choice->id)
                                        checked
                                    @endif>
                                    <label for="{{$choice->id}}" class="text-lowercase" style="font-size:15px">
                                        @if ($question->choice_type=='text')
                                            {!!$choice->choice!!}
                                        @else
                                            <img src="{{url('img/question/'.$choice->choice)}}" class="card-img-top" style="width:auto;height:100%; max-height:200px">
                                        @endif
                                    </label>
                                </div>
                            </li>
                        @endforeach
                    </ul>
                </div>
                @php
                    $i++;
                @endphp
            @endforeach
        </div>
        <div class="col-lg-4">
            <div class="card" >
                <div class="card-header">
                    Sisa Waktu : <span id="countdown"></span>
                </div>
                <div class="card-body" style="height:450px;overflow:scroll">
                    <div class="row">
                        @foreach ($questions as $question)
                            <div class="col-3">
                                <button type="button" onclick="show({{$loop->iteration}})" class="btn 
                                    @if (old('answers.'.$loop->iteration))
                                        btn-primary
                                    @else
                                        btn-light
                                    @endif
                                     btn-{{$loop->iteration}} my-1 mx-0 btn-block" >{{$loop->iteration}}</button>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="card-footer ">
                    <button type="button" class="submit btn btn-primary float-right mx-2">Selesai</button>
                    <a href="{{route('tryout.index')}}" class="btn btn-danger float-right">Batal</a>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection
@section('js')

<script>
    //fullscreen
    addEventListener("load", function() {
        var el = document.documentElement
            , rfs =
                el.requestFullScreen
                || el.webkitRequestFullScreen
                || el.mozRequestFullScreen
        ;
        rfs.call(el);
    });

    $('.question').addClass('d-none');
    $('#q1').addClass('d-block');

    i=1;
    function show(id){
        $('.question').removeClass('d-block');
        $('#q'+id).addClass('d-block');
        i=id;
    }


    $('body').on("click",".submit", function(){
        swal({
            title: "Apa kamu yakin?",
            text: "anda akan mengirimkan semua jawaban ulangan, pastikan semua jawaban telah terisi dengan benar",
            type: "warning",
            showCancelButton:true,
            dangerMode:true,
            cancelButtonClass:'#DD5B55',
            confirmButtonText:'Kirim Ulangan!',
        },function(result){
            if(result){
                $('body').find('#form').submit();
            }
        });
    })

    @foreach ($questions as $question)
        $('input[name="answers[{{$loop->iteration}}]"]').on('click', function(){
            $('.btn-{{$loop->iteration}}').removeClass('btn-light').addClass('btn-primary');
        });
    @endforeach

    //hitung mundur tryout
    var countDownTime = new Date().getTime()+({{$question_package->tryout_time}}*60*1000);
    
    var x = setInterval(()=>{
        var now = new Date().getTime();
        var distance = countDownTime - now;
        
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
        $('#countdown').text(hours + "h "+ minutes + "m " + seconds + "s");
        
        if (distance < 0) {
            clearInterval(x);
            $('#countdown').html("<span class='text-danger'>Waktu Habis</span>");
        }
    }, 1000);
    
    //waktu tryout berjalan
    setTimeout(() => {
        $('body').find('#form').submit();
        // console.log('boom')
    }, {{$question_package->tryout_time}}*60*1000);

</script>
@endsection