@extends('layouts.main')
@section('title','List Paket Ulangan Online')

@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')

<div class="row">
    @if(session('error'))
        <div class="col-12">  
            <div class="alert alert-danger" role="alert" style="padding: 0.75rem 1.25rem;">
                {{session('error')}}
            </div>
        </div>
    @endif
    <div class="col-lg-12">
        <div class="row">
            @php
                $i=0;
            @endphp
            @foreach ($questionPackages as $questionPackage)
                @php
                    $color=['primary','success','danger','info','warning','dark','secondary'];
                    if($i==count($color)-1){
                        $i=0;
                    }else{
                        $i++;
                    }
                @endphp
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title text-{{$color[$i]}}">{{$questionPackage->question_package}}</h5>
                            <p class="card-text">{{$questionPackage->desc}}</p>
                            @php
                                $question_count=DB::table('questions')
                                        ->where('id_question_package',$questionPackage->id)
                                        ->count();
                            @endphp
                            <p class="card-text">Waktu Pengerjaan: <b>{{$questionPackage->tryout_time}}</b> Menit</p>
                            <p class="card-text">Jumlah Soal : <b>{{$question_count}}</b> Soal</p>
                            @php
                                $question_type_in_question = DB::table('questions')
                                    ->where('id_question_package', '=', $questionPackage->id)
                                    ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
                                    ->distinct()
                                    ->get(['question_type']);
                            @endphp
                            <p class="card-text"> 
                                @foreach ($question_type_in_question as $question_type)
                                    @php
                                        $count_type=DB::table('questions')
                                            ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
                                            ->where('id_question_package',$questionPackage->id)
                                            ->where('question_type',$question_type->question_type)
                                            ->count(['question_type']);
                                    @endphp
                                    | {{$question_type->question_type}} : <b>{{$count_type}}</b> |
                                @endforeach
                            </p>
                            <button data-action="{{route('tryout.show',$questionPackage->id)}}" class="float-right btn btn-{{$color[$i]}} btn-block choose-package shadow-{{$color[$i]}} waves-effect waves-light"><i class="fa fa-edit mr-1"></i>Kerjakan</button>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

@endsection

@section('js')
    <script>
        $('body').on("click",".choose-package", function() {
            var current_object=$(this);
            swal({
                title: "Hallo!!!",
                text: "Sebelum mengerjakan Ulangan Online pastikan internet kamu stabil dan tidak meninggalkan aplikasi selama ulangan, Good Luck :)",
                type: "info",
                showCancelButton:true,
                dangerMode:true,
                cancelButtonClass:'#DD5B55',
                confirmButtonColor:'#0dceec',
                confirmButtonText:'Mulai Ulangan Online',
            },function(result){
                if(result){
                    var action=current_object.attr('data-action');
                    window.location.href=action;
                }
            });
        });
    </script>
@endsection