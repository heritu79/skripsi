@extends('layouts.main')
@section('title','Review Jawaban')


@section('content')

<div class="row">
    <div class="col-lg-8">
        @php
            $i=1;
            $buttonCorrect=[];
        @endphp
        @foreach ($questions as $question)
        <div class="card question" id="q{{$loop->iteration}}">
            <div class="card-body">
                @if (!$loop->last)
                    <button type="button" class="btn btn-light btn-sm pull-right mx-1" onclick="show({{$loop->iteration+1}})"><i class="ti-angle-right"></i></button>
                @endif
                @if (!$loop->first)
                    <button type="button" class="btn btn-light btn-sm pull-right mx-1" onclick="show({{$loop->iteration-1}})"><i class="ti-angle-left"></i></button>
                @endif
                <p class="card-text"><b>{{$loop->iteration}}.</b> {!!$question->question!!}</p>
                @if ($question->question_image != '')
                    <img src="{{url('img/question/'.$question->question_image)}}" style="width:auto;height:100%;max-height:250px" class="card-img-top" alt=''>
                @endif
            </div>
            <ul class="list-group list-group-flush list shadow-none">
                @php
                    $choices=DB::table('question_choices')
                        ->where('id_question',$question->id)
                        ->get();
                @endphp
                @foreach ($choices as $choice)
                    @if($choice->value==5)
                        @php
                            $correct=$choice->id;
                        @endphp
                    @endif
                    <li class="list-group-item d-flex justify-content-between align-items-center @if($choice->value==5) {{'active'}} @endif">
                        <div class="icheck-primary">
                            {{-- <input type="radio" id="{{$choice->id}}" name="answers[{{$i}}]" value="{{$choice->id}}"/> --}}
                            <label for="{{$choice->id}}" class="text-lowercase @if($choice->value==5) {{'text-white'}} @endif" style="font-size:15px" >
                                @if ($question->choice_type=='text')
                                    {{$choice->choice}}
                                @else
                                    <img src="{{url('img/question/'.$choice->choice)}}" class="card-img-top" style="width:auto;height:100%; max-height:200px">
                                @endif
                            </label>
                        </div>
                        <span class="badge badge-light badge-pill">@if($choice->value!=0&&$choice->value!=5){{$choice->value}}@endif</span>
                    </li>
                @endforeach
            </ul>
            <div class="card-body">
                @php
                    $answer=DB::table('user_answers')
                        ->join('question_choices','user_answers.id_question_choice','question_choices.id')
                        ->join('questions','questions.id','question_choices.id_question')
                        ->where('id_user_tryout',$user_tryout->id)
                        ->where('id_question',$question->id)
                        ->first();

                @endphp
                <p class="card-text font-weight-bold">Jawaban Siswa : 
                    @if ($question->choice_type=='text')
                        <span class="
                            @if(empty($answer))
                                text-danger 
                            @else
                                @if($answer->id_question_choice==$correct)
                                    text-success 
                                @else 
                                    text-danger 
                                @endif
                            @endif
                        ">
                            {{ $answer->choice }}
                        </span>
                    @else
                        <img src="{{url('img/question/'.$choice->choice)}}" class="card-img-top" style="width:auto;height:100%; max-height:200px">
                    @endif
                </p>
                <p class="card-text"><b>Penjelasan : </b>
                    {{$question->answer}}
                </p>
                @php
                    if(empty($answer)):
                        $buttonCorrect[$loop->iteration]='warning';
                    else:
                        if($answer->id_question_choice==$correct):
                            $buttonCorrect[$loop->iteration]='success';
                        else:
                            $buttonCorrect[$loop->iteration]='danger';
                        endif;
                    endif;
                @endphp
            </div>

            </div>
            @php
                $i++;
            @endphp
        @endforeach
        
    </div>
    <div class="col-lg-4">
        <div class="card" >
            <div class="card-header">
                Nomor Soal
            </div>
            <div class="card-body" style="height:400px;overflow:scroll">
                <div class="row">
                    @foreach ($questions as $question)
                        <div class="col-3">
                            <button type="button" onclick="show({{$loop->iteration}})" class="btn btn-{{$buttonCorrect[$loop->iteration]}} btn-{{$loop->iteration}} my-1 mx-0 btn-block">{{$loop->iteration}}</button>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="card-body text-center">
                <a href="{{route('review.statistic',$user_tryout->id)}}" class="btn btn-gradient-forest text-white">Lihat Statistik</a>
            </div>
        </div>
    </div>
</div>
@endsection
@section('js')

<script>
    $('#lreview').addClass('active');

    $('.question').addClass('d-none');
    $('#q1').addClass('d-block');

    i=1;
    function show($id){
        $('.question').removeClass('d-block');
        $('#q'+$id).addClass('d-block');
        i=$id;
    }
</script>
@endsection