@extends('layouts.main')
@section('title','Statistik Ulangan Online')

@section('content')
    <div class="card">
        <div class="card-header">
            Statistik Hasil Ulangan Online ({{$user_tryout->question_package->question_package}}) - <span class="text-capitalize">{{$user['name']}}</span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-4 col-sm-12 text-center">
                    <p style="font-size:20px">
                        Hasil
                    </p>
                    @php
                        $result=true;
                        $i=0;
                    @endphp
                    @foreach ($type_in_packages as $type_in_package)                        
                        @php
                            //mendapatkan jawaban berdasarkan tipe soal
                            $score_per_question_type = DB::table('user_answers')
                                ->join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
                                ->where('id_user_tryout', $user_tryout->id)
                                ->join('questions', 'questions.id', '=', 'question_choices.id_question')
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->where('question_type', $type_in_package->question_type)
                                ->get();

                            //medapatkan skor berdasarkan tipe soal
                            $scorePerType = 0;
                            foreach ($score_per_question_type as $score) {
                                $scorePerType += $score->value;
                            }

                            //total score per tipe
                            $totalScorePerType=DB::table('questions')
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->where('id_question_package', '=', $user_tryout->id_question_package)
                                ->where('question_type', $type_in_package->question_type)
                                ->count();

                            $totalScorePerType*=5;
                        @endphp
                        <p>
                            <span class="text-uppercase">{{$type_in_package->question_type}}</span> : <b><span 
                            @if ($scorePerType/$totalScorePerType*100> $type_in_package->passing_grade)
                                class="text-success"
                                <?php
                                    $result=$result&&true;
                                ?>
                            @else
                                class="text-danger"
                                <?php
                                    $result=$result&&false;
                                ?>
                            @endif>{{$scorePerType/5}}</span> / {{$totalScorePerType/5}} Poin</b>
                        </p>
                    @endforeach
                    <p style="font-size:20px">
                        Passing Grade
                    </p>
                    @foreach ($type_in_packages as $type_in_package)
                        @php
                            $totalScorePerType=DB::table('questions')
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->where('id_question_package', '=', $user_tryout->id_question_package)
                                ->where('question_type', $type_in_package->question_type)
                                ->count();

                            $totalScorePerType*=5;
                        @endphp
                        <p>
                            <span class="text-uppercase">{{$type_in_package->question_type}}</span> : <b> {{$type_in_package->passing_grade}} %</b>
                        </p>
                    @endforeach
                </div>
                <div class="col-lg-4 col-sm-12 text-center">
                    <p style="font-size:20px">Skor Akhir</p>
                    @php
                        $score = 0;
                        foreach ($user_scores as $user_score) {
                            $score += $user_score->value;
                        }
                    @endphp 
                    <h3><span
                    @if ($result)
                        class="text-success"
                    @else
                        class="text-danger"
                    @endif>{{$score/5}}</span> / {{$total_score}}</h3>

                    <p style="font-size:20px" class="mt-3">Keterangan</p>
                    <p style="font-size:32px" class="mt-0">
                        @if ($result)
                            <span class="badge badge-success">LULUS</span>
                        @else
                            <span class="badge badge-danger">TIDAK LULUS</span>
                        @endif
                    </p>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <p style="font-size:20px">Statistik</p>
                    @foreach ($type_in_packages as $type_in_package)                        
                        @php 
                            $score_per_question_type = DB::table('user_answers')
                                ->join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
                                ->where('id_user_tryout', $user_tryout->id)
                                ->join('questions', 'questions.id', '=', 'question_choices.id_question')
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->where('question_type', $type_in_package->question_type)
                                ->get();

                            $scorePerType = 0;
                            foreach ($score_per_question_type as $score) {
                                $scorePerType += $score->value;
                            }

                            $totalScorePerType=DB::table('questions')
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->where('id_question_package', '=', $user_tryout->id_question_package)
                                ->where('question_type', $type_in_package->question_type)
                                ->count();

                            $totalScorePerType*=5;
                            $scoreInPercent=$scorePerType/$totalScorePerType*100;
                        @endphp
                        <p class="mt-3">{{$type_in_package->question_type}} <span class="float-right">{{round($scoreInPercent)}}%</span></p>
                        <div class="progress" style="height: 7px;">
                            @php
                                if ($scorePerType/$totalScorePerType*100> $type_in_package->passing_grade):
                                    $color='success';
                                else:
                                    $color='danger';
                                endif;
                            @endphp
                            <div class="progress-bar bg-{{$color}} progress-bar-striped" role="progressbar" style="width: {{$scoreInPercent}}%"></div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-12 text-center">
            <a href="{{route('review.detail',$user_tryout->id)}}" class="btn btn-gradient-forest text-white">Lihat Jawaban</a>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $('#lreview').addClass('active');
    </script>
@endsection