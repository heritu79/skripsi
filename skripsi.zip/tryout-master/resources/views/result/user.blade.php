@extends('layouts.main')
@section('title','Paket Pengerjaan')

@section('css')
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title">
            List Pengerjaan Siswa
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">NISN</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Tanggal Pengerjaan</th>
                        <th scope="col">Nilai</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        @php
                            $user_scores=DB::table('user_answers')
                                    ->join('question_choices','user_answers.id_question_choice','=','question_choices.id')
                                    ->where('id_user_tryout',$user->tryout[0]->id)
                                    ->get();

                            $score = 0;
                            foreach ($user_scores as $user_score) {
                                $score += $user_score->value;
                            }

                            $total_score = DB::table('questions')
                                ->where('id_question_package', '=', $user->tryout[0]->id_question_package)
                                ->count();

                            //mendapatkan tipe soal yang ada pada paket yang dikerjakan oleh user
                            $type_in_packages = DB::table('questions')
                                ->where('id_question_package', '=', $user->tryout[0]->id_question_package)
                                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                ->distinct()
                                ->get(['question_type', 'passing_grade']);
                            
                            $result=true;
                            foreach ($type_in_packages as $type_in_package) {
                                //mendapatkan jawaban berdasarkan tipe soal
                                $score_per_question_type = DB::table('user_answers')
                                    ->join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
                                    ->where('id_user_tryout', $user->tryout[0]->id)
                                    ->join('questions', 'questions.id', '=', 'question_choices.id_question')
                                    ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                    ->where('question_type', $type_in_package->question_type)
                                    ->get();

                                //medapatkan skor berdasarkan tipe soal
                                $scorePerType = 0;
                                foreach ($score_per_question_type as $score_type) {
                                    $scorePerType += $score_type->value;
                                }

                                $totalScorePerType=DB::table('questions')
                                    ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                                    ->where('id_question_package', '=', $user->tryout[0]->id_question_package)
                                    ->where('question_type', $type_in_package->question_type)
                                    ->count();

                                $totalScorePerType*=5;
                                $scoreInPercent=$scorePerType/$totalScorePerType*100;
                                
                                if ($scorePerType/$totalScorePerType*100> $type_in_package->passing_grade):
                                    $result=$result&&true;
                                else:
                                    $result=$result&&false;
                                endif;
                            }
                        @endphp    
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$user->name}}</td>
                            <td>{{$user->username}}</td> 
                            <td>{{$user["student"]["study_group"]['name']}}</td>    
                            <td>{{date('d F Y', strtotime($user->tryout[0]->created_at))}}</td>
                            <td>{{ round($scoreInPercent) }}</td>
                            <td>
                                @if ($result)
                                    <span class="badge badge-success">LULUS</span>
                                @else
                                    <span class="badge badge-danger">TIDAK LULUS</span>
                                @endif
                            </td>
                            <td>
                                <button class="btn btn-sm btn-danger btn-delete" data-id="{{$user->tryout[0]->id}}">Hapus</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<form id="delete-form" method="post">
    @csrf
    @method('delete')
</form>
@endsection

@section('js')
    <!--Data Tables js-->
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

    <script>
        $('#default-datatable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'excel', 'pdf', 'print'
            ]
        });

        $(document).on('click', '.btn-delete', function(){
            tryout_id = $(this).data('id')
            swal({
                title: "Hapus hasil ujian ?",
                text: "Hasil ujian akan dihapus secara permanen !",
                type: "error",
                showCancelButton:true,
                dangerMode:true,
                cancelButtonClass:'#DD5B55',
                cancelButtonText:'Batal!',
                confirmButtonColor:'#dc3545',
                confirmButtonText:'Hapus!',
            },function(result){
                if(result){
                    $('#delete-form').attr('action', '/tryout/'+tryout_id)
                    $('#delete-form').submit()
                    // $.ajax({
                    //     url: '/tryout/'+tryout_id,
                    //     type: 'delete',
                    //     data: {'_token' : "{{csrf_token()}}"},
                    //     dataType: 'json',
                    //     success: function(response){
                    //         if(response.success){
                    //             location.reload();
                    //         }
                    //     }
                    // })
                }
            });
        })
    </script>
@endsection