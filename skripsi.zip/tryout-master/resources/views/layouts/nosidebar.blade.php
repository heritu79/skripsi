<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from codervent.com/rocker/white-version/authentication-signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 15 Oct 2019 15:30:49 GMT -->

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Ulangan Online</title>
    
    <!-- assets css -->
    <link rel="icon" href="{{url('assets/images/favicon.ico')}}" type="image/x-icon">
    <link href="{{url('assets/css/bootstrap.min.css')}}" rel="stylesheet" />
    <link href="{{url('assets/css/animate.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('assets/css/icons.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('assets/css/app-style.css')}}" rel="stylesheet" />
    <link href="{{url('assets/plugins/sweetalert/sweetalert.min.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{url('assets/plugins/sweetalert/sweetalert.min.js')}}"></script>
    <link rel="stylesheet" href="{{url('assets/plugins/notifications/css/lobibox.min.css')}}"/>

    @yield('css')
</head>

<body>
    <header class="topbar-nav">
        <nav class="navbar navbar-expand fixed-top bg-white">
            <ul class="navbar-nav mr-auto align-items-center">
                <li class="justifiy-content-center ml-2 mt-2 nav-item ">
                    <a href="#">
                        <img src="{{url('/img/logo.png')}}" class="p-0" style="width:200px; height:auto" alt="logo icon">
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav align-items-center right-nav-link">
                <li class="nav-item">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
                        <span class="user-profile"><img src="{{url('img/profile/'.auth()->user()->profile_picture)}}" class="img-circle"  style="width:40px;height:40px;object-fit:cover;overflow:hidden;"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <li class="dropdown-item user-details">
                            <a href="javaScript:void();">
                                <div class="media">
                                    <div class="avatar"><img class="align-self-start mr-3" src="{{url('img/profile/'.auth()->user()->profile_picture)}}"  style="width:40px;height:40px;object-fit:cover;overflow:hidden;"></div>
                                    <div class="media-body">
                                        <h6 class="mt-2 user-title text-capitalize">{{auth()->user()->name}}</h6>
                                        <p class="user-subtitle">{{auth()->user()->email}}</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                                                
                        <li class="dropdown-divider"></li>
                        <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <li class="dropdown-item"><i class="icon-power mr-2"></i> Logout</li>
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>
    <div class="clearfix"></div>

    <div class="my-2 mx-3 content-wrapper">
        @yield('content')
    </div>


    <!-- Bootstrap core JavaScript-->
    <script src="{{url('assets/js/jquery.min.js')}}"></script>
    <script src="{{url('assets/js/popper.min.js')}}"></script>
    <script src="{{url('assets/js/bootstrap.min.js')}}"></script>
        
    <script src="{{url('assets/plugins/notifications/js/lobibox.min.js')}}"></script>
    <script src="{{url('assets/plugins/notifications/js/notifications.min.js')}}"></script>
    @yield('js')

    @if(session('status'))
        <script>
            function notification() {
                Lobibox.notify('{{ session('type') ? session('type') : 'success' }}', {
                    pauseDelayOnHover: true,
                    continueDelayOnInactiveTab: false,
                    position: 'right top',
                    icon: '{{ session('icon') ? session('icon') : 'fa fa-check-circle' }}',
                    msg: '{{session('status')}}'
                });
            };
            notification();
        </script>
    @endif

    <script>
        function validationNotification(errorMessage) {
            Lobibox.notify('error', {
                pauseDelayOnHover: true,
                continueDelayOnInactiveTab: false,
                position: 'right top',
                icon: 'fa fa-times',
                msg: errorMessage
            });
        };
    </script>
    @if ($errors->any())
        @foreach ($errors->all() as $error)
            <script>
                validationNotification("{{$error}}");
            </script>
        @endforeach
    @endif
</body>

<!-- Mirrored from codervent.com/rocker/white-version/authentication-signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 15 Oct 2019 15:30:49 GMT -->

</html>