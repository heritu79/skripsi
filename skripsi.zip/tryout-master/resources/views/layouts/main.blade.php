<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Ulangan Online</title>

    <!-- assets css -->
    {{-- <link rel="icon" href="{{url('assets/images/favicon.ico')}}" type="image/x-icon"> --}}
    <link href="{{url('assets/plugins/simplebar/css/simplebar.css')}}" rel="stylesheet" />
    <link href="{{url('assets/css/bootstrap.min.css')}}" rel="stylesheet" />
    <link href="{{url('assets/css/animate.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('assets/css/icons.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('assets/css/sidebar-menu.css')}}" rel="stylesheet" />
    <link href="{{url('assets/css/app-style.css')}}" rel="stylesheet" />
    <link href="{{url('assets/plugins/sweetalert/sweetalert.min.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{url('assets/plugins/sweetalert/sweetalert.min.js')}}"></script>
    <link rel="stylesheet" href="{{url('assets/plugins/notifications/css/lobibox.min.css')}}"/>

    @yield('css')

</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">
        <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
            <div class="brand-logo">
                <a href="{{url('/')}}">
                    <img src="{{url('/img/logo.png')}}" class="ml-3 mt-2" style="width:200px; height:auto" alt="logo icon">
                </a>
            </div>
            <ul class="sidebar-menu do-nicescrol">
                <li class="sidebar-header">PUBLIC</li>
                <li>
                    <a href="{{url('/')}}" class="waves-effect">
                        <i class="icon-home"></i> <span>Dashboard</span>
                    </a>
                </li>
                @if(auth()->user()->role == 'teacher')
                    <li class="sidebar-header">Guru</li>
                    <li>
                        <a href="{{url('/homeroom')}}">
                            <i class="icon-user"></i>Siswa Kelas
                        </a>
                    </li>
                @endif
                @if (auth()->user()->role=='admin')
                    <li id="">
                        <a href="{{url('/user')}}" class="waves-effect">
                            <i class="icon-user"></i> <span>Pengelolaan Siswa</span>
                        </a>
                    </li>
                    <li id="">
                        <a href="{{url('/teacher')}}" class="waves-effect">
                            <i class="icon-user"></i> <span>Pengelolaan Guru</span>
                        </a>
                    </li>
                    <li id="">
                        <a href="{{url('/class')}}" class="waves-effect">
                            <i class="icon-home"></i> <span>Pengelolaan Kelas</span>
                        </a>
                    </li>
                @endif

                @if (auth()->user()->role=='admin')
                    <li class="sidebar-header">PENGELOLAAN APLIKASI</li>
                @else
                    @if (auth()->user()->role=='user')
                        <li class="sidebar-header">Ulangan Online</li>
                        <li>
                            <a href="{{url('/tryout')}}" class="waves-effect">
                                <i class="icon-grid"></i> <span>Ulangan Online</span>
                            </a>
                        </li>
                    @endif
                @endif
                
                @if (auth()->user()->role=='user')
                    <li class="sidebar-header">FITUR LAINNYA</li>
                @else
                    <li id="lhpackage">
                        <a href="{{url('/package')}}"  class="waves-effect">
                            <i class="icon-list"></i> <span>Pengeloaan Soal</span> <i class="fa fa-angle-left pull-right"></i>
                        </a> 
                        <ul class="sidebar-submenu">
                            @if (auth()->user()->role=='admin')
                                <li id="ltype"><a href="{{url('/type')}}"><i class="fa fa-circle-o"></i> Tipe Soal</a></li>
                            @endif
                            <li id="lpackage"><a href="{{url('/package')}}" ><i class="fa fa-circle-o"></i> Paket Soal</a></li>
                        </ul>
                    </li>
                @endif
                
                <li id="lmodule">
                    <a href="{{url('/module')}}" class="waves-effect">
                        <i class="icon-book-open"></i> <span>Materi</span>
                    </a>
                </li>

                @if (auth()->user()->role=='admin')
                    <li>
                        <a href="{{url('/information')}}" class="waves-effect">
                            <i class="icon-info"></i> <span>Informasi Sekolah</span>
                        </a>
                    </li>
                @endif
            </ul>

        </div>
        <!--End sidebar-wrapper-->

        <!--Start topbar header-->
        <header class="topbar-nav">
            <nav class="navbar navbar-expand fixed-top bg-white">
                <ul class="navbar-nav mr-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link toggle-menu" href="javascript:void();">
                            <i class="icon-menu menu-icon"></i>
                        </a>
                    </li>
                    <li class="justifiy-content-center ml-2 mt-2 nav-item ">
                    </li>
                </ul>

                <ul class="navbar-nav align-items-center right-nav-link">
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
                            <span class="user-profile"><img src="{{url('img/profile/'.auth()->user()->profile_picture)}}" class="img-circle"  style="width:40px;height:40px;object-fit:cover;overflow:hidden;"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li class="dropdown-item user-details">
                                <a href="javaScript:void();">
                                    <div class="media">
                                        <div class="avatar"><img class="align-self-start mr-3" src="{{url('img/profile/'.auth()->user()->profile_picture)}}"  style="width:40px;height:40px;object-fit:cover;overflow:hidden;"></div>
                                        <div class="media-body">
                                            <h6 class="mt-2 user-title text-capitalize">{{auth()->user()->name}}</h6>
                                            <p class="user-subtitle">{{auth()->user()->email}}</p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            
                            <li class="dropdown-divider"></li>
                            <a href="{{route('setting')}}">
                                <li class="dropdown-item"><i class="icon-settings mr-2"></i> Setting</li>
                            </a>
                            <li class="dropdown-divider"></li>
                            <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <li class="dropdown-item"><i class="icon-power mr-2"></i> Logout</li>
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </ul>
                    </li>
                </ul>
            </nav>
        </header>
        <!--End topbar header-->

        <div class="clearfix"></div>

        <div class="content-wrapper">
            <div class="container-fluid">
                <!-- Breadcrumb-->
                <div class="row pt-2 pb-2">
                    <div class="col-lg-6 col-sm-12">
                        <h4 class="page-title">@yield('title')</h4>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javaScript:void();">{{url()->current()}}</a></li>
                        </ol>
                    </div>

                    <div class="col-lg-6 col-sm-12">
                        <!-- <button class="btn btn-primary btn-sm pull-right mt-3">Tambah Siswa</button> -->
                    </div>
                    
                </div>
                <!-- End Breadcrumb-->
                <div class="row">
                    <div class="col-lg-12">
                        @yield('content')
                    </div>
                </div>

            </div>
            <!-- End container-fluid-->

        </div>
        <!--End content-wrapper-->
        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <footer class="footer" style="position:fixed; bottom:0; background-color:whitesmoke;z-index:99">
            <div class="container">
                <div class="text-center">
                    Copyright © 2020 <a target="_blank" href="javascript:voi(0)">GetIdea</a>
                </div>
            </div>
        </footer>
        <!--End footer-->

    </div>
    <!--End wrapper-->


    <!-- Bootstrap core JavaScript-->
    <script src="{{url('assets/js/jquery.min.js')}}"></script>
    <script src="{{url('assets/js/popper.min.js')}}"></script>
    <script src="{{url('assets/js/bootstrap.min.js')}}"></script>

    <!-- simplebar js -->
    <script src="{{url('assets/plugins/simplebar/js/simplebar.js')}}"></script>
    <!-- waves effect js -->
    <script src="{{url('assets/js/waves.js')}}"></script>
    <!-- sidebar-menu js -->
    <script src="{{url('assets/js/sidebar-menu.js')}}"></script>
    <!-- Custom scripts -->
    <script src="{{url('assets/js/app-script.js')}}"></script>
    
    <script src="{{url('assets/plugins/notifications/js/lobibox.min.js')}}"></script>
    <script src="{{url('assets/plugins/notifications/js/notifications.min.js')}}"></script>
    @yield('js')

    @if(session('status'))
        <script>
            function notification() {
                Lobibox.notify('{{ session('type') ? session('type') : 'success' }}', {
                    pauseDelayOnHover: true,
                    continueDelayOnInactiveTab: false,
                    position: 'right top',
                    icon: '{{ session('icon') ? session('icon') : 'fa fa-check-circle' }}',
                    msg: '{{session('status')}}'
                });
            };
            notification();
        </script>
    @endif
</body>


</html>