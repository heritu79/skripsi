@extends('layouts.main')

@section('title','Materi')

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title">
            {{$module->module_header}}
        </div>
        <p>{!!$module->module_body!!}</p>

        <div class="row">
            @foreach ($module_files as $file)
                <div class="col-lg-4 col-sm-12">
                    <a href="{{url('modules/'.$file->file)}}" target="_blank" class="btn btn-link">{{$file->file}}</a>
                </div>
            @endforeach
        </div>
    </div>
</div>
@if($module->type == 'Dengan Tugas')
    @if($module->answer())
    <div class="card">
        <div class="card-body">
            <div class="card-title">
                Jawaban
            </div>
            <div class="row">
                <div class="col-12">
                    {{$module->answer()->answer}}
                </div>
                @if($module->answer()->file)
                <div class="col-12 my-3">
                    <a href="{{url('modules/'.$file->file)}}" target="_blank" class="btn btn-link">Lampiran Jawaban</a>
                </div>
                @endif
            </div>
        </div>
    </div>
    @else
    <div class="card">
        <div class="card-body">
            <form action="/module-answer" method="post" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="module_id" value="{{$module->id}}">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="answer">Jawaban</label>
                            <textarea class="form-control" id="answer" rows="3" name="answer"></textarea>
                        </div>
                    </div>
                    <div class="col-12 mb-4">
                        <label for="file" class="col-form-label">Upload File Jawaban</label>
                        <div class="custom-file custom-file-sm ">
                            <input type="file" name="file" class="custom-file-input" id="file">
                            <label class="custom-file-label" for="file">Pilih file</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-sm btn-primary float-right">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @endif
@endif
@endsection

@section('js')
    <script>
        $('#lmodule').addClass('active');
    </script>
@endsection