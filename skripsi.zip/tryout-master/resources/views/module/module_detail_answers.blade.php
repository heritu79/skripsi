@extends('layouts.main')

@section('title','Materi')

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title">
            {{$module->module_header}}
        </div>
        <p>{!!$module->module_body!!}</p>

        <div class="row">
            @foreach ($module_files as $file)
                <div class="col-lg-4 col-sm-12">
                    <a href="{{url('modules/'.$file->file)}}" target="_blank" class="btn btn-link">{{$file->file}}</a>
                </div>
            @endforeach
        </div>
    </div>
</div>
@forelse ($module->answers as $answer)
<div class="card">
    <div class="card-body">
        <div class="card-title">
            Jawaban {{$answer->user->name}}
        </div>
        <div class="row">
            <div class="col-12">
                {{$answer->answer}}
            </div>
            @if($answer->file)
            <div class="col-12 my-3">
                <a href="{{url('modules/'.$file->file)}}" target="_blank" class="btn btn-link">Lampiran Jawaban</a>
            </div>
            @endif
        </div>
    </div>
</div>
@empty
<div class="card">
    <div class="card-body">
        <div class="card-title text-center">
            Belum ada siswa yang menjawab !
        </div>
        </div>
    </div>
</div>
    
@endforelse
@endsection

@section('js')
    <script>
        $('#lmodule').addClass('active');
    </script>
@endsection