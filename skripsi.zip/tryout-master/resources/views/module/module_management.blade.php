@extends('layouts.main')

@section('title','Pengelolaan Materi')
@section('css')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{url('assets/plugins/summernote/dist/summernote-bs4.css')}}" />
<link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
<link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<button onclick="addform()" class="btn btn-primary waves-effect waves-light mb-2"><i class="fa fa-plus mr-1"></i>Tambah Materi</button>

<div class="card">
    <div class="card-body">
        <div class="card-title">
            List Materi Tersedia
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th width="5%">#</th>
                        <th width="65%">Judul Materi</th>
                        <th width="5%">Tingkat</th>
                        <th width="10%">Jurusan</th>
                        <th width="10%">Tipe</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($modules as $module)    
                        @php
                            $files=DB::table('module_files')
                                    ->where('id_module',$module->id)
                                    ->get();
                        @endphp    
                        <tr>
                            <th>{{$loop->iteration}}</th>
                            <td style="white-space:pre-wrap;word-wrap:break-word;">{{$module->module_header}}</td>
                            <td style="white-space:pre-wrap;word-wrap:break-word;">{{$module->degree}}</td>
                            <td style="white-space:pre-wrap;word-wrap:break-word;">{{$module->department}}</td>
                            <td style="white-space:pre-wrap;word-wrap:break-word;">{{$module->type}}</td>
                            <td>
                                <div class="btn-group">
                                    @if($module->type == "Dengan Tugas")
                                    <a href="/module-answers/{{$module->id}}" class="btn btn-sm btn-outline-primary waves-effect waves-light "><i class="fa fa-file fa-2x"></i></a>
                                    @endif
                                    <button type="button" onclick="detailModuleForm({{$module->id}})" class="btn btn-sm btn-outline-success waves-effect waves-light "><i class="fa fa-eye fa-2x"></i></button>
                                    <button type="button" onclick="editModuleForm({{$module->id}})" class="btn btn-sm btn-outline-primary waves-effect waves-light "><i class="fa fa-edit fa-2x"></i></button>
                                    <button type="button" class="btn btn-sm delete-module btn-outline-danger waves-effect waves-light data-id="{{$module->id}}" data-action=" {{route('module.destroy',$module->id)}}"><i class="fa fa-trash-o fa-2x"></i></button>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- modal form --}}
<div class="modal fade" id="modalModule">
    <div class="modal-dialog modal-lg" >
        <form id="form_module" action="{{url('module')}}" method="POST" enctype="multipart/form-data">
            @csrf
            {{method_field('')}}
            <div class="modal-content animated fadeInUp">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Materi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body row">
                    <input type="hidden" name="id" value="">
                    <input type="hidden" name="old_file" value="">
                    <div class="form-group col-lg-4">
                        <label for="module_header">Judul Materi</label>
                        <input type="text" class="form-control @error('module_header') is-invalid @enderror" id="module_header" placeholder="masukan judul materi" name="module_header" value="{{ old('module_header') }}" autocomplete="off" autofocus>
                        @error('module_header')
                            <small for="module_header" class="error">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="col-lg-4 mb-4">
                        <label for="file" class="col-form-label">Upload File Materi</label>
                        <div class="custom-file custom-file-sm ">
                            <input type="file" name="file[]" multiple class="custom-file-input" id="file">
                            <label class="custom-file-label" id="label_materi" for="file">Pilih file</label>
                        </div>
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="degree">Tipe</label>
                        <select name="type" class="form-control" id="type">
                            <option>Dengan Tugas</option>
                            <option>Tanpa Tugas</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="department">Jurusan</label>
                        <input type="text" class="form-control @error('department') is-invalid @enderror" id="department" placeholder="masukan nama jurusan" name="department" value="{{ old('department') }}" autocomplete="off" autofocus>
                        @error('department')
                            <small for="department" class="error">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="degree">Tingkat</label>
                        <select name="degree" class="form-control" id="degree">
                            <option value="X">X</option>
                            <option value="XI">XI</option>
                            <option value="XII">XII</option>
                        </select>
                    </div>
                    <div class="old_module col-lg-4"></div>
                    <div class="col-lg-12">
                        <textarea id="module_body" placeholder="masukan detail materi" name="module_body">{{ old('module_body') }}</textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary"><span id="submit"><i class="fa fa-plus"></i> Tambah Materi</span> </button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="detailModule">
    <div class="modal-dialog modal-lg" >
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Detail Materi</h5>
            </div>
            <div class="modal-body">
                <h5 class="modal-title text-center mb-1" id="detail_header"></h5>
                <p id="detail_body"></p>
                <div class="old_module2 row mt-2">

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
<script src="{{url('assets/plugins/summernote/dist/summernote-bs4.min.js')}}"></script>
<!--Data Tables js-->
<script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
<script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

<script>
    $('#default-datatable').DataTable();
</script>

@if ($errors->any())
    <script>
        $("#modalModule").modal('show');        
    </script>
@endif

<script>
    function addform() {
        $("#modalModule").modal('show');
        $('.modal-title').html('Tambah Materi');
        $('#submit').html('<i class="fa fa-plus"></i> Tambah');
        $('#module_header').val('');
        $('.note-editable').html('');
        $('#label_materi').text('Pilih file baru');
        $('input[name$="_method"]').val('POST');
        $('#form_module').attr('action', "{{url('module')}}");
    }

    function detailModuleForm(id){
        $('#detailModule').modal('show');
        $.ajax({
            url: "{{url('getmodule').'/'}}" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                $('#detail_header').html(data[0].module_header);
                $('#detail_body').html(data[0].module_body);
                $('.old_module2').html('');

                data[1].forEach(data => {    
                    $('.old_module2').append(`
                        <div class="col-lg-3 col-sm-12">
                            <div class="btn-group m-1">
                                <a href="
                                {{ url('modules/`+data.file+`') }}
                                " target="_blank" class="btn btn-link">`+data.file+`</a>
                            </div>
                        </div>
                    `);
                });
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                console.log('Error - ' + errorMessage);
            }
        });
    }

    function editModuleForm(id) {
        $("#modalModule").modal('show');
        $('.modal-title').html('Edit Materi');
        $('#submit').html('<i class="fa fa-edit"></i> Edit');
        $('#form_module').attr('action', "{{url('module')}}/" + id);
        $('input[name$="_method"]').val('PATCH');
        $('#label_materi').text('Pilih file lain');
        $('input[name$="id"]').val(id);

        $.ajax({
            url: "{{url('getmodule').'/'}}" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                $('#module_header').val(data[0].module_header);
                $('#department').val(data[0].department);
                $('#degree').val(data[0].degree);
                $('.note-editable').html(data[0].module_body);
                $('.old_module').html('');
                
                data[1].forEach(data => {    
                    $('.old_module').append(`
                        <br>
                        <div class="btn-group m-1">
                            <a href="{{ url('modules/`+data.file+`') }}" target="_blank" class="btn btn-outline-danger waves-effect waves-light btn-sm">`+data.file+`</a>
                            <button type="button" class="btn btn-sm delete-module btn-outline-danger waves-effect waves-light" data-id="`+data.id+`" data-action="
                                {{ url('modulefile/`+data.id+`') }}
                            "><i class="fa fa-trash-o fa-2x"></i></button>
                        </div>
                    `);
                });
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                console.log('Error - ' + errorMessage);
            }
        });
    }

    $('body').on("click", ".delete-module", function() {
        var current_object = $(this);
        swal({
            title: "Apa kamu yakin?",
            text: "menghapus materi beserta file didalamnya!",
            type: "error",
            showCancelButton: true,
            dangerMode: true,
            cancelButtonClass: '#DD5B55',
            confirmButtonColor: '#dc3545',
            confirmButtonText: 'Delete!',
        }, function(result) {
            if (result) {
                var action = current_object.attr('data-action');
                var token = jQuery('meta[name="csrf-token"]').attr('content');
                var id = current_object.attr('data-id');

                $('body').html("<form class='form-inline delete-module' method='post' action='" + action + "'></form>");
                $('body').find('.delete-module').append('<input name="_method" type="hidden" value="delete">');
                $('body').find('.delete-module').append('<input name="_token" type="hidden" value="' + token + '">');
                $('body').find('.delete-module').append('<input name="id" type="hidden" value="' + id + '">');
                $('body').find('.delete-module').submit();
            }
        });
    });

    $('#module_body').summernote({
        height: 100,
        tabsize: 2,
        toolbar: [
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['para', ['ul', 'ol', 'paragraph']],
        ]
    });

    $('input[type="file"]').change(function(e) {
        if(e.target.files.length==1){
            $('.custom-file-label').html(e.target.files[0].name);
        }else{
            $('.custom-file-label').html(e.target.files.length+' files selected.');

        }
    });
</script>

@endsection