<table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Username</th>
                        <th scope="col">Status</th>
                        <th scope="col">Paket Tersedia</th>
                        <th scope="col">Paket Dikerjakan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($siswa as $siswa)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$siswa->user->name}}</td>
                            <td>{{$siswa->user->username}}</td>
                            <td>@if($siswa->user->is_login == 'yes')<span class="badge badge-success">Hadir</span>@else<span class="badge badge-warning">Tidak Hadir</span>@endif</td>
                            <td>{{$siswa->user->paket_tersedia()}}</td>
                            <td>{{$siswa->user->paket_dikerjakan()}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>