@extends('layouts.main')
@section('title','Pengelolaan Guru')

@section('css')
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title mb-4">
            Daftar Guru
            <button class="btn btn-primary btn-sm float-right" id="create-teacher" data-toggle="modal" data-target="#create-teacher-modal">Tambah Guru</button>
        </div>
        <div class="table-responsive">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Email</th>
                        <th scope="col">Username</th>
                        <th scope="col">Wali Kelas</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($teachers as $teacher)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$teacher->user->name}}</td>
                            <td>{{$teacher->user->email}}</td>    
                            <td>{{$teacher->user->username}}</td>
                            @if($teacher->study_group->first())    
                            <td>
                            @foreach($teacher->study_group as $kelas)
                            <span class="badge badge-primary mx-1">{{$kelas->name}}</span>
                            @endforeach
                            </td>
                            @else
                            <td></td>
                            @endif
                            <td>
                                <span style="cursor:pointer" class="badge badge-danger delete-teacher" onclick="deleteGuru({{$teacher->id}})">Delete</span>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<form id="delete-teacher-form" action="/teacher" method="post">
    @method('delete')
    @csrf
</form>
{{-- modal form --}}
<div class="modal fade" id="create-teacher-modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated fadeInUp">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Guru</h5>
            </div>
            <form action="/teacher" method="post">
                <div class="modal-body row">
                        @csrf
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Nama : </label>
                                <input type="text" class="form-control" name="name" autocomplete="off" placeholder="Masukan Nama">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Username :</label>
                                <input type="text" class="form-control" name="username" autocomplete="off" placeholder="Masukan Username">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Password :</label>
                                <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Masukan Password">
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label>Konfirmasi Password :</label>
                                <input type="password" class="form-control" name="password_confirmation" autocomplete="off" placeholder="Masukan Password">
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-sm float-right" id="store-teacher">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('js')
    <!--Data Tables js-->
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

    <script>
        $('#default-datatable').DataTable();

        function deleteGuru(id){
            console.log(id)
            $('#delete-teacher-form').attr('action', '/teacher/'+id)
            $('#delete-teacher-form').submit()
        }
    </script>
@endsection