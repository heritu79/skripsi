@extends('layouts.main')
@section('title','Siswa Kelas')

@section('css')
    <link href="{{url("assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
    <link href="{{url("assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css")}}" rel="stylesheet" type="text/css">
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="card-title mb-4">
            Daftar Siswa Kelas {{isset($study_group->name) ? $study_group->name : ''}}
            <button class="btn btn-primary btn-sm float-right py-1 px-2" id="refreshSiswa" data-id_kelas="{{$study_group->id}}"><i class="icon-refresh" style="font-size: 18px;"></i></button>
        </div>
        <div class="table-responsive" id="tabel-siswa">
            <table class="table table-hover" id="default-datatable">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Username</th>
                        <th scope="col">Status</th>
                        <th scope="col">Paket Tersedia</th>
                        <th scope="col">Paket Dikerjakan</th>
                        <th scope="col">Izin Mengerjakan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($siswa as $siswa)
                        <tr>
                            <th scope="row">{{$loop->iteration}}</th>
                            <td>{{$siswa->user->name}}</td>
                            <td>{{$siswa->user->username}}</td>
                            <td>@if($siswa->user->is_login == 'yes')<span class="badge badge-success">Hadir</span>@else<span class="badge badge-warning">Tidak Hadir</span>@endif</td>
                            <td>{{$siswa->user->paket_tersedia()}}</td>
                            <td>{{$siswa->user->paket_dikerjakan()}}</td>
                            <td class="text-center">
                                <button class="btn @if($siswa->test_permission == 'allowed') btn-success @else btn-danger @endif btn-sm py-1 px-2 test-permission" id="test-permission-{{$siswa->id}}" data-id="{{$siswa->id}}">@if($siswa->test_permission == 'allowed') DIIZINKAN @else TIDAK DIIZINKAN @endif</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@section('js')
    <!--Data Tables js-->
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/jszip.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/pdfmake.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/vfs_fonts.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.html5.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.print.min.js")}}"></script>
    <script src="{{url("assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js")}}"></script>

    <script>
        $('#default-datatable').DataTable();

        $(document).on('click', '#refreshSiswa', function(){
            id = $(this).data('id_kelas')
            $.ajax({
                url: '/homeroom/siswa/'+id,
                type: 'get',
                dataType: 'json',
                success: (data) => {
                    if(data.success){
                        $('#tabel-siswa').html(data.html)
                        $('#default-datatable').DataTable();
                    }
                }
            })
        })

        $(document).on('click', '.test-permission', function(){
            id = $(this).data('id')
            $.ajax({
                url: '/homeroom/test-permission/siswa/'+id,
                type: 'post',
                data: {
                    '_token' : '{{csrf_token()}}'
                },
                dataType: 'json',
                success: (data) => {
                    if(data.success){
                        $('#test-permission-'+id).toggleClass('btn-success')
                        $('#test-permission-'+id).toggleClass('btn-danger')
                        $('#test-permission-'+id).html($('#test-permission-'+id).html() === ' DIIZINKAN ' ? ' TIDAK DIIZINKAN ' : ' DIIZINKAN ');
                    }
                }
            })
        })
    </script>
@endsection