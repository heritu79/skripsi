@extends('layouts.main')
@section('title','Pengelolaan Soal')

@section('css')
    <link href="{{url("assets/plugins/horizontal-timeline/css/horizontal-timeline.css")}}" rel="stylesheet" />
@endsection

@section('content')
<div class="row">
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-danger">{{$package}}</h4>
                        <span>Paket Soal</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-ibiza">
                        <i class="icon-book-open text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-warning">{{$question}}</h4>
                        <span>Soal</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-blooker">
                        <i class="icon-list text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-dark">{{$module}}</h4>
                        <span>Materi</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-royal">
                        <i class="icon-notebook text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-info">{{$file}}</h4>
                        <span>File</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-scooter">
                        <i class="icon-doc text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header text-uppercase">
                Informasi Seputar Sekolah
            </div>
            <div class="card-body">
                <ul class="nav nav-pills top-icon">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#item1"><i class="icon-home"></i> <span class="hidden-xs">Informasi Utama</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#item2"><i class="icon-menu"></i> <span class="hidden-xs">Informasi Lainnya</span></a>
                    </li>
                </ul>
        
                <div class="tab-content">
                    <div id="item1" class="container tab-pane active">
                        <section class="cd-horizontal-timeline">
                            <div class="timeline">
                                <div class="events-wrapper">
                                    <div class="events">
                                        <ol>
                                            @foreach ($timeline_informations as $information)
                                                <li><a href="#0" data-date="{{date('d/m/Y', strtotime($information->timeline_date))}}" @if ($loop->iteration==1) class="selected" @endif>{{date('d M',strtotime($information->timeline_date))}}</a></li>
                                            @endforeach
                                        </ol>
                
                                        <span class="filling-line" aria-hidden="true"></span>
                                    </div> <!-- .events -->
                                </div> <!-- .events-wrapper -->
                
                                <ul class="cd-timeline-navigation">
                                    <li><a href="#0" class="prev inactive">Prev</a></li>
                                    <li><a href="#0" class="next">Next</a></li>
                                </ul> <!-- .cd-timeline-navigation -->
                            </div> <!-- .timeline -->
                
                            <div class="events-content">
                                <ol>
                                    @foreach ($timeline_informations as $information)
                                        <li  data-date="{{date('d/m/Y', strtotime($information->timeline_date))}}" @if ($loop->iteration==1) class="selected" @endif>
                                            <h5>{{$information->information_header}}</h5>
                                            <em>{{date('d F Y', strtotime($information->timeline_date))}}</em>
                                            <p>
                                                {!!$information->information_body!!}
                                            </p>
                                        </li>
                                    @endforeach
                                </ol>
                            </div> <!-- .events-content -->
                        </section>
                    </div>
                    <div id="item2" class="container tab-pane">
                        @foreach ($no_timeline_informations as $information)
                                <h5>{{$information->information_header}}</h5>
                                <p>
                                    {!!$information->information_body!!}
                                </p>
                                <hr class="mb-2">
                        @endforeach
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
    <script src="{{url("assets/plugins/horizontal-timeline/js/horizontal-timeline.js")}}"></script>
@endsection