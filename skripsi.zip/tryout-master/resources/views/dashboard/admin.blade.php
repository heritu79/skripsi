@extends('layouts.main')
@section('title','Dashboard')

@section('css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection

@section('content')
@php
if (count($dates) != 0) {
    foreach ($dates as $date => $details) {
    $i = 0;
        foreach ($details as $detail) {
            $i++;
        }
        $datas[] = $i;
    }
}
@endphp
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-primary">{{$user}}</h4>
                        <span>Pengguna</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-violet">
                        <i class="icon-user text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-success">{{$tryout}}</h4>
                        <span>Ulangan Online Dikerjakan</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-quepal">
                        <i class="icon-pencil text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-danger">{{$package}}</h4>
                        <span>Paket Soal</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-ibiza">
                        <i class="icon-book-open text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-warning">{{$question}}</h4>
                        <span>Soal</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-blooker">
                        <i class="icon-list text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-dark">{{$module}}</h4>
                        <span>Materi</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-royal">
                        <i class="icon-notebook text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h4 class="text-info">{{$file}}</h4>
                        <span>File</span>
                    </div>
                    <div class="align-self-center w-circle-icon rounded gradient-scooter">
                        <i class="icon-doc text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header text-uppercase">Grafik Pengerjaan Ulangan Online Oleh Pengguna</div>
            <div class="card-body">
            <canvas id="lineChart" height="110"></canvas>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
    <script src="{{url("assets/plugins/Chart.js/Chart.min.js")}}"></script>
    <script>
        var dates= <?= json_encode($dates)?>;
        console.log(dates);
        if ($('#lineChart').length) {
			var ctx = document.getElementById('lineChart').getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: [
                        @foreach($dates as $date=>$details)
                            "<?= $date ?>",
                        @endforeach
                    ],
					datasets: [
                        {
                            label: 'Ulangan Online',
                            data: [
                                @if(isset($datas))
                                    @foreach($datas as $data)
                                        "<?= $data ?>",
                                    @endforeach
                                @endif
                            ],
                            backgroundColor: "transparent",
                            borderColor: "#fd3550",
                            borderWidth: 2
                            
                        }
                    ]
				}
			});
		}
    </script>
@endsection
