<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question_package extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'question_package', 'tryout_time', 'desc', 'user_id', 'degree', 'department'
    ];

    public function user_tryout()
    {
        return $this->hasMany('App\User_tryout', 'id_question_package');
    }

    public function question()
    {
        return $this->hasMany(Question::class, 'id_question_package');
    }
}
