<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_tryout extends Model
{
    protected $fillable = [
        'id_user', 'id_question_package'
    ];

    public function question_package()
    {
        return $this->belongsTo('App\Question_package', 'id_question_package');
    }

    public function answer()
    {
        return $this->hasMany('App\User_answer', 'id_user_tryout');
    }

    public static function boot() {
        parent::boot();
        self::deleting(function($user_tryout) {
             $user_tryout->answer()->each(function($answer) {
                $answer->delete();
             });
        });
    }
}
