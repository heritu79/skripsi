<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id_question_package', 'id_question_type', 'question', 'choice_type', 'question_image', 'answer'
    ];

    public function question_type()
    {
        return $this->belongsTo('App\Question_type', 'id_question_type');
    }
}
