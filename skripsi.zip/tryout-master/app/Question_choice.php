<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question_choice extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id_question', 'choice', 'choice_type', 'value'
    ];

    public function user_answer()
    {
        return $this->hasOne('App\User_answer');
    }
}
