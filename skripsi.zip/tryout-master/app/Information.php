<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Information extends Model
{
    public $timestamps = false;
    protected $table = 'informations';

    protected $fillable = [
        'information_header', 'information_body', 'timeline_date'
    ];
}
