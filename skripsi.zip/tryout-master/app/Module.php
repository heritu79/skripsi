<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'module_header', 'module_body', 'file','degree','department','user_id','type'
    ];

    public function answers()
    {
        return $this->hasMany(ModuleAnswer::class);
    }

    public function answer()
    {
        return \App\ModuleAnswer::where('user_id', auth()->user()->id)->first();
    }

    public static function boot() {
        parent::boot();
        
        static::deleting(function($module) {
            \App\ModuleAnswer::where('module_id', $module->id)->delete();
        });
    }
}
