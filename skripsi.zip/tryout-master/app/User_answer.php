<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_answer extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id_user_tryout', 'id_question_choice'
    ];

    public function question_choice()
    {
        return $this->belongsTo('App\Question_choice', 'id_question_choice');
    }
}
