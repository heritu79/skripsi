<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    protected $fillable = [
        'user_id'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function study_group()
    {
        return $this->hasMany(study_group::class, 'homeroom_teacher_id');
    }
}
