<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class study_group extends Model
{
    protected $fillable = [
        'homeroom_teacher_id',
        'name', 'degree', 'department'
    ];

    public function wali_kelas()
    {
        return $this->belongsTo('App\Teacher', 'homeroom_teacher_id');
    }

    public function students()
    {
        return $this->hasMany('App\Student');
    }
}
