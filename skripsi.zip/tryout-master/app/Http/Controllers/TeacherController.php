<?php

namespace App\Http\Controllers;

use App\{Student, study_group, Teacher, User};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TeacherController extends Controller
{
    public function index()
    {
        $teachers = Teacher::with('study_group')->get();
        // return response($teachers);
        return view('teacher.index', compact('teachers'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'username' => 'required',
            'password' => 'required|confirmed',
        ]);

        $user =  User::create([
            'name' => $request->name,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'teacher',
            'profile_picture' => 'default.png'
        ]);

        Teacher::create(['user_id' => $user->id]);

        return redirect('/teacher')->with(['success' => 'Data berhasil ditambahkan !']);
    }

    public function destroy(Teacher $teacher)
    {
        $user = User::find($teacher->user_id);
        $user->delete();
        $teacher->delete();
        
        return redirect('/teacher');
    }

    public function siswaWali()
    {
        $teacher = Teacher::where('user_id', auth()->user()->id)->first();
        $study_group = study_group::where('homeroom_teacher_id', $teacher->id)->first();
        if(!$study_group){
            $study_group['id'] = 0;
        }
        $siswa = Student::with('user')->where('study_group_id', $study_group['id'])->get();
        return view('teacher.siswa', compact('siswa', 'study_group'));
    }

    public function refreshSiswa()
    {
        $teacher = Teacher::where('user_id', auth()->user()->id)->first();
        $study_group = study_group::where('homeroom_teacher_id', $teacher->id)->first();
        if(!$study_group){
            $study_group['id'] = 0;
        }
        $siswa = Student::with('user')->where('study_group_id', $study_group['id'])->get();
        
        $html = view('teacher.student_table', compact('siswa'))->render();
        return response(['success' => true, 'html' => $html]);
    }

    public function testPermission(Student $student)
    {
        $student->test_permission = $student->test_permission == 'allowed' ? 'prohibited' : 'allowed';
        $student->save();

        return response(['success' => true]);
    }
}
