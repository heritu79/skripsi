<?php

namespace App\Http\Controllers;

use App\Module_file;

class ModuleFileController extends Controller
{
     
    public function destroy(Module_file $module_file, $id)
    {
        $file = Module_file::where('id', $id)->first();
        unlink('modules/' . $file->file);
        $module_file->delete();
        return redirect('/module')->with('status', 'Materi Berhasil Dihapus');
    }
}
