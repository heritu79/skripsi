<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Information;

class InformationController extends Controller
{
     
    public function index()
    {
        $informations = Information::orderBy('id', 'desc')->get();

        return view('information.information', compact('informations'));
    }

     
    public function store(Request $request)
    {
        $request->validate([
            'information_header' => 'required',
        ]);

        Information::create($request->all());

        return redirect('/information')->with('status', 'Informasi Baru Berhasil Ditambahkan');
    }

     
    public function show(Information $information)
    {
        $data = $information;
        return $data;
    }

     
    public function update(Request $request, Information $information)
    {
        $request->validate([
            'information_header' => 'required',
        ]);

        Information::where('id', $information->id)
            ->update($request->only('information_header', 'information_body', 'timeline_date'));

        return redirect('/information')->with('status', 'Informasi Berhasil Diedit');
    }

     
    public function destroy(Information $information)
    {
        $information->delete();
        return redirect('/information')->with('status', 'Informasi Berhasil Dihapus');
    }
}
