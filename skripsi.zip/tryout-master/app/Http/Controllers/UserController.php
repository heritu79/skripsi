<?php

namespace App\Http\Controllers;

use App\User;
use App\Question_package;
use App\{Student, study_group, User_tryout};
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
     
    public function index()
    {
        $users = User::with('student.study_group')
            ->where('role', 'user')
            // ->where('email_verified_at', '!=', '')
            ->orderBy('id', 'desc')
            ->get();
        // return $users[1]->student->study_group->name;
        $total_package = Question_package::count();
        // return response($users);s
        $classes = study_group::all();

        return view('user.user', compact('users', 'total_package','classes'));
    }

    public function show(User $user)
    {
        //0 data user
        $data[] = $user;

        //1 jumlah tryout
        $data[] = User_tryout::where('id_user', $user->id)
            ->distinct()
            ->get(['id_question_package'])
            ->count();

        //2 jumlah paket
        $data[] = Question_package::count();

        //3 jumlah user tryout
        $data[] = User_tryout::where('id_user', $user->id)
            ->count();

        $user_tryouts = User_tryout::where('id_user', '=', $user->id)
            ->orderBy('id', 'desc')
            ->get();

        $pass = 0;
        $fail = 0;
        foreach ($user_tryouts as $user_tryout) {
            $user_scores = DB::table('user_answers')
                ->join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
                ->where('id_user_tryout', $user_tryout->id)
                ->get();

            $score = 0;
            foreach ($user_scores as $user_score) {
                $score += $user_score->value;
            }

            $total_score = DB::table('questions')
                ->where('id_question_package', '=', $user_tryout->id_question_package)
                ->count();
            //mendapatkan tipe soal yang ada pada paket yang dikerjakan oleh user
            $type_in_packages = DB::table('questions')
                ->where('id_question_package', '=', $user_tryout->id_question_package)
                ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                ->distinct()
                ->get(['question_type', 'passing_grade']);

            $result = true;
            foreach ($type_in_packages as $type_in_package) {
                //mendapatkan jawaban berdasarkan tipe soal
                $score_per_question_type = DB::table('user_answers')
                    ->join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
                    ->where('id_user_tryout', $user_tryout->id)
                    ->join('questions', 'questions.id', '=', 'question_choices.id_question')
                    ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                    ->where('question_type', $type_in_package->question_type)
                    ->get();

                //medapatkan skor berdasarkan tipe soal
                $scorePerType = 0;
                foreach ($score_per_question_type as $score_type) {
                    $scorePerType += $score_type->value;
                }

                $totalScorePerType = DB::table('questions')
                    ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
                    ->where('id_question_package', '=', $user_tryout->id_question_package)
                    ->where('question_type', $type_in_package->question_type)
                    ->count();

                $totalScorePerType *= 5;
                $scoreInPercent = $scorePerType / $totalScorePerType * 100;
                if ($scorePerType / $totalScorePerType * 100 > $type_in_package->passing_grade) :
                    $result = $result && true;
                else :
                    $result = $result && false;
                endif;
            }
            if ($result == true) {
                $pass++;
            } else {
                $fail++;
            }
        }

        //4 data lulus
        $data[] = $pass;

        //5 data gagal
        $data[] = $fail;

        //6 data terverifikasi
        $data[] = date('j F Y', strtotime($user->email_verified_at));

        return $data;
    }

    public function storeSiswa(Request $request)
    {
        $user =  User::create([
            'name' => $request->name,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'user',
            'profile_picture' => 'default.png'
        ]);

        $student = Student::create([
            'user_id' => $user->id,
            'study_group_id' => $request->study_group_id,
        ]);
        
        return redirect('/user');
    }

    public function destroySiswa($user_id)
    {
        $user = User::find($user_id);
        $user->student->delete();
        $user->delete();

        return redirect('user');
    }
}
