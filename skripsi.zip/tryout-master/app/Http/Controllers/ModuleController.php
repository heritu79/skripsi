<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Module;
use App\{Module_file, ModuleAnswer};

class ModuleController extends Controller
{
     
    public function index()
    {
        
        if (auth()->user()->role == 'teacher') {
            $modules = Module::where('user_id', auth()->user()->id)->orderBy('id', 'desc')->get();
            return view('module.module_management', compact('modules'));
        } elseif(auth()->user()->role == 'admin'){
            $modules = Module::orderBy('id', 'desc')->get();
            return view('module.module', compact('modules'));
        } else {
            $modules = Module::where([['degree', auth()->user()->student->study_group->degree],['department', auth()->user()->student->study_group->department]])->orderBy('id', 'desc')->get();
            return view('module.module', compact('modules'));
        }
    }

     
    public function store(Request $request)
    {
        $request->validate([
            'module_header' => 'required',
        ]);

        $module_id = Module::create([
                'module_header' => $request->module_header, 
                'module_body' => $request->module_body,
                'degree' => $request->degree,
                'department' => $request->department,
                'user_id' => auth()->user()->id,
                'type' => $request->type,
            ])->id;

        if ($request->hasFile('file')) {
            for ($i = 0; $i < count($request->file); $i++) {
                if (isset($request['file'][$i])) {
                    $name = uniqid() . '.' . $request->file[$i]->getClientOriginalExtension();
                    $request->file[$i]->move(public_path('modules/'), $name);

                    Module_file::create(
                        ['id_module' => $module_id, 'file' => $name]
                    );
                }
            }
        }

        return redirect('/module')->with('status', 'Materi Berhasil Ditambahkan');
    }

     
    public function show(Module $module)
    {
        $module_files = Module_file::where('id_module', '=', $module->id)->get();

        return view('module.module_detail', compact('module', 'module_files'));
    }

     
    public function update(Request $request, Module $module)
    {
        $request->validate([
            'module_header' => 'required',
        ]);

        if ($request->hasFile('file')) {
            for ($i = 0; $i < count($request->file); $i++) {
                if (isset($request['file'][$i])) {
                    $name = uniqid() . '.' . $request->file[$i]->getClientOriginalExtension();
                    $request->file[$i]->move(public_path('modules/'), $name);

                    Module_file::create(
                        ['id_module' => $module->id, 'file' => $name]
                    );
                }
            }
        }

        Module::where('id', $module->id)
            ->update($request->only(['module_header', 'module_body','degree','department','type']));

        return redirect('/module')->with('status', 'Informasi Berhasil Diedit');
    }

     
    public function destroy(Module $module)
    {
        $datas = Module_file::where('id_module', $module->id)->get();
        if (count($datas) != 0) {
            foreach ($datas as $data) {
                // unlink('modules/' . $data->file);
            }
        }
        $module->delete();
        Module_file::where('id_module', $module->id)->delete();
        return redirect('/module')->with('status', 'Materi Berhasil Dihapus');
    }

    public function getmodule(Module $module)
    {
        $data[] = $module;
        $data[] = Module_file::where('id_module', $module->id)->get();
        return $data;
    }

    public function answer(Request $request)
    {
        $request->validate([
            'answer' => 'nullable',
            'file' => 'mimes:doc,docx,pdf,xls,xlsx,jpeg,jpg,png,zip'
        ]);

        $file = null;

        if($request->file){
            $file = $request->file->store(
                'module answer',  'assets'
            );
            $file = "/assets/$file";
        }

        ModuleAnswer::create([
            'module_id' => $request->module_id,
            'user_id' => auth()->user()->id,
            'answer' => $request->answer,
            'file' => $file,
        ]);

        return redirect()->back()->with('status', 'Jawaban Berhasil Disimpan !');
    }

    public function answers(Module $module)
    {
        $module_files = Module_file::where('id_module', '=', $module->id)->get();

        return view('module.module_detail_answers', compact('module', 'module_files'));
    }
}
