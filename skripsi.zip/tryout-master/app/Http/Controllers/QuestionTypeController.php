<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Question_type;

class QuestionTypeController extends Controller
{
     
    public function index()
    {
        $questionTypes = Question_type::orderBy('id', 'desc')
            ->get();
        return view('question.type', compact('questionTypes'));
    }

     
    public function store(Request $request)
    {
        $request->validate([
            'question_type' => 'required',
            'passing_grade' => 'required|numeric',
        ]);

        Question_type::create($request->all());

        return redirect('/type')->with('status', 'Tipe Soal Baru Berhasil Ditambahkan')->with('color', 'success');
    }

     
    public function update(Request $request, Question_type $type)
    {
        $request->validate([
            'question_type' => 'required',
            'passing_grade' => 'required|numeric',
        ]);

        Question_type::where('id', $type->id)
            ->update($request->only('question_type', 'passing_grade', 'desc'));

        return redirect('/type')->with('status', 'Tipe Soal Berhasil Diedit')->with('color', 'success');
    }

     
    public function destroy(Question_type $type)
    {
        $type->delete();
        return redirect('/type')->with('status', 'Tipe Soal Berhasil Dihapus')->with('color', 'success');
    }

    public function gettype(Question_type $type)
    {
        $data = $type;
        return $data;
    }
}
