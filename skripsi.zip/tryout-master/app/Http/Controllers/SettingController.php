<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;

class SettingController extends Controller
{
    public function userAcc()
    {
        $user = User::find(auth()->user()->id);
        return view('setting.acc', compact('user'));
    }

    public function userAccStore(Request $request)
    {
        $request->validate([
            'profile_picture' => 'mimes:jpg,jpeg,gif,png',
            'name' => ['required', 'string', 'max:255'],
        ]);

        $input = $request->all();
        if ($request->hasFile('profile_picture')) {
            $input['profile_picture'] = uniqid() . '.' . $request->profile_picture->getClientOriginalExtension();
            $request->profile_picture->move(public_path('img/profile/'), $input['profile_picture']);
            if ($request->old_picture != 'default.png') {
                // unlink('img/profile/' . $request->old_picture);
            }
        } else {
            $input['profile_picture'] = $request['old_picture'];
        }

        User::where('id', auth()->user()->id)
            ->update([
                'name' => $request->name,
                'profile_picture' => $input['profile_picture'],
            ]);

        if ($request['password'] != '') {
            User::where('id', auth()->user()->id)
                ->update([
                    'password' => Hash::make($request['password'])
                ]);
        }

        return redirect('/setting')->with('status', 'Profile Berhasil Diupdate');
    }
}
