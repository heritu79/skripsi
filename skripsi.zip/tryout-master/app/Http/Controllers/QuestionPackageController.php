<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use App\Question_package;
use App\Question_type;
use App\Question;
use App\Question_choice;
use App\User;
use App\study_group;

class QuestionPackageController extends Controller
{
     
    public function index()
    {
        $questionPackages = new Question_package;

        if(auth()->user()->role == 'teacher'){
            $questionPackages = $questionPackages->where('user_id', auth()->user()->id);
        }
        
        $questionPackages = $questionPackages->orderBy('id', 'desc')->get();

        return view('question.package', compact('questionPackages'));
    }

     
    public function store(Request $request)
    {
        // return $request;
        $request->validate([
            'question_package' => 'required',
        ]);

        
        $question_package = new Question_package();

        $question_package->question_package = $request->question_package;
        $question_package->tryout_time = $request->tryout_time;
        $question_package->is_active = $request->is_active;
        $question_package->desc = $request->desc;
        $question_package->degree = $request->degree;
        $question_package->department = $request->department;

        if(auth()->user()->role == 'teacher'){
            $question_package->user_id = auth()->user()->id;
        }

        $question_package->save();

        return redirect('/package')->with('status', 'Paket Soal Baru Berhasil Ditambahkan');
    }

     
    public function show(Question_package $package)
    {
        $question_package = $package;
        $question_types = Question_type::all();
        $questions = Question::where('id_question_package', '=', $package->id)->get();
        $question_count = Question::where('id_question_package', '=', $package->id)->count();
        $question_type_in_question = Question::where('id_question_package', '=', $package->id)
            ->join('question_types', 'questions.id_question_type', '=', 'question_types.id')
            ->distinct()
            ->get(['question_type']);

        return view('question/question', compact('question_package', 'question_types', 'questions', 'question_count', 'question_type_in_question'));
    }

     
    public function update(Request $request, Question_package $package)
    {
        $request->validate([
            'question_package' => 'required',
        ]);

        Question_package::where('id', $package->id)
            ->update($request->only('question_package', 'tryout_time', 'is_active', 'desc','degree','department'));

        return redirect('/package')->with('status', 'Paket Soal Berhasil Diedit');
    }

     
    public function destroy($id)
    {
        $questions = Question::where('id_question_package', $id)->get();
        if (count($questions) != 0) {
            foreach ($questions as $question) {
                if ($question->question_image != "") {
                    // unlink('img/question/' . $question->question_image);
                }

                $datas = Question_choice::where('id_question', $question->id)->get();
                if ($question->choice_type == "img") {
                    foreach ($datas as $data) {
                        // unlink('img/question/' . $data->choice);
                    }
                }
            }
        }

        Question_package::where('id', $id)->delete();
        return redirect('/package')->with('status', 'Paket Soal Berhasil Dihapus');
    }

    public function getpackage(Question_package $package)
    {
        $data = $package;
        return $data;
    }

    public function result(Question_package $package)
    {
        $users = User::with(['tryout' => function($query) use ($package){
                $query->where('id_question_package', $package->id)->latest();
            }])
            ->whereHas('tryout', function($query) use ($package){
                $query->where('id_question_package', $package->id)->latest();
                $query->latest();
            })
            ->with('student.study_group')
            ->where('role', 'user')
            ->get();
            
        return view('result.user',[
           'users' => $users,
        ]);
    }
}
