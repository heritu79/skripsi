<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\User_tryout;
use App\User_answer;
use App\Question;
use App\Question_package;

class ReviewController extends Controller
{
     
    public function show($user_id)
    {
        $user_tryouts = User_tryout::where('id_user', '=', $user_id)
            ->orderBy('id', 'desc')
            ->get();
            
        return view('review.tryout_list', compact('user_tryouts'));
    }

     
    public function detail($id)
    {
        $user_tryout = User_tryout::find($id);
        $questions = Question::where('id_question_package', '=', $user_tryout->id_question_package)->get();

        // return $questions;
        $question_package = Question_package::find($id);
        $user_tryout = User_tryout::find($id);

        return view('review.review', compact('questions', 'question_package', 'user_tryout'));
    }

    public function statistic($id)
    {
        //user tryout answer
        $user_tryout = User_tryout::find($id);

        //user
        $user = User::where('id', $user_tryout->id_user)
            ->first();

        //get user score
        $user_scores = User_answer::join('question_choices', 'user_answers.id_question_choice', '=', 'question_choices.id')
            ->where('id_user_tryout', $id)
            ->get();

        //get total score
        $total_score = Question::where('id_question_package', '=', $user_tryout->id_question_package)->count();

        //passing grade
        $type_in_packages = Question::where('id_question_package', '=', $user_tryout->id_question_package)
            ->join('question_types', 'question_types.id', '=', 'questions.id_question_type')
            ->distinct()
            ->get(['question_type', 'passing_grade']);

        return view('review.statistic', compact('user', 'user_tryout', 'user_scores', 'total_score', 'type_in_packages'));
    }
}
