<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Question;
use App\Question_choice;
use App\Question_type;
use App\User_tryout;

class QuestionController extends Controller
{
     
    public function store(Request $request)
    {
        if (isset($request->choice_type)) {
            $type = 'img';
            $request->validate([
                // 'img' => ['mimes:JPG,JPEG,GIF,PNG', 'required'],
                'valimg' => ['required'],
                // 'answer' => 'required',
            ]);
        } else {
            $type = 'text';
            $request->validate([
                'text' => ['required'],
                'valtext' => ['required'],
                // 'answer' => 'required',
            ]);
        }

        $input = $request->all();
        if ($request->hasFile('question_image')) {
            $input['question_image'] = uniqid() . '.' . $request->question_image->getClientOriginalExtension();
            $request->question_image->move(public_path('img/question/'), $input['question_image']);
        } else {
            $input['question_image'] = '';
        }

        Question::create([
            'id_question_package' => $request['id_question_package'],
            'id_question_type' => $request['id_question_type'],
            'question' => $request['question'],
            'question_image' => $input['question_image'],
            'choice_type' => $type,
            'answer' => $request['answer']
        ]);

        //get id question
        $question = Question::orderBy('id', 'desc')->first();

        if (isset($request->choice_type)) {
            for ($i = 0; $i < 5; $i++) {
                if (isset($request['img'][$i])) {
                    $name = uniqid() . '.' . $request->img[$i]->getClientOriginalExtension();
                    $request->img[$i]->move(public_path('img/question/'), $name);

                    Question_choice::create(
                        ['id_question' => $question->id, 'choice' => $name, 'value' => $request['valimg'][$i]]
                    );
                }
            }
        } else {
            for ($i = 0; $i < 5; $i++) {
                Question_choice::create(
                    [
                        'id_question' => $question->id, 
                        'choice' => $request['text'][$i], 
                        'value' => isset($request['valtext'][$i]) ? 5 : 0
                    ]
                );
            }
        }

        return redirect("/package/" . $request['id_question_package'])->with('status', 'Soal Berhasil Ditambahkan');
    }

     
    public function show(Question $question)
    {
        $data[] = $question;
        $data[] = Question_choice::where('id_question', $question->id)->get();
        return $data;
    }

    public function update(Request $request, $id)
    {
        // return $request;
        if (isset($request->choice_type)) {
            $type = 'img';
            $request->validate([
                'valimg' => ['required'],
            ]);
        } else {
            $type = 'text';
            $request->validate([
                'text' => ['required'],
                'valtext' => ['required'],
            ]);
        }

        $input = $request->all();
        if ($request->hasFile('question_image')) {
            $input['question_image'] = uniqid() . '.' . $request->question_image->getClientOriginalExtension();
            $request->question_image->move(public_path('img/question/'), $input['question_image']);
        } else if (isset($request->old_question_image)) {
            $input['question_image'] = $request->old_question_image;
        } else {
            $input['question_image'] = '';
        }

        //get jawaban ada bug
        $question_by_id = Question::where('id', $id)->first();
        if ($request['answer'] == null) {
            $question_get_one = $question_by_id['question'];
            $answer = $question_by_id['answer'];
        } else {
            $question_get_one = $request['question'];
            $answer = $request['answer'];
        }

        Question::where('id', $id)
        ->update([
            'id_question_type' => $request['id_question_type'],
            'question' => $request['question'],
            'question_image' => $input['question_image'],
            'choice_type' => $type,
            'answer' => $answer
        ]);

        $question_choices = Question_choice::where('id_question', $id)->get();
        if (isset($request->choice_type)) {
            for ($i = 0; $i < count($question_choices); $i++) {
                if (isset($request['img'][$i])) {
                    $name = uniqid() . '.' . $request->img[$i]->getClientOriginalExtension();
                    $request->img[$i]->move(public_path('img/question/'), $name);
                    // unlink('img/question/' . $request['old_img'][$i]);
                } else {
                    $name = $request['old_img'][$i];
                }

                Question_choice::where('id', $question_choices[$i]['id'])
                    ->update([
                        'choice' => $name,
                        'value' => $request['valimg'][$i],
                    ]);
            }
        } else {
            for ($i = 0; $i < count($question_choices); $i++) {
                Question_choice::where('id', $question_choices[$i]['id'])
                    ->update([
                        'choice' => $request['text'][$i],
                        'value' =>  isset($request['valtext'][$i]) ? 5 : 0
                    ]);
            }
        }

        $question = Question::find($id);
        return redirect("/package/" . $question->id_question_package)->with('status', 'Soal Berhasil Diupdate');
    }

     
    public function destroy(Question $question)
    {
        if ($question->question_image != "") {
            // unlink('img/question/' . $question->question_image);
        }

        $datas = Question_choice::where('id_question', $question->id)->get();
        if ($question->choice_type == "img") {
            foreach ($datas as $data) {
                // unlink('img/question/' . $data->choice);
            }
        }

        $result = User_tryout::where('id_question_package', $question->id_question_package)->count();

        if ($result != 0) {
            return redirect('/package/' . $question->id_question_package)->with('status_question', 'Soal Tidak Bisa Dihapus Dikarnakan Sudah Digunakan Tryout Oleh User')->with('type', 'error')->with('icon', 'fa fa-times-circle');
        } else {
            $question->delete();
            return redirect('/package/' . $question->id_question_package)->with('status_question', 'Soal Berhasil Dihapus')->with('type', 'success')->with('icon', 'fa fa-check-circle');
        }
    }
}
