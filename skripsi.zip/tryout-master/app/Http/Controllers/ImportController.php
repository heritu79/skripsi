<?php

namespace App\Http\Controllers;

use App\Imports\{SiswaImport};
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;

class ImportController extends Controller
{
    public function siswa(Request $request)
    {
        Excel::import(new SiswaImport, $request->file('file'));

        return redirect('/user')->with('success', 'Data Berhasil Diimport');
    }
}
