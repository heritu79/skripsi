<?php

namespace App\Http\Controllers;

use App\{study_group, Teacher};
use Illuminate\Http\Request;

class StudyGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kelas = study_group::all();
        $teachers = Teacher::all();
        return view('study_group.index', compact('kelas','teachers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        study_group::create($request->all());
        return redirect('/class');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\study_group  $study_group
     * @return \Illuminate\Http\Response
     */
    public function show(study_group $study_group)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\study_group  $study_group
     * @return \Illuminate\Http\Response
     */
    public function edit(study_group $study_group)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\study_group  $study_group
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, study_group $study_group)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\study_group  $study_group
     * @return \Illuminate\Http\Response
     */
    public function destroy(study_group $study_group)
    {
        $study_group->delete();
        return redirect('/class');
    }

    public function homeroomChange(Request $request, study_group $study_group)
    {
        $study_group->homeroom_teacher_id = $request->teacher_id;
        $study_group->save();

        return redirect('class');
    }
}
