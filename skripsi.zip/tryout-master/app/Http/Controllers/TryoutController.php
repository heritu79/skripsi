<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Question_package;
use App\Question;
use App\User_tryout;
use App\User_answer;

class TryoutController extends Controller
{

    public function index()
    {
        if(auth()->user()->role != 'user'){
            $questionPackages = Question_package::where('is_active', 'true')
                ->orderBy('id', 'desc')
                ->get();
        }else{
            $questionPackages = Question_package::where([
                ['is_active', 'true'],
                ['degree', auth()->user()->student->study_group->degree],
                ['department', auth()->user()->student->study_group->department],
            ])->orWhere([
                ['is_active', 'true'],
                ['degree', auth()->user()->student->study_group->degree],
                ['department', 'UMUM'],
            ])
                ->orderBy('id', 'desc')
                ->get();
        }

        return view('tryout.package_list', compact('questionPackages'));
    }

     
    public function store(Request $request)
    {
        $question_package = Question_package::find($request['id_question_package']);
        $count_answers = isset($request->answers) ? count($request->answers) : 0;
        $request->validate([
            'answers' => 'required|array|min:'.$question_package->question->count().'|max:'.$question_package->question->count()
        ],[
            'answers.required' => 'Kerjakan soal terlebih dahulu !',
            'answers.array' => 'Jawaban tidak valid !',
            'answers.min' => 'Jawab semua pertanyaan !, anda menjawab '.$count_answers.' dari '.$question_package->question->count().' pertanyaan !',
            'answers.max' => 'Jawab semua pertanyaan !, anda menjawab '.$count_answers.' dari '.$question_package->question->count().' pertanyaan !',
        ]);
        if($request->answers != null){
            $user_tryout = User_tryout::create([
                'id_user' => auth()->user()->id,
                'id_question_package' => $request['id_question_package'],
            ]);

            //get id tryout terbaru
            // $user_tryout = User_tryout::latest()->first();
            
            if ($user_tryout) {
                foreach ($request->answers as $answer) {
                    User_answer::create([
                        'id_user_tryout' => $user_tryout->id,
                        'id_question_choice' => $answer,
                    ]);
                }
                return redirect('tryout')->with('status', 'Selamat Anda Telah Menyelesaikan Tryout');
            }else{
                return redirect()->back()->with('status', 'Terjadi kesalahan pada sistem silahkan coba lagi !')->with('type', "error")->with('icon', 'fa fa-times');
            }
        }

        return redirect()->back()->with('status', 'Jawaban Anda Kosong Silahkan ikuti kembali Tryout')->with('type', "error")->with('icon', 'fa fa-times');
    }

     
    public function show($id)
    {
        if(auth()->user()->student->test_permission === 'prohibited'){
            return back()->with('error', 'Anda belum diizinkan untuk melakukan ujian, silahkan hubungi wali kelas anda !');
        }
        $questions = Question::where('id_question_package', '=', $id)->get();
        $question_package = Question_package::find($id);

        $check = User_tryout::where('id_question_package', $id)
            ->where('id_user', auth()->user()->id)
            ->count();

        if($check > 0){
            return redirect('tryout')->with('status', 'Anda tidak bisa ngekakses Ulangan Online, Dikarnakan telah dikerjakan')->with('icon', 'fa fa-times-circle')->with('type', 'error');
        }

        return view('tryout.tryout', compact('questions', 'question_package'));
    }

    public function destroy(Request $request, User_tryout $user_tryout)
    {
        $user_tryout->delete();
        return redirect()->back()->with('status', 'Data berhasil dihapus');
    }
}
