<?php

namespace App\Http\Controllers;

use App\User;
use App\Question_package;
use App\Question;
use App\User_tryout;
use App\Module;
use App\Module_file;
use App\Information;
use Carbon\Carbon;

class DashboardController extends Controller
{
     
    public function index()
    {
        //data dashboard
        $user = User::where('role', 'user')->count();
        $package = Question_package::where('is_active', 'true')
            ->count();
        $question = Question::join('question_packages', 'question_packages.id', '=', 'questions.id_question_package')
            ->where('is_active', 'true')
            ->count();
        $tryout = User_tryout::count();
        $module = Module::count();
        $file = Module_file::count();
        $informations = Information::orderBy('id', 'desc')->get();
        $timeline_informations = Information::where('timeline_date', '!=', '')->get();
        $no_timeline_informations = Information::where('timeline_date', '=', '')->get();

        //data untuk chart pengguna yang mengerjakan tryout
        $dates = User_tryout::orderBy('created_at')
            ->get()
            ->groupBy(function ($val) {
                return Carbon::parse($val->created_at)->format('F Y');
            });

        if (auth()->user()->role == 'admin') :
            return view('dashboard.admin', compact('user', 'package', 'question', 'tryout', 'module', 'file', 'dates'));
        else :
            return view('dashboard.user', compact('package', 'question', 'module', 'file', 'informations', 'timeline_informations', 'no_timeline_informations'));
        endif;
    }
}
