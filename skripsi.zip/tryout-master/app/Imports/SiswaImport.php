<?php

namespace App\Imports;

use App\{User, Student, study_group};
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Hash;

class SiswaImport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows)
    {
        foreach ($rows as $row) 
        {
            $user = User::create([
                'name' => $row['nama'],
                'username' => $row['username'],
                'password' => hash::make($row['password']),
                'role' => 'user',
                'profile_picture' => 'default.png'
            ]);

            $study_group = study_group::firstOrNew([
                'name' => $row['kelas'],
                'degree' => $row['tingkat'],
                'department' => $row['jurusan']
            ]);
            $study_group->save();

            $student = Student::create([
                'user_id' => $user->id,
                'study_group_id' => $study_group->id,
            ]);
        }
    }

    public function headingRow(): int
    {
        return 2;
    }
}
