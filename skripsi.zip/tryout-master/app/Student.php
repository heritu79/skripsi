<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
        'user_id',
        'study_group_id',
        'test_permission',
    ];

    public function study_group()
    {
        return $this->belongsTo('App\study_group');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
