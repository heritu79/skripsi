<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question_type extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'question_type', 'passing_grade', 'desc'
    ];

    public function question()
    {
        return $this->hasMany('App\Question');
    }
}
