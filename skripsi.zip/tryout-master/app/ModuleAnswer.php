<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModuleAnswer extends Model
{
    protected $fillable = [
        'module_id',
        'user_id',
        'answer',
        'file',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function boot() {
        parent::boot();

        static::deleting(function($answer) {
            $file_path = public_path('assets/'.$answer->file);

            if (File::exists($file_path)) {
                File::delete($file_path);
            }
        });
    }
}
