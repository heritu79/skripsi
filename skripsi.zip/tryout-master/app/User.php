<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'username', 'password', 'role', 'profile_picture', 'is_login'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function student() {
        return $this->hasOne('App\Student', 'user_id');
    }

    public function tryout()
    {
        return $this->hasMany('App\User_tryout', 'id_user');
    }

    public static function boot() {
        parent::boot();
        self::deleting(function($user) {
             $user->tryout()->each(function($tryout) {
                $tryout->delete();
             });
        });
    }

    public function teacher()
    {
        return $this->hasOne('App\Teacher');
    }

    public function paket_tersedia()
    {
        $questionPackages = Question_package::where([
            ['is_active', 'true'],
            ['degree', $this->student->study_group->degree],
            ['department', $this->student->study_group->department],
        ])->orWhere([
            ['is_active', 'true'],
            ['degree', $this->student->study_group->degree],
            ['department', 'UMUM'],
        ])->count();

        return $questionPackages;
    }

    public function paket_dikerjakan()
    {
        return User_tryout::where('id_user', $this->id)->count();
    }
}
