<?php

use Illuminate\Database\Seeder;

class UserTryoutTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('user_tryouts')->insert([
            [
                'id_user' => 2,
                'id_question_package' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'id_user' => 2,
                'id_question_package' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'id_user' => 2,
                'id_question_package' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'id_user' => 3,
                'id_question_package' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
        ]);

        DB::table('user_answers')->insert([
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 1,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 6,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 11,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 17,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 24,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 27,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 33,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 38,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 43,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 48,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 54,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 59,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 62,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 67,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 73,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 77,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 82,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 88,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 93,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 100,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 102,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 108,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 113,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 120,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 125,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 127,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 131,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 136,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 141,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 147,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 154,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 159,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 162,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 166,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 172,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 177,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 182,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 187,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 192,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 196,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 202,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 208,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 214,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 218,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 223,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 226,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 234,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 239,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 242,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 247,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 252,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 260,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 263,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 269,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 273,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 276,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 281,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 287,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 291,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 297,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 301,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 308,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 311,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 317,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 322,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 330,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 335,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 338,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 344,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 349,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 354,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 357,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 361,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 369,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 373,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 377,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 382,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 386,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 393,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 396,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 402,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 408,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 412,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 420,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 423,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 428,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 433,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 437,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 444,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 449,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 453,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 458,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 463,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 467,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 473,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 478,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 484,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 488,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 492,
            ],
            [
                'id_user_tryout' => 1,
                'id_question_choice' => 499,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 327,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 333,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 336,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 345,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 348,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 353,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 358,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 365,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 369,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 373,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 378,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 384,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 388,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 394,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 399,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 402,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 406,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 411,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 418,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 423,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 428,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 434,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 436,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 441,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 448,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 453,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 458,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 463,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 470,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 472,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 477,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 484,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 489,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 494,
            ],
            [
                'id_user_tryout' => 2,
                'id_question_choice' => 498,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 4,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 9,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 11,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 18,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 21,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 28,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 35,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 38,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 41,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 49,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 54,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 56,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 63,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 69,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 75,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 78,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 83,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 89,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 91,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 96,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 102,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 108,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 112,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 118,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 124,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 126,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 131,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 140,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 143,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 146,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 151,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 157,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 165,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 170,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 171,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 180,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 184,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 190,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 191,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 200,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 203,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 210,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 215,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 219,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 222,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 229,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 232,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 238,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 245,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 249,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 252,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 257,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 264,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 266,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 274,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 279,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 283,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 290,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 291,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 298,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 301,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 309,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 314,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 317,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 322,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 328,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 333,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 336,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 345,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 348,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 353,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 359,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 365,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 369,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 374,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 378,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 382,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 388,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 392,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 399,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 402,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 406,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 411,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 420,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 421,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 426,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 434,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 437,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 441,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 448,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 453,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 457,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 463,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 470,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 472,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 477,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 484,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 489,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 495,
            ],
            [
                'id_user_tryout' => 3,
                'id_question_choice' => 498,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 2,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 8,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 12,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 16,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 23,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 27,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 32,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 37,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 43,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 47,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 52,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 59,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 62,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 68,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 73,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 78,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 82,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 86,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 91,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 98,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 102,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 107,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 111,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 117,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 121,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 126,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 133,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 136,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 141,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 148,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 153,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 158,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 162,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 168,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 172,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 177,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 183,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 186,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 191,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 198,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 203,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 208,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 212,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 218,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 223,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 226,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 231,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 237,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 242,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 248,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 252,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 257,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 261,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 267,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 273,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 276,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 281,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 287,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 291,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 297,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 302,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 308,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 311,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 316,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 321,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 327,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 333,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 337,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 342,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 346,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 352,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 356,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 361,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 367,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 372,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 382,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 386,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 392,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 396,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 402,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 408,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 412,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 416,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 423,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 428,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 434,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 437,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 444,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 448,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 453,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 458,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 463,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 466,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 473,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 478,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 483,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 487,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 491,
            ],
            [
                'id_user_tryout' => 4,
                'id_question_choice' => 498,
            ]
        ]);
    }
}
