<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UserTableSeeder::class);
        $this->call(QuestionPackageTableSeeder::class);
        $this->call(QuestionTypeTableSeeder::class);
        $this->call(QuestionTableSeeder::class);
        $this->call(QuestionChoiceTableSeeder::class);
        $this->call(InformationTableSeeder::class);
        $this->call(ModuleTableSeeder::class);
        $this->call(UserTryoutTableSeeder::class);
        $this->call(StudyGroupsTableSeeder::class);
        $this->call(StudentsTableSeeder::class);
    }
}
