<?php

use Illuminate\Database\Seeder;

class ModuleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('modules')->insert([
            [
                'module_header' => 'Materi TWK 1',
                'module_body' => 'berisi materi twk untuk pemantapan',
            ],
            [
                'module_header' => 'Materi TWK 2',
                'module_body' => 'berisi materi twk untuk pemantapan',
            ],
            [
                'module_header' => 'Materi TWK 3',
                'module_body' => 'berisi materi twk untuk pemantapan',
            ],
            [
                'module_header' => 'Materi TIU',
                'module_body' => 'berisi materi tiu untuk pemantapan',
            ],
            [
                'module_header' => 'Materi TKP ',
                'module_body' => 'berisi materi tkp untuk pemantapan',
            ],
        ]);
    }
}
