<?php

use Illuminate\Database\Seeder;

class QuestionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('questions')->insert([
            //1-35 TWK 35 Soal
            //1
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Berikut ini yang bukan termasuk ciri ideologi Pancasila adalah …',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Ciri khas ideologi Pancasila, yaitu dibentuk dengan keselarasan, keseimbangan, dan keserasian dalam setiap aspek kehidupan. Pancasila sebagai suatu ideologi tidak bersifat kaku dan tertutup, namun bersifat reformatif, dinamis, dan terbuka.',
            ],
            //2
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Memperhatikan kepentingan orang lain dengan sebaik-baiknya merupakan nilai Pancasila yang mengacu pada …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Memperhatikan kepentingan orang lain dengan sebaik-baiknya berarti tidak membedakan setiap orang berdasarkan strata sosial, kedudukan, jabatan, ras, suku, maupun agama merupakan ciri dari nilai pancasila berdasarkan hakikat keadilan sosial.',
            ],
            //3
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Nilai Pancasila yang sesuai dengan sila ke-3 adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Sila ke-3 Pancasila berbunyi "Persatuan Indonesia." Sikap yang sesuai dengan nilai Pancasila sila ke-3, salah satunya dengan ikut mewujudkan perdamaian dunia melalui hubungan kerja sama dengan bangsa lain karena dengan itu, Indonesia mampu menjaga Persatuannya dengan cara menjaga hubungan kerja sama dengan bangsa lain sehingga terwujudnya perdamaian dunia.',
            ],
            //4
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Ekaprasetya Pancakarsa merupakan Pedoman Penghayatan dan Pengamalan Pancasi I a (P4) berdasarkan Ketetapan MPR Nomor II/MPR/1978 ditetapkan pada …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pedoman Penghayatan dan Pengamalan Pancasila atau dikenal P4 yang juga dinamakan Ekaprasetya Pancakarsa merupakan wujud pengamalan kelima sila Pancasila yang tercantum dalam Ketetapan MPR Nomor II/MPR/1978 yang ditetapkan pada tanggal 22 Maret 1978.',
            ],
            //5
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Pada alinea ke-4 Pembukaan UUD 1945, dijelaskan bahwa Pancasila sebagai ….',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Dalam Pembukaan UUD 1945 alinea ke-4, dijelaskan bahwa Pancasila sebagai dasar negara dan juga pandangan hidup yang memiliki nilai-nilai serta memberikan arah serta tujuan menuju masyarakat yang adil dan makmur.',
            ],
            //6
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Untuk pertama kalinya presiden dan wakil presiden dipilih oleh PPKI, hal tersebut berdasarkan aturan peralihan …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Sehari setelah kemerdekaan Indonesia pada 18 Agustus 1945, diadakan rapat pleno oleh anggota PPKI dan menghasilkan dua keputusan penting. Berdasarkan aturan peralihan pasal 3 UUD 1945, dinyatakan bahwa presiden dan wakil presiden dipilih oleh PPKI (Panitia Persiapan Kemerdekaan Indonesia).',
            ],
            //7
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Pasal yang secara tegas melarang dilakukannya perubahan UUD 1945 yang mengatur tentang amandemen UUD 1945 adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pasal 37 ayat 3 UUD 1945 menegaskan bahwa tidak dibenarkan melakukan perubahan UUD 1945 yang mengatur tentang amandemen UUD 1945.',
            ],
            //8
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Undang-undang RI No. 26 Tahun 2000 mengatur tentang …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Undang-undang RI No. 26 Tahun 2000 mengatur tentang pengadilan Hak Asasi Manusia di Indonesia',
            ],
            //9
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => ' Fungsi DPR tercantum dalam UUD 1945, yaitu …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Fungsi DPR adalah fungsi legislasi, fungsi anggaran, dan fungsi penawaran. Fungsi ini tercantum dalam UUD 1945 Pasal 20 A ayat 1.',
            ],
            //10
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'UU No. 12 Tahun 2006 tentang Kewarganegaraan RI menjelaskan orang asing dapat menjadi WNI jika memenuhi syarat yang diatur dalam peraturan perundang-undangan, kecuali …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'UU No. 12 Tahun 2006 tentang Kewarganegaraan Republik Indonesia menjelaskan bahwa orang asing dapat menjadi Warga Negara Indonesia jika memenuhi syarat dan tata cara yang diatur dalam peraturan perundang-undangan, di antaranya:
                - Telah berusia 18 tahun atau sudah kawin
                - Sudah bertempat tinggal di wilayah negara RI paling singkat 5 tahun berturut-turut atau 10
                tahun tidak berturut-turut
                - Dapat berbahasa Indonesia dan mengakui dasar negara Pancasila dan UUD 1945
                - Tidak pernah dijatuhi hukuman pidana yang diancam pidana penjara 1 tahun atau lebih
                - jika memperoleh kewarganegaraan Indonesia tidak menjadi berkewarganegaraan ganda
                - Mempunyai pekerjaan atau penghasilan tetap
                - Membayar uang pewarganegaraan ke Kas Negara',
            ],
            //11
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Berikut ini yang tidak termasuk hukum perdata adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Hukum perdata meliputi:
                - Hukum perorangan
                - Hukum keluarga
                - Hukum waris
                - Hukum kekayaan',
            ],
            //12
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Pengadilan kasasi merupakan fungsi dari pengadilan tinggi …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pengadilan tinggi rakyat pertama adalah Pengadilan Negeri, sedangkan pengadilan banding dan kasasi merupakan Pengadilan Tinggi Mahkamah Agung.',
            ],
            //13
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Mahkamah Agung tidak berwenang untuk menguji peraturan perundang-undangan yang berlaku terhadap …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pasal 24A UUD 1945 menyebutkan Mahkamah Agung berhak mengadili tingkat pengadilan banding dan kasasi, menguji peraturan perundang-undangan di bawah undangundang, serta wewenang lain yang diberikan undang-undang, seperti Peraturan Pemerintah, Keputusan Presiden, dan Keputusan Daerah.',
            ],
            //14
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Hukum yang mengatur hubungan antara orang-orang yang menjadi pejabat pemerintahan adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Hubungan antara orang-orang yang menjadi pejabat pemerintahan merupakan hal yang berhubungan dengan kepentingan umum. Hukum yang mengatur hal tersebut adalah hukum publik. Selain mengatur kepentingan umum seperti politik dan pemilu, hukum publik juga mengatur kegiatan pernerintahan sehari-hari.',
            ],
            //15
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Berikut ini yang bukan fungsi hukum di Indonesia adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Fungsi hukum di Indonesia, antara lain:
                - Sebagai alat kontrol sosial
                - Sebagai alat kritik dan perubahan sosial
                - Sebagai sarana untuk mewujudkan keadilan sosial
                - Sebagai alat penata ketertiban dan keteraturan masyarakat
                - Untuk melindungi kepentingan manusia
                - Untuk menyelesaikan pertikaian',
            ],
            //16
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Perjanjian antar dua negara atau lebih menyangkut bidang ekonomi dan politik disebut …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Hak yang dimiliki anggota DPRD, antara lain:
                • Hak interpelasi
                • Hak angket
                • Hak menyatakan pendapat untuk mengajukan rancangan Perda
                • Hak memilih dan dipilih
                • Hak imunitas',
            ],
            //17
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Mencetak uang dan menentukan nilai mata uang merupakan kewenangan pemerintah pusat dalam menyelenggarakan daerah otonom dalam bidang',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Kewenangan pemerintah pusat sebagai daerah otonom mencakup kewenangan dalam bidang politik luar negeri, pertahanan dan keamanan, peradilan, moneter dan fiskal, agama, serta kewenangan bidang lain. Mencetak uang dan menentukan nilai mata uang merupakan kewenangan pemerintah pusat dalam bidang fiskal.',
            ],
            //18
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Teori perseorangan tentang pengertian negara dikemukakan oleh beberapa tokoh berikut, kecuali …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Teori Perseorangan tentang pengertian negara mengemukakan bahwa negara adalah suatu masyarakat hukum yang disusun berdasarkan bidang Tata Negara perjanjian antarindividu yang menjadi anggota masyarakat. Penganjur teori ini, yaitu Thomas Hobbes, John Locke, Jean Jacques Rousseau, Harold J Laski, dan Herbert Spencer.',
            ],
            //19
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Kepercayaan Animisme di Indonesia berakulturasi dengan budaya Hindu-Buddha dalam bentuk …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Kepercayaan animisme merupakan kepercayaan terhadap roh nenek moyang. Kepercayaan animisme yang ada di Indonesia, berakulturasi dengan budaya Hindu-Buddha, salah satunya dalam bentuk patung dan arca-arca yang dipercaya sebagai wujud roh nenek moyang.',
            ],
            //20
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Peristiwa Perang Bubat terjadi pada masa pemerintahan …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Peristiwa Bubat atau Yang dikenal Perang Bubat adalah perselisihan antara Gajah Mada dengan Raja Pajajaran yang terjadi pada masa pemerintahan Raja Majapahit, yaitu Hayam Wuruk. Perang terjadi di pesanggrahan Bubat sehingga dikenal dengan sebutan Perang Bubat.',
            ],
            //21
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => ' Sebelum terjadinya Peristiwa Rengasdengklok, terjadi perbedaan pendapat antara kelompok pejuang senior dengan kelompok pemuda. Kelompok pejuang senior berpendapat bahwa …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Setelah Jepang mengalami kekalahan di berbagai kawasan, muncul perbedaan antar kelompok pejuang mengenai masalah proklamasi Kemerdekaan Indonesia.
                • Kelompok pejuang senior, Yaituo kelompok anggota PPKI yang dipimpin oleh lr. Soekarno dan Drs. Moh. Hatta yang berpendapat proklamasi kemerdekaan harus dipersiapkan secara matang dan harus dibicarakan dalam rapat PPKI terlebih dahulu.
                • Kelompok pejuang bawah tanah yang dipimpin oleh Sutan Syahrir dan kelompok pemuda yang dipimpin oleh Chaerul Saleh berpendapat proklamasi kemerdekaan harus dilaksanakan secepat mungkin tanpa menunggu rapat PPKI yang dibentuk oleh Jepang.',
            ],
            //22
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Berikut ini yang bukan tahapan dari diadakannya perjanjian internasional adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Tahapan-tahapan yang harus dilakukan dengan diadakannya perjanjian internasional:
                - Perundingan (Negotiation)
                - Penandatanganan (Signature)
                - Pengesahan (Ratification)',
            ],
            //23
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Konferensi Asia Afrika atau yang dikenal KAA dilaksanakan pertama kali di Bandung pada tahun …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Sebelum KAA diselenggarakan, terlebih dahulu telah diadakan pertemuan di Colombo, Srilanka, pada 28 April - 2 Mei 1954. Hasil pertemuan yang dikenal konferensi Colombotersebut adalah kesepakatan untuk menyelenggarakan konferensi lanjutan negara-negara Asia Afrika. Oleh karena itu, pada 18 April – 24 ApriI 1955 diadakan Konferensi antara negara-negara Asia-Afrika yang dikenal dengan KAA atau Konferensi Asia-Afrika.',
            ],
            //24
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Agenda pokok pembicaraan KAA di antaranya, kecuali …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pokok-pokok agenda pembicaraan pada KAA, di antaranya:
                - Kerja sama ekonomi
                - Kerja sama budaya
                - Masalah perdamaian dunia dan kerja sama internasional (termasuk beberapa aspek
                tentang PBB, masalah indocina, dan pelucutan senjata)
                - Masalah kolonialisme dan imperialisme seperti Belanda di Irian Barat.',
            ],
            //25
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Tanggal 1 Mei merupakan hari buruh dunia. Wadah yang menampung isu buruh internasional yang berada di bawah PBB adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Suatu wadah yang dibuat untuk menampung isu buruh internasional yang berada di baswah PBB adalah International Labour Organization (ILO). ILO atau Organisasi Buruh Internasional didirikan dengan tujuan mengusahakan keadilan sosial ekonomi dan meningkatkan taraf hidup pekerja (buruh). ILO menjadi bagian PBB setelah pembubaran LBB dan dibentuknya PBB pada akhir Perang Dunia II. Sekretariat organisasi ILO dikenal sebagai Kantor Buruh Intemasional.',
            ],
            //26
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => '(1) Para peneliti mengemukakan bahwa area otak untuk bernyanyi berbeda dengan area otak untuk berbicara. (2) Mereka menyajikan temuan mereka tersebut pada pertemuan American Association for the Advancement of Science di San Diego. (3) Jika pusat bicara seseorang rusak oleh stroke, ia dapat belajar menggunakan pusat bernyanyinya. (4) Dalam uji coba klinis, para peneliti menunjukkan cara otak merespons terapi intonasi melodi. (5) Gottfried Schlaug, profesor neurologi Beth lsrael Deaconess Medical Center dan Harvard Medical School di Boston Amerika Serikat memimpin uji coba tersebut. (6) Penelitian itu menemukan bahwa pasien stroke dengan kerusakan otak membuat pasien tidak bisa bicara tetapi bisa bernyanyi. Kalimat utama paragraf di atas adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Kalimat utama paragraf tersebut terdapat pada kalimat pertama, yaitu para peneliti mengemukakan bahwa area otak untuk bernyanyi berbeda dengan area otak untuk berbicara. Adapun kalimat 2 sampai dengan 6 merupakan kalimat penjelas. Kalimat utama menjadi hal yang paling umum dibicarakan dalam paragraf.',
            ],
            //27
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Fisika plasma merupakan salah satu bidang fisika yang ….. gas terionisasi, yang dikenal sebagai plasma. Dalam fisika dan kimia, plasma adalah fase-gas berenergi yang sering ditunjuk sebagai “keadaan benda keempat”, yang beberapa atau semua elektron di orbit atom terluar telah ….. dari atom atau molekul. Hasilnya, sebuah koleksi ion dan elektron yang tidak lagi ….. satu dengan yang lain. Urutan kata yang tepat untuk melengkapi teks di atas adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Kata mempelajari, keadaan, terpisah, dan terikat secara berurutan merupakan kata-kata
                yang tepat untuk mengisi bagian yang kosong sehingga wacana dapat menjadi kohesif dan
                koherensif.',
            ],
            //28
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Sejumlah pengusaha sepatu keci I menengah di Kabupaten Mojokerto mengalami kesul itan menghadapi aturan perdagangan bebas atau Free Trade Agreement (FTA) ASEAN — China. Mereka mengaku merugi sejak isu itu digulirkan pada awal Januari lalu. Para pedagang mengalami dampak negatif aturan itu. Pada sektor usaha kecil sepatu, misalnya, pengusaha merugi sampai 50%. “Orderan berkurang 50%. Artinya, produksi kami juga berkurang sebesar itu,” kata Budi Utomo, anggota Gabungan Pengusaha Sepatu (GPS) Kabupaten Mojokerto. Sepinya order terjadi karenasebagian besarpelanggan tidak melakukan pemesanan karena menunggu masuknya produk sepatu impor. Alasannya, harga produk impor lebih murah daripada harga produk lokaI.
                Pernyataan berikut yang tidak sesuai dengan isi paragraf di atas adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pernyataan yang tidak sesuai dengan isi paragraf adalah banyak pelanggan pengusaha sepatu di Kabupaten Mojokerto menghentikan permintaan pesanan karena menunggu pelaksanaan FTA ASEAN -China. Hal itu karena fakta yang benar dalam paragraf adalah sebagian besar pelanggan menunggu masuknya produk sepatu impor.',
            ],
            //29
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Affandi dilahirkan di Cirebon pada 1907. Affandi adalah putra R. Koesoema, seorang mantri ukur di pabrik gula Ciledug, Cirebon. Affandi memiliki pendidikan formal yang cukup tinggi. Bagi orang-orang segenerasinya, hanya segelintir anak negeri saja yang memperoleh pendidikan HIS, MULO, dan AMS. Akan tetapi, bakat seni lukisnya yang sangat kuat mengalahkan disiplin ilmu lain dalam kehidupannya. Bakat itu menjadikan nama Affandi tenar, sama dengan nama-nama tokoh atau pemuka bidang lainnya. Sebelum menjadi pelukis, Affandi pernah menjadi guru, tukang sobek karcis, dan pembuat gambar reklame bioskop di salah satu gedung bioskop di Bandung. Pekerjaan tersebut tidak lama ia geluti karena Affandi lebih tertarik pada seni Iukis. Sekitar tahun 30-an, Affandi bergabung dalam kelompok Lima Bandung, yaitu kelompok Iima pelukis Bandung. Kelompok ini memiliki andil besar dalam perkembangan seni rupa Indonesia. Pernyataan berikut yang sesuai dengan isi teks di atas adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pernyataan yang paling sesuai dengan isi teks terdapat di pilihan jawaban C. Pernyataan di pilihan C sesuai dengan isi paragraf kalimat kedelapan, yaitu "Pekerjaan tersebut tidak lama ia geluti karena Alfandi lebih tertarik Pada seni lukis". Jadi, melukis menjadi pekerjaan paling lama digeluti Affandi dalam hidupnya.',
            ],
            //30
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Peningkatan kesejahteraan masyarakat merupakan tanggung jawab bersama antara pemerintah dan masyarakat. Baik pria maupun wanita, hendaknya selalu meningkatkan rasa tanggung jawab mereka terhadap kesejahteraan bersama. Kader-kader wanita diharapkan juga peduli terhadap kesejahteraan masyarakat pada umumnya. Banyak kaum wanita yang terpaksa bekerja karena suami mereka terkena PHK. Untuk itu, pemerintah perlu memerhatikan nasib kaum wanita yang suami mereka terkena PHK. lde pokok paragraf tersebut adalah …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'lde pokok / tema wacana tersebut terdapat pada kalimat utama, yaitu pada awal paragraf. Paragraf ini merupakan paragraf berpola deduktif sehingga ide pokok ada di awal paragraf, yakni pemerintah dan masyarakat bertanggung jawab terhadap kesejahteraan masyarakat.',
            ],
            //31
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Kesadaran akan nasionalisme terkadang membelenggu dan menghambat rakyat dan pemerintahan sendiri. Hal ini bisa terjadi ketika...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Hambatan yang bisa menjadi serius ketika memahami nasionalisme adalah ketika pemahaman nasionalisme didaIami sebagai sebuah ideologi, bukan sebagai semangat, pola perilaku, dan cara pandang terhadap negeri atau bangsa. Jika demikian, akan menimbulkan sikap kapitalis bahkan cenderung individualistis.',
            ],
            //32
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Bentuk nasionalisme salah satunya adalah nasionalisme kewarganegaraan yang subjeknya adalah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Bentuk nasionalisme kewarganegaraan yang dikenal dengan nasionalisme Sipil subjeknya adalah rakyat sipil. Nasionalisme kewarganegaraan adalah nasionalisme yang memiliki kebenaran politik dari, oleh, dan untuk rakyatnya dalam keaktifan berbangsa dan bernegara.',
            ],
            //33
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Paham integralistik sebagai semangat nasionalisme yang mengalir pertama kali dikemukakan oleh . . . pada sidang BPUPKI.',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Soepomo sebagai aktor dan pahlawan Indonesia dari kaum terpelajar yang mencetuskan pertama kali tentang paham integralistik pada sidang BPUPKI dalam merumuskan bentuk negara kesatuan bukan federal.',
            ],
            //34
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Salah satu lagu nasional yang menggambarkan Bhinneka Tunggal Ika melalui keindahan alam Indonesia adalah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Lagu yang melambang keindahan alam Indonesia yang paling terkenal adalah lagi Rayuan Pulau Kelapa yang diciptaka oleh Ismail Marzuki. Lirik dari lagu ini menceritakan hampir semua kelebihan dan potensi yang dimiliki oleh Indonesia dari alamnya. Pulau Kelapa yang dijadikan sebagai icon dalam liriknya adalah penggambaran jajaran pohon kelapa yang menghiasi panjangnya pantai Indonesia dari Sabang hingga Merauke.',
            ],
            //35
            [
                'id_question_package' => '1',
                'id_question_type' => '1',
                'question' => 'Pengakuan terhadap keberagaman agama dan keyakinan di negara Indonesia merupakan perwujudan dari semangat nasionalisme dalam mempersatukan keberagaman nasional. Semangat ini dilandasi bahwa..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pengakuan terhadap keberagaman agama yang dimiliki oleh Indonesia dan dituangkan dalam dasar negara merupakan perwujudan keberagaman yang diakui bahwa agama merupakan nilai positif bagi warga negara yang harus dijamin.',
            ],
            //36-65 TIU 30 Soal
            //36
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => ' EKUATOR = …',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'garis yang ditarik pada peta bumi untuk menggambarkan titik-titik yang sarna jaraknya dari kutub utara ke kutub selatan',
            ],
            //37
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'DEPUTI = …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'orang yang diangkat sebagai wakil atau pengganti dengan kuasa jabatan untuk bertindak',
            ],
            //38
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'DELUSI > < …',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'pikiran atau pandangan yang tidak berdasar (tidak rasional)',
            ],
            //39
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'DETERIORASI > < …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'kemunduran; penurunan mutu',
            ],
            //40
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'SUNGAI : NIL = GUNUNG : ….',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Sungai terpanjang di dunia adalah Sungai Nil, gunung tertinggi di dunia adalah Everest.',
            ],
            //41
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'BUNGLON : MIMIKRI = AUTOTOMI : …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Mimikri adalah cara mempertahankan diri bunglon dari musuh, sedangkan autotomi
                adalah cara pertahanan diri cicak',
            ],
            //42
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'BUKU : NOVEL : DETEKTIF = ….. : ….. : …..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Salah satu jenis buku adalah novel. Salah satu jenis novel adalah tentang detektif.',
            ],
            //43
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Merupakan kelompok heman mamalia (menyusui). Ayam tidak termasuk hewan
                menyusui.',
            ],
            //44
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => ' Merupakan kelompok peralatan pertukangan. Paku termasuk dalam kategori bahan.',
            ],
            //45
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => ' Merupakan kelompok peralatan pertukangan. Paku termasuk dalam kategori bahan.',
            ],
            //46
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'Arnold harus membayar Rp 10.000,00 untuk pembelian 5 buku dan 5 pensil. Anita membayar Rp 11.900,00 untuk pembelian 7 buku dan 4 pensil. Berapakah yang harus dibayar oleh Wulan bila ia membeli 10 buku dan 5 pensil? Wulan harus membayar seharga …',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Caranya :
                misal buku = b dan pensil = p maka
                5 buku dan 5 pensil, 5b + 5p = 10.000….x4
                7 buku dan 4 pensil, 7b + 4p = 11.900….x5
                menjadi :
                20b + 20p = 40.000
                35b + 20p = 59.500
                – 15b = – 19.500
                b = 19.500 / 15
                b = 1300
                5b + 5p = 10.000
                5(1300) + 5p = 10.000
                6.500 + 5p = 10.000
                5p = 10.000 – 6.500
                5p = 3500 maka P = 700
                jadi, 10 buku dan 5 pensil = (10 x 1.300 )+(5 x 700 )
                = 13.000 + 3500 = 16.500,-',
            ],
            //47
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'Pada hari Minggu, Deni bermain sepeda di halaman rumahnya. Jari-jari roda sepeda yang digunakan oleh Deni 42 cm. Jika selama bersepeda rodanya berputar sebanyak 50 kali, panjang lintasan yang dilalui ialah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pembahasan : keliling roda = keliling
                lingkaran = 2лR
                Keliling roda = 2 x 22/7 x 42 = 264 cm
                lima puluh kali putaran = 50 x 264 = 13.200 cm
                = 132 m.',
            ],
            //48
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '1/4 berbanding 3/5 adalah ...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => '¼ : 3/5 = ¼ x 5/3 = 5/12.
                Jawabannya : 5 berbanding 12',
            ],
            //49
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'Sebuah wadah berbentuk silinder dan berisi air 1/5 nya. Jika ditambah dengan 6 liter air, temyata wadah tersebut terisi 1/2 nya. Berapa liter kapasitas wadah tersebut ?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'y = air , x = wadah
                y = ⅕x
                y + 6 = ½x
                (⅕x) + 6 = ½x…..dikali 5
                x + 30 = 2,5 x
                30 = 2,5 x – x
                30 = 1,5 x
                x = 30/1,5 = 20',
            ],
            //50
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '7,7 : 2,5 – (2/4 x ¾) =',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => '7,7 : 2,5 – (2/4 x ¾)=
                75 : 25 = 3
                -1/2 x 3/4 = 3/8,
                maka 3 – 3/8 = mendekati 3
                jawaban yang mendekati 2,625.',
            ],
            //51
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'Upah rata-rata 7 orang pekerja Rp 25.000,00 per hari. Jika ada tambahan satu orang pekerja, rata-rata upahnya menjadi Rp 23.750,00 per hari, maka upah pekerja baru tersebut ialah',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Caranya :
                jumlah upah 7 orang =7 x Rp.25.000,-
                =Rp.175.000,-
                jumlah upah 8 orang =8 x Rp.23.750,-
                =Rp.190.000,-
                Maka upah 1 orang pekerja tambahan
                =Rp.190.000 – Rp.175.000 = Rp.15.000,-',
            ],
            //52
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'Sebuah pabrik merencanakan membuat sepatu dan sandal. Jika jumlah barang tersebut adalah 1200 pasang dan jumlah sepatu 4 kali lipat dari jumlah sandal, berapa pasang sepatu yang akan dibuat?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Misal sepatu = U dan sandal = L .
                Jumlah sepatu sama dengan 4 kali jumlah sandal,
                U = 4L
                U + L = 1200
                4L + L = 1200
                5L = 1200
                L = 240
                karena U = 4L maka U = 4 x 240 = 960 pasang',
            ],
            //53
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '1/9 1/3 1 3 9 27 …. ….',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pola dikalikan 3.',
            ],
            //54
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '12 9 9 8 6 7 …. ….',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Pola ada 2 deret: (1) dikurangi 3; (2) dikurangi 1.',
            ],
            //55
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'A B D B B D C B D D B D …. ….',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Urutan abjad A,B,C,D,E, dst . . . Diselingi BD',
            ],
            //56
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '56.png',
                'choice_type' => 'img',
                'answer' => 'Bila dianalisis, gambar 1, gambar 2, gambar 3 dan gambar 5 merupakan gambar yang terbentuk dari tiga garis yang saling dihubungkan. Oleh sebab itu, maka gambar yang tidak sesuai dengan gambar lainnya adalah gambar 4.
                Alasannya karena gambar 4 merupakan gambar yang terbentuk dari dua garis yang saling dihubungkan. Pilihan jawaban yang memuat gambar 4 terdapat dalam pilihan jawaban d.',
            ],
            //57
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '57.png',
                'choice_type' => 'img',
                'answer' => 'Ingat rumus "Lihat Pilihan bangun ruang dan petakan di jaring".  Jika di lihat, dalam jaring adalah bangun prisma segi empat dengan sisi berbentuk sama kaki. Lihat di jaring bagian ujung gambar sebelah kanan, itu adalah kuncinya.',
            ],
            //58
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '58.png',
                'choice_type' => 'img',
                'answer' => 'Perhatikan 4 buah gambar kecil yang ada di kotak besar pertama, dikotak besar kedua ternyata salah satu gambar kecil membelah menjadi 2 bagian. Begitu pula untuk kotak besar ketiga satu gambar kecil membelah lagi menjadi 2 bagian juga.',
            ],
            //59
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => 'perhatikan gambar persegi PQRS dan persegi KLMN. Panjang PQ=12cm, LM=5cm dan KL=10cm. Luas daerah yang tidak diarsir adalah 156cm persegi, luas daerah yang diarsir adalah..',
                'question_image' => '59.png',
                'choice_type' => 'text',
                'answer' => 'Luas daerah tidak diarsir = Lpp + Lp - 2(Luas terarsir)<br>
                156 = (12x12) + (5x10) - 2(Luas terarsir)<br>
                156 = 144 + 50 - 2(Luas terarsir)<br>
                156 = 194 - 2(Luas terarsir)<br>
                -38 = -2Luas terarsir<br>
                19cm^2 = Luas terarsir',
            ],
            //60
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '60.png',
                'choice_type' => 'text',
                'answer' => 'Jawaban a,c,d,e mempunyai bentuk yang sama, hanya berbeda di letak posisi karena rotasi',
            ],
            //61
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '61.png',
                'choice_type' => 'text',
                'answer' => 'Jawaban b, c, d, e mempunyai bangun luar dan dalam yang sama',
            ],
            //62
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '62.png',
                'choice_type' => 'text',
                'answer' => 'bangun belah ketupat berpindah ujung dan berubah warna, begitu juga dengan irisannya',
            ],
            //63
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '63.png',
                'choice_type' => 'img',
                'answer' => 'kolom 1 berasal dari gabungan kolom 2 dan 3',
            ],
            //64
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '64.png',
                'choice_type' => 'img',
                'answer' => 'hubungan = dirotasi 90˚searah jarum jam',
            ],
            //65
            [
                'id_question_package' => '1',
                'id_question_type' => '2',
                'question' => '',
                'question_image' => '65.png',
                'choice_type' => 'img',
                'answer' => 'mengecil secara proporsional',
            ],
            //66-100 TKP 35 Soal
            //66
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda diminta oleh atasan untuk membuat sebuah laporan pelaksanaan tugas. Namun, ketika Anda hendak mencetak laporan dimaksud, file laporan yang Anda buat tiba-tiba corrupt karena terkena virus, sedangkan atasan Anda meminta laporan tersebut segera. Apa yang akan Anda lakukan ?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Berdasarkan soal tersebut, Anda sedang diminta untuk membuat sebuah laporan dan Anda telah menyelesaikan pembuatan laporan dimaksud. Namun ketika hendak mencetak laporan yang telah anda selesaikan, file laporan tersebut tiba-tiba corrupt karena terkena virus sehingga tidak bisa dicetak.

                Disisi lain atasan Anda meminta segera laporan dimaksud, maka tindakan efektif yang seharusnya dilakukan adalah tindakan yang secara efektif dapat menyelesaikan masalah tersebut dalam waktu yang singkat.
                
                Pilihan jawaban a merupakan jawaban yang cukup tepat. Namun, mencari solusi permasalahan melalui google dalam kondisi ini bukan cara yang terbaik, mengingat kita harus browsing mencari dan mencoba cara mana yang tepat untuk diimplementasikan dan hal tersebut membutuhkan waktu yang relatif lama dan belum tentu menyelesaikan masalah Anda secara efektif mengingat laporan harus segera diberikan kepada atasan.
                
                Pilihan jawaban b merupakan jawaban yang tepat. Alasannya karena meminta bantuan kepada orang yang tepat dan ahlinya merupakan solusi yang tepat pada kondisi ini.
                
                Pilihan jawaban c merupakan jawaban yang tidak tepat. Alasannya, karena file Anda sudah terkena virus, walaupun dipindahkan ke flash disk tetap akan ada virus bahkan bisa jadi menyebarkan virus ke file lain yang ada di flash disk.
                
                Pilihan jawaban d adalah jawaban yang tepat. Alasannya, karena dalam soal tersebut atasan Anda meminta laporan segera, maka ketika ada permasalahan dengan laporan yang dibuat, Anda segera laporan kepada atasan sehingga beliau mengetahui sudah sejauhmana laporan yang dibuat. 
                
                Pilihan jawaban e mirip dengan pilihan jawaban b. Namun perbedaannya, pada jawaban b Anda meminta kepada ahlinya sedangkan pada jawaban e Anda meminta kepada orang yang belum tentu ahli sedangkan laporan harus segera diberikan kepada atasan.
                
                Berdasarkan uraian tersebut, pilihan jawaban b dan d adalah jawaban yang sama-sama tepat. Namun, dalam kondisi ketika file laporan tiba-tiba corrupt karena terkena virus dan laporan harus segera diberikan kepada atasan sebaiknya segera memanggil tim IT untuk menangani permasalahan dimaksud daripada segera melaporkan kepada atasan yang menimbulkan kepanikan dan atasan Anda marah karena kelalaian Anda yang menyebabkan file corrupt dan terkena virus.
                
                Kemudian apabila diteliti secara lebih seksama, pilihan jawaban b lebih menawarkan solusi daripada pilihan jawaban d yang cenderung memberitahu saja bahwa file belum bisa dicetak karena corrupt karena terserang virus, tanpa ada solusi yang ditawarkan untuk memperbaiki file dimaksud.
                
                Kemudian pertimbangan lainnya, bahwa atasan tidak sedang berada di hadapan Anda sehingga pilihan jawaban b lebih tepat pada kondisi ini. Jawaban b.',
            ],
            //67
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda sedang mengerjakan sebuah tugas dengan suatu aplikasi. Tiba-tiba ditengah jalan aplikasi tersebut error sehingga mengganggu pekerjaan. Anda akan....',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban Yang Paling Tepat Adalah Langsung menutup aplikasi tersebut agar tidak banyak data yang hilang
                soal ini menguji tentang skala inisiatif. di khawatirkan apabila aplikasi tetap dijalankan, data yang tersimpan akan hilang.',
            ],
            //68
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Banyak perusahaan yang berlomba-lomba untuk mengikuti perubahan dengan penggunaan teknologi informasi dalam aktivitas pekerjaan sehari-hari. Namun penggunaan teknologi informasi di perusahaan anda tidak signifikan, serta kurang bisa memajukan kinerja karyawan dan perusahaan yang anda pimpin. Sikap anda sebagai pemimpin pada perusahaan tersebut adalah',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => '

                Jawaban yang paling tepat adalah Memberi memotivasi dan diklat seluruh anggota/karyawan untuk terus meningkatkan ilmu tentang teknologi informasi.
                
                Ketika kita diperintahkan untuk memimpin sesuatu artinya kita diberikan kepercayaan bahwa kita bisa memimpin hal tersebut maka yang harus dilakukannya adalah membuat suatu hal untuk mendongkrak tim terebut seperti berusaha menyemangati tim saya, dan memberi memotivasi dan diklat seluruh anggota/karyawan untuk terus meningkatkan ilmu tentang teknologi informasi.
                ',
            ],
            //69
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Dalam perkembangan teknologi informasi di masa kini terutama dalam dunia kerja, ketika mengakses internet utamanya Anda adalah orang yang',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban paling tepat adalah menggunakan fasilitas internet sebagai sarana untuk menghasilkan uang.
                pada soal ini membahas tentang aspek peluang.
                karena orang bekerja untuk menghasilkan uang, dan mereka menggunakan fasilitas internet untuk menghasilkan uang.',
            ],
            //70
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Kantor tempat saya bekerja meminta laporan harian secara online, sementara saya adalah bekerja di lapangan yang kadang terkendala sinyal untuk melaporkan kegiatan. Saya akan....',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah berusaha mencari tempat dengan sinyal bagus untuk dapat melaporkan sesuai ketentuan kantor.pada soal ini membahas tentang aspek inisiatif dan aspek tanggung jawab.',
            ],
            //71
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Atasan meminta saya untuk membuat laporan hasil kerja melalui aplikasi berbasis internet, sementara saya terbiasa membuat laporan dengan print out hasil ketikan komputer. Saya akan...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban paling tepat adalah Belajar untuk membuat laporan hasil kerja melalui aplikasi. soal ini membahas tentang aspek inisiatif dan tanggung jawab. Dikarenakan tidak ada salahnya mencoba hal yang baru demi suatu kemajuan bersama untuk hal yang lebih baik',
            ],
            //72
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Kantor saya sepakat untuk membuat grup di sebuah program jejaring sosial untuk mempermudah komunikasi dan berbagi informasi. Sementara gadget saya belum mendukung untuk program tersebut. Saya akan....',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban paling tepat adalah Segera mengganti gadget saya supaya bisa ikut ke dalam grup tersebut. soal ini membahas tentang aspek inisiatif dan tanggung jawab. Dikarenakan tidak ada salahnya mencoba hal yang baru demi suatu kemajuan bersama untuk hal yang lebih baik.',
            ],
            //73
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Andi adalah seorang Kabag di suatu Dinas di Kabupaten Lumbung, Andi dikenal orang cukup patuh kepada atasan. Suatu hari atasannya yang bernama Yanto pergi keluar kota untuk urusan Dinas yang cukup rahasia. Andi diminta mengawasi pegawai secara ketat, hal ini ditekankan oleh Yanto karena ia mendapat laporan bahwa banyak karyawan yang sering terlambat datang dan pulang sebelum waktunya. Yanto juga berpesan agar Andi tidak memberitahukan kepada siapapun kemana ia pergi karena tugas yang diembannya sangat rahasia. Andi menyatakan kesanggupannya untuk mengawasi karyawan dan memegang rahasia tersebut. Pada hari pertama Yanto pergi, Andi menemukan 5 karyawan yang datang terlambat dan 7 orang pulang sebelum waktunya. Pada hari kedua datang tamu dari provinsi yang mempunyai urusan penting berkaitan dengan tugas, dan harus diselesaikan hari itu juga. Ia memaksa Andi untuk memberitahukan kemana Yanto karena sejak dua hari Yanto tidak dapat dihubungi. Jika anda Andi, tindakan apa yang akan anda lakukan dalam menghadapi tamu dari Provinsi?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'awaban yang paling tepat adalah Mengatakan kepada tamu dari Provinsi diri anda tidak memiliki kewenangan untuk informasi. Soal ini membahas tentang aspek tanggungjawab dan kepercayaan. hal ini bertujuan untuk tetap menjaga kepercayaan dengan baik dan tetap berpegang teguh dalam tanggung jawab.',
            ],
            //74
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Saya adalah seorang teknisi pada sebuah perusahaan teknologi terkemuka. Suatu hari terjadi kerusakan mesin yang sangat vital pada kantor cabang kami, dan harus diselesaikan dengan segera. Padahal saat itu saya sedang mengerjakan perbaikan pada mesin di kantor lain yang jaraknya sangat jauh. Saya akan...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban paling tepat adalah Menghubungi rekan teknisi yang dekat dengan lokasi mesin dan memintanya untuk memperbaikinya.
                Pada soal ini membahas tentang aspek inisiatif dan tanggungjawab, agar permasalahan segera terselesaikan dan dapat kembali beraktifitas tanpa ada halangan',
            ],
            //75
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Saat pulang Kantor, anda ditugaskan panitia seminar untuk memberitahukan kepada rekan kerja melalaui SMS sebelum jam 24.00 untuk agenda seminar besok pagi dengan dresscode. Pagi hari H anda lupa untuk SMS mereka, sebagai pengemban amanat maka anda sebaiknya.',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling benar adalah Mengumumkannya di Grup Kantor.
                soal ini membahas tentang aspek inisiatif. ',
            ],
            //76
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Rekan team kerja anda dimarahi oleh atasan pada saat mengumpulkan tugas team karena sudah telat beberapa menit mengumpulkan tugasnya. Hal ini disebabkan karena rekan anda tersebut harus menggabungkan pekerjaan tersebut terlebih dahulu sebelum dikumpulkan ditambah lagi semua rekan anggota team mengumpulkan tugas pribadi mereka juga terlambat, sehingga rekan anda yang bertugas untuk menggabungkan setiap pekerjaan jadi tidak menyelesaikan pekerjaannya tepat waktu, sikap anda',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Mengakui kesalahan kepada atasan jika anda juga turut berkontribusi pada masalah tersebut. soal ini membahas tentang aspek inisiatif dan tanggungjawab. tetap mengakui kesalahan dan memperbaiki segera agar permasalahan lekas terselesaikan.',
            ],
            //77
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda memiliki seorang teman yang bercerita kepada anda dan mengeluhkan suami nya yang pecandu narkoba. Dan memohon bantuan karena dia sudah kehabisan cara menghadapi suami nya. Anda sangat prihatin melihat teman anda yg sangat tertekan itu.
                Anda memiliki sahabat yang bekerja di Lembaga yang merehabilitasi pecandu narkotika maka tindakan anda...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang paling tepat adalah menyarankannya agar segera mendaftar di lembaga rehabilitasi tersebut. soal ini membahas tentang aspek kepedulian dan inisiatif. ',
            ],
            //78
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Rekan team kerja anda dimarahi oleh atasan pada saat mengumpulkan tugas team karena sudah telat beberapa menit mengumpulkan tugasnya. Hal ini disebabkan karena rekan anda tersebut harus menggabungkan pekerjaan tersebut terlebih dahulu sebelum dikumpulkan ditambah lagi semua rekan anggota team mengumpulkan tugas pribadi mereka juga terlambat, sehingga rekan anda yang bertugas untuk menggabungkan setiap pekerjaan jadi tidak menyelesaikan pekerjaannya tepat waktu, sikap anda',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Mengakui kesalahan kepada atasan jika anda juga turut berkontribusi pada masalah tersebut. soal ini membahas tentang aspek inisiatif dan tanggungjawab. tetap mengakui kesalahan dan memperbaiki segera agar permasalahan lekas terselesaikan.',
            ],
            //79
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Salah seorang rekan kerja saya mendapat promosi sedangkan menurut penilaian saya kemampuannya tidak lebih baik dari saya. Respon saya adalah ...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Tetap bekerja seperti biasa Soal ini membahas tentang aspek lapang dada. tetap lapang dada dan tetap memacu untuk lebih baik kedepannya. tidak lupa memberikan support kepada rekan tersebut',
            ],
            //80
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda sedang mengendarai motor dengan agak terburu-buru karena khawatir terlambat sampai dikantor. Ditengah perjalanan, dari jauh terlihat ada sepasang laki- laki dan perempuan berpakaian serba putih-hitam menghentikan setiap keendaraan yang melintas dihadapannya dengan panik, namun sepertinya tidak mendapat respon yang baik. Motor Anda pun di stop, laki-laki itu meminta bantuan Anda untuk mengantarkan istrinya yang akan melaksanakan ujian CAT Sekolah dalam waktu kurang lebih 30 menit lagi, karena motor yang mereka tumpangi mengalami bocor ban dan sedang ditangani oleh bengkel. Rupanya tempat yang dituju kebetulan satu arah, namun bukanlah jalur tercepat yang biasa Anda lewati untuk sampai dikantor. Yang akan Anda lakukan adalah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang paling tepat adalah Mengantarkan hanya setengah jalan karena saya harus melintasi jalur yang berbeda untuk cepat sampai dikantor. Soal ini membahas tentang aspek inisiatif dan tanggung jawab. ha tersebut dilakukan agar permasalahan segera terselesaikan',
            ],
            //81
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Saya adalah seorang staf administrasi di sebuah perusahaan jasa layanan telepon. Akibat kenaikan tarif layanan telepon banyak pelanggan yang datang dan mengajukan protes. Karena hal tersebut, saya diminta membantu bagian pelayanan. Tiba-tiba, saat bertugas, saya harus melayani seorang tamu yang sangat rewel dan banyak bertanya. Sikap saya saat itu adalah',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Melayani seperti biasa dan memberikan yang terbaik. soal ini membahas tentang aspek tanggungjawab.',
            ],
            //82
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda sebagai manajer pelayanan konsumen di salah satu tempat servis mobil. Suatu hari ada seorang pelanggan perempuan yang sudah menunggu 3 jam untuk servis mobilnya. Untuk membuat pelanggan merasa nyaman dalam menunggu, hal apa yang anda lakukan...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Mengajak ngobrol pelanggan sembari menunggu mobilnya selesai di servis. soal ini membahas tentang aspek inisiatif',
            ],
            //83
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda mempunyai klient yg telah bertahun-tahun di perusahaan anda, suatu ketika klient tsb ditangani oleh rekan kerja anda. Dan rekan kerja tsb melakukan suatu tindakan yg tidak disenangi oleh klien tsb. Bagaimana sikap anda dlam situasi tsb?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Meminta maaf atas nama rekan kerja anda soal ini membahas tentang aspek inisiatif dan rendah hati. ',
            ],
            //84
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Kamu sebagai seorang polisi, kemudian ada salah seorang yang minta didahulukan dalam pembuatan SKCK karena lusa harus segera diberikan ke tempat kerja, padahal situasi saat itu pemohon SKCK juga sangat banyak. Sebagai Polisi apa yang harus kamu lakukan ?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'jawaban yang paling tepat adalah Menyuruh orang itu untuk ikut sesuai aturan yaitu antre soal ini membahas tentang aspek ketegasan.',
            ],
            //85
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Ketika anda hendak berangkat ke kantor, anda melewati jalan raya dan anda melihat banyak orang membuang sampah di dekat tempat pembuangan sampah dan sampah tersebut berserahkan dipinggir jalan yang mengganggu pandangan dan jalannya kendaraan. Apakah yang akan anda lakukan melihat keadaan tersebut....',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah memberitahu orang yang ada disekitar jalan untuk memungut sampah tersebut dan membuah pada tempat pembuangan sampah yang telah disediakan. Soal ini membahas tentang sosial budaya.',
            ],
            //86
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Kantor anda akan mengadakan bakti sosial di daerah padat penduduk. Agar acara tersebut berjalan dengan lancar yang akan anda perhatikan adalah…',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah jenis bantuan dan koordinasi dengan pihak terkait agar acara berlangsung dengan tertib. Soal ini membahas tentang jejaring kerja.',
            ],
            //87
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Suatu hari Anda ditugaskan untuk melaksanakan dinas luar ke suatu desa adat. Di desa tersebut Anda dijamu dengan makanan yang dalam agama Anda, makanan tersebut dilarang untuk dimakan. Bagaimana sikap Anda ?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Tidak memakan makanan tersebut dan menanyakan hal lain tentang adat dan kebudayaan di desa tersebut agar lebih memahami kebiasaan-kebiasaannya. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //88
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Teman sekantor suka mengolok – olok teman yang berasal dari daerah dan memiliki adat yang kuat. Kita sebaiknya?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Menasehati mengenai keragaman kebudayaan tanpa diminta. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //89
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Saya baru saja pindah ke lingkungan yang baru, dan ingin mengadakan syukuran dengan mengundang pentas musik. Seorang tetangga mengingatkan saya kalau budaya di lingkungan tersebut menganggap pentas musik adalah sesuatu yang kurang baik. Yang saya lakukan adalah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Mengganti acara dengan yang lebih cocok untuk lingkungan tersebut. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //90
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Atasan anda menugaskan anda membuat sebuah tim untuk menyelesaikan sebuah masalah pekerjaan di kantor anda, tetapi di kantor anda terdiri dari orang-orang dari berbagai macam latar belakang suku yang berbeda dengan anda. Bagamana sikap anda...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Memilih orang-orang dari berbagai latar belakang yang berbeda agar dapat memperoleh bermacam saran dan masukan. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //91
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Ada tetangga baru di dekat rumah Anda dan mereka sangat menyukai musik keras/underground music, sikap Anda terhadap hal itu …',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Mengambil kesempatan untuk bertemu mereka seolah-olah secara tidak sengaja, dan dengan bijaksana mengatakan bahwa musik yang didengarkan terlalu keras. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //92
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda bekerja di kantor dan kepala dewan kantor sedang berjalan melewati Anda, maka',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Melanjutkan seperti biasa dan berbicara dengannya jika diperlukan. Soal ini membahas tentang aspek Profesionalisme Kerja. ',
            ],
            //93
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda adalah rakyat sipil yang diwajibkan untuk mengikuti wajib militer dan putra Anda menanyakan kepada Anda tentang keterlibatan Anda dalam sebuah perang. Kenyataannya adalah bahwa Anda menghindari wajib militer tersebut karena Anda takut. Maka Anda akan ...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Mengatakan kebenarannya dan menjelaskan bahwa perang adalah sesuatu yang ditakuti oleh orang-orang. Soal ini membahas tentang aspek Sosial Budaya.',
            ],
            //94
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Siska adalah seorang mahasiswi fakultas kedokteran di universitas ternama. Adapun pada semester pertengahan, dia mengalami depresi berat karena ayahnya meninggal akibat kecelakaan pesawat terbang. Akibat depresi berat itu, Siska terpaksa mengambil cuti dan melakukan terapi pengobatan sampai depresinya sembuh. Kini Siska telah lulus dari kuliahnya dan ingin melanjutkan menjadi dokter spesialis. Namun, panitia seleksi menggugurkannya karena Siska memiliki riwayat gangguan kejiwaan. Menurut Anda, bagaimana sikap panitia seleksi tersebut kepada Siska ?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'awabannya adalah Setuju karena panitia seleksi sudah tepat dengan menjalankan tugas sebagaimana mestinya. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //95
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Sebagai anggota tim humas dalam kepanitiaan, Anda diserahi tugas untuk memberikan undangan pada narasumber. Namun, karena suatu alasan Anda lupa dan belum menyerahkan undangan tersebut hingga narasumber tersebut menolak untuk hadir di acara tersebut. Sebagai konsekuensinya, ketua kegiatan meminta Anda untuk mencari sendiri narasumber untuk acara yang dilangsungkan. Sikap Anda adalah...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya adalah Menerima penuh semua akibatnya. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //96
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Karena kekurangan sumber daya manusia di sebuah kantor cabang perusahaan tempat anda bekerja, Atasan anda memutuskan hendak memindahkan anda ke cabang yang sama sekali tidak pernah anda kunjungi disebuah pulau terpencil, padahal anda adalah karyawan yang sudah lama mengabdi dan berprestasi dan anda cukup dekat dengan atasan,sikap anda',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawabannya yang tepat adalah Berdiskusi dengan atasan anda terkait proses pemindahan anda ke kantor cabang yang baru tersebut. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //97
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Pimpinan menugaskan saya untuk menjadi notulen dalam Rapat Badan Pertimbangan Penempatan dan Mutasi Pegawai. Respon saya ..',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang tepat adalah Tidak akan membocorkan keputusan rapat karena hal tersebut bukan wewenang saya. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //98
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Anda seorang karyawan yang memiliki dedikasi yang tinggi terhadap pekerjaan. Suatu hari anda dihadapkan dengan pekerjaan yang sangat banyak dan semuanya memiliki deadline yang sama. Sebagai karyawan yang profesional apa yang anda lakukan?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang tepat adalah Melapor pada atasan bahwa anda butuh bantuan karyawan lain dalam menyelesaikan tugas yang banyak. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //99
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Seminggu yang lalu diperusahaan tempat anda bekerja sedang melakukan perekrutan karyawan baru. Hari ini semua dari calon pelamar yang memenuhi sarat administrasi diminta datang oleh atasan anda untuk seleksi. Namun karena suatu hal atasan anda berhalangan untuk datang ke kantor. Atasan meminta anda untuk memutuskan diterima atau tidaknya pelamar tersebut di perusahaan. Hal apa yang akan kamu lakukan?',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang tepat adalah Berikan tes tertulis, wawancara dan memutuskan untuk menerima atau menolak berdasarkan klasifikasi yang diingin perusahaan. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ],
            //100
            [
                'id_question_package' => '1',
                'id_question_type' => '3',
                'question' => 'Instansi kantor anda mengadakan training yang sangat bermanfaat bagi peningkatan kemampuan anda, namun training tersebut diakan pada hari sabtu dan minggu...',
                'question_image' => '',
                'choice_type' => 'text',
                'answer' => 'Jawaban yang tepat adalah Saya bersedia mengorbankan dua hari libur tersebut untuk mengikuti training. Soal ini membahas tentang aspek Profesionalisme Kerja.',
            ]
        ]);
    }
}
