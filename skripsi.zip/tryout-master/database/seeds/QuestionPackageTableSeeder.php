<?php

use Illuminate\Database\Seeder;

class QuestionPackageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('question_packages')->insert([
            [
                'question_package' => 'Paket 1',
                'desc' => 'Paket berisi soal TWK, TKP dan TIU.',
                'is_active' => "true",
                'tryout_time' => '90',
            ],
            [
                'question_package' => 'Paket 2',
                'desc' => 'Paket berisi soal TWK, TKP dan TIU.',
                'is_active' => "true",
                'tryout_time' => '90',
            ],
            [
                'question_package' => 'Paket 3',
                'desc' => 'Paket berisi soal TWK, TKP dan TIU.',
                'is_active' => "false",
                'tryout_time' => '90',
            ],
        ]);
    }
}
