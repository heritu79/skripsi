<?php

use Illuminate\Database\Seeder;

class InformationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('informations')->insert([
            [
                'information_header' => 'pendaftaran Sekolah',
                'information_body' => 'pendaftaran Sekolah dibuka 10 juli 2020',
                'timeline_date' => '2020-05-18',
            ],
            [
                'information_header' => 'Daftar Ulang',
                'information_body' => 'Daftar ulang mengumpulkan persyaratan Sekolah',
                'timeline_date' => '2020-05-21',
            ],
            [
                'information_header' => 'Seleksi tahap 1',
                'information_body' => 'seleksi tahap 1 memeriksa semua file',
                'timeline_date' => '2020-05-25',
            ],
            [
                'information_header' => 'Pembatalan Sekolah',
                'information_body' => 'Seleksi Sekolah dibatalkan karena covid-19, informasi lebih lanjut akan diinformasikan oleh pemerintah. Diharapkan masyarakat dapat turut andil dalam penanganan covid-19 dengan melaksanakan <i>social distancing</i> dan dirumah saja.',
                'timeline_date' => '',
            ],
        ]);
    }
}
