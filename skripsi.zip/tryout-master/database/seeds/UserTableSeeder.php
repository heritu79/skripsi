<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'name' => 'admin',
                'email' => 'admin@sttgarut.ac.id',
                'username' => 'admin',
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                'role' => 'admin',
                'profile_picture' => 'default.png',
                'email_verified_at' => '2020-06-09 23:06:35',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Siswa 1',
                'email' => 'rifan.alamsyah03@gmail.com',
                'username' => 'siswa1',
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                'role' => 'user',
                'profile_picture' => 'default.png',
                'email_verified_at' => '2020-06-09 23:06:37',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Siswa 2',
                'email' => 'rifan.alamsyah02@gmail.com',
                'username' => 'siswa2',
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                'role' => 'user',
                'profile_picture' => 'default.png',
                'email_verified_at' => '2020-06-09 23:06:37',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
    }
}
