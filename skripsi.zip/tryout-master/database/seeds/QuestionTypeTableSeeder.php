<?php

use Illuminate\Database\Seeder;

class QuestionTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('question_types')->insert([
            [
                'question_type' => 'TWK',
                'passing_grade' => 43,
                'desc' => 'Test Wawasan Kebangsaan.',
            ],
            [
                'question_type' => 'TIU',
                'passing_grade' => 46,
                'desc' => 'Test Intelegensi Umum.',
            ],
            [
                'question_type' => 'TKP',
                'passing_grade' => 72,
                'desc' => 'Test Karakteristik Pribadi.',
            ],
        ]);
    }
}
