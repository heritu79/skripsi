<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeyQuestionTable2 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('user_tryouts', function (Blueprint $table) {
            $table->dropForeign('user_tryouts_id_user_foreign');
            $table->dropForeign('user_tryouts_id_question_package_foreign');

            $table->foreign('id_user')->references('id')->on('users');
            $table->foreign('id_question_package')->references('id')->on('question_packages');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
