<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserAnswersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_answers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('id_user_tryout'); //tryout yang dilakukan oleh user 
            $table->unsignedBigInteger('id_question_choice'); //jawaban yang diberikan oleh user
            $table->foreign('id_user_tryout')->references('id')->on('user_tryouts')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('id_question_choice')->references('id')->on('question_choices')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_answers');
    }
}
