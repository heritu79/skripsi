<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTryoutsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_tryouts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_user'); //user mana yang mengisi jawaban
            $table->unsignedBigInteger('id_question_package'); //paket mana yang dikerjakan
            $table->foreign('id_user')->references('id')->on('users');
            $table->foreign('id_question_package')->references('id')->on('question_packages');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_tryouts');
    }
}
