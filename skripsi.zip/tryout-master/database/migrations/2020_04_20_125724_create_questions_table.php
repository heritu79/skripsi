<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuestionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('questions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('id_question_package'); //paket soal yang membedakan soal yang akan tampil
            $table->unsignedBigInteger('id_question_type'); //jenis soal yang diisikan, mengambil dari table question_types
            $table->longtext('question')->nullable(); //soal berupa text
            $table->string('question_image')->nullable(); //gambar jika ada
            $table->enum('choice_type', ['text', 'img']); //membedakan jawaban yang akan ditampilkan antara gambar dan string
            $table->longtext('answer')->nullable(); //mendeskripsi soal dan jawaban
            $table->foreign('id_question_package')->references('id')->on('question_packages')->onDelete('cascade');
            $table->foreign('id_question_type')->references('id')->on('question_types');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('questions');
    }
}
